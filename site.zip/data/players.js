window.PEPPA_ROSTER = {
  "generatedAt": "2026-10-08T07:11:05.719Z",
  "source": "public snapshot",
  "avatarBase": "avatars/",
  "players": [
    {
      "qq": "player-01",
      "name": "苏苏",
      "role": "owner",
      "avatar": "avatars/player-01.jpg"
    },
    {
      "qq": "player-02",
      "name": "鸭謨言鸭",
      "role": "admin",
      "avatar": "avatars/player-02.jpg"
    },
    {
      "qq": "player-03",
      "name": "柠萌",
      "role": "admin",
      "avatar": "avatars/player-03.jpg"
    },
    {
      "qq": "player-04",
      "name": "AmR.",
      "role": "admin",
      "avatar": "avatars/player-04.jpg"
    },
    {
      "qq": "player-05",
      "name": "彬",
      "role": "member",
      "avatar": "avatars/player-05.jpg"
    },
    {
      "qq": "player-06",
      "name": "星",
      "role": "member",
      "avatar": "avatars/player-06.jpg"
    },
    {
      "qq": "player-07",
      "name": "小蓝",
      "role": "member",
      "avatar": "avatars/player-07.jpg"
    },
    {
      "qq": "player-08",
      "name": "口渴不喝水，掰开苏陌腿",
      "role": "member",
      "avatar": "avatars/player-08.jpg"
    },
    {
      "qq": "player-09",
      "name": "N神",
      "role": "member",
      "avatar": "avatars/player-09.jpg"
    },
    {
      "qq": "player-10",
      "name": "独宠堂主",
      "role": "member",
      "avatar": "avatars/player-10.jpg"
    },
    {
      "qq": "player-11",
      "name": "埃高荒瑟",
      "role": "member",
      "avatar": "avatars/player-11.jpg"
    },
    {
      "qq": "player-12",
      "name": "yizhiyu",
      "role": "member",
      "avatar": "avatars/player-12.jpg"
    },
    {
      "qq": "player-13",
      "name": "孤舟naughty",
      "role": "member",
      "avatar": "avatars/player-13.jpg"
    },
    {
      "qq": "player-14",
      "name": "千代高手鸭",
      "role": "member",
      "avatar": "avatars/player-14.jpg"
    },
    {
      "qq": "player-15",
      "name": "塔达林高阶领主～特莉波卡之夫",
      "role": "member",
      "avatar": "avatars/player-15.jpg"
    },
    {
      "qq": "player-16",
      "name": "†𝔸𝕟𝕘𝕖𝕝†",
      "role": "member",
      "avatar": "avatars/player-16.jpg"
    },
    {
      "qq": "player-17",
      "name": "晗",
      "role": "member",
      "avatar": "avatars/player-17.jpg"
    },
    {
      "qq": "player-18",
      "name": "大肥鱼",
      "role": "member",
      "avatar": "avatars/player-18.jpg"
    }
  ]
};
