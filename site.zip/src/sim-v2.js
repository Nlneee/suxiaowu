/*!
 * 群友大逃杀 · 滚球竞速淘汰赛 —— 物理与赛制内核
 * ---------------------------------------------------------------------------
 * 本文件不依赖任何 DOM / Canvas：浏览器用 <script> 直接加载，Node 里也能跑
 * （tools/verify.mjs 用它做无头复现校验）。
 *
 * 世界模型（2D 侧视）：
 *   赛道是一条「溜槽中心线」折线，带可变半宽 W(s)。小球被约束在距中心线
 *   W - r 的管道内，受重力沿坡下滑。管道约束就是"球永远滚不出赛道"的硬保证，
 *   同时保证同一轮里所有球面对完全相同的几何。
 *
 * 确定性：
 *   - 固定步长 1/120s 推进；
 *   - 所有遍历按索引顺序，无 Math.random / Date / 性能计时；
 *   - 唯一随机源 mulberry32(seed)，只用于赛道细节抖动；
 *   - 同 seed → 完全相同的比赛过程与名次（tools/verify.mjs 会跑两遍比对）。
 */
(function (global) {
  'use strict';

  /* ============================== 常量 ============================== */

  var DEG = Math.PI / 180;
  var DT = 1 / 120;             // 固定物理步长（120Hz）；内部再按速度自适应细分
  var BALL_R = 34;              // 所有球半径完全一致 —— 公平性硬要求
  var BALL_M = 1;               // 所有球质量完全一致 —— 公平性硬要求
  var BALL_I = 0.4 * BALL_M * BALL_R * BALL_R;   // 实心球转动惯量 I = 2/5·m·r²
  var GRAVITY = 1350;           // 重力加速度 g

  /* 空气阻力：a_drag = −k_air·|v|·v（与速度平方成正比）。
   * 终端速度 sqrt(g/k_air) = 1389。k_air 越小越接近纯自由落体：
   *   0.0006 → 0.3 秒自由落体平均加速度/g = 0.977
   *   0.0007 → 0.972（本工程取值，仍满足 ≥0.97 的判据）
   *   0.0010 → 0.962（掉出判据，故未采用）
   * 详见 README「物理模型」一节。 */
  var K_AIR = 0.0007;
  var MAX_SPEED = 1900;         // 数值保险，正常比赛不应触发
  var ROLL_FRIC = 0.022;        // 滚动阻力系数 c_roll：|a| = c_roll·g·|n_y|
  var MUD_ROLL_MUL = 2.5;       // 泥沼：滚动阻力 ×2.5（9° 坡的重力分量只有 211，×7 会把球拖停）
  var MUD_TAN_DAMP = 0.8;       // 泥沼：额外的切向阻尼（1/s）
  var SUB_TRAVEL = 0.35 * BALL_R;  // 每个子步的最大位移（防穿透）
  var SUB_MAX = 6;                 // 单步细分上限
  var E_STATIC = 40;            // |vn| < 40 → e = 0，视为静止接触（防地面抖动）
  var E_KNEE = 120;             // 40~120 之间 e 线性过渡到材质值
  var PEN_SLOP = 0.5;           // 允许的穿透容差
  var PEN_CORRECT = 0.8;        // 位置修正比例
  var VFX_VN = 200;             // 超过这个法向速度才产生撞击特效
  var STUCK_TIME = 3.0;         // 卡住判定时长
  var STUCK_SPEED = 55;         // （历史字段，保留导出）
  var STUCK_SLOW = 150;         // 脱困所需的"确实低速"门槛
  var STUCK_HARD = 12;          // 硬兜底：停滞这么久必定脱困
  var DEATH_TIME = 1.6;         // 淘汰动画时长
  var WORLD_W = 1500;           // 世界宽度
  var MAX_RACE_TIME = 300;      // 单轮保险丝

  var CUT_SIZE = 3;             // 每条淘汰线淘汰人数
  var CUT_COUNT = 5;            // 预赛淘汰线数量 → 18 - 5×3 = 3 人进决赛

  /* 材质表：碰撞恢复系数 e 与库仑摩擦系数 μ。
   * 所有碰撞（墙 / 挡板 / 风车 / 摆锤 / 平台 / 圆钉 / 蘑菇 / 球球）统一走
   * resolveBallContact，这里集中定义材质，不再散落 1.35 / 1.45 / 0.34 之类的硬编码反射系数。 */
  var MATERIALS = {
    wall:     { e: 0.58, mu: 0.25 },   // 弹性管壁：更明显弹回；保留原摩擦，避免缓坡粘球
    // 增强离开障碍时的法向速度，同时提高切向摩擦：正面更明显弹回，擦边更难滑过。
    // e 不超过 1，静态钉阵不会凭空增加能量；低速静止接触仍由 restitutionFor 抑制抖动。
    spinner:  { e: 0.92, mu: 0.34 },   // 旋转挡板 / 风车 / 摆锤
    platform: { e: 0.72, mu: 0.56 },   // 移动平台 / 推杆 / 闸门
    peg:      { e: 0.94, mu: 0.18 },   // 圆钉
    bumper:   { e: 0.98, mu: 0.10 },   // 弹射蘑菇
    ball:     { e: 0.65, mu: 0.05 },   // 球与球（低摩擦：18 球挤在窄管道里不能互相粘住）
  };

  var HIST_BIN = 20;            // 速度直方图分箱宽度（统计分位数用）
  var HIST_N = 140;             // 分箱数（覆盖到 2800）

  /* ============================== 工具 ============================== */

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function hypot(x, y) { return Math.sqrt(x * x + y * y); }

  /** 固定种子 PRNG：同 seed 完全可复现 */
  function mulberry32(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** 折线在 [i0,i1] 上的最小曲率半径（用相邻两段的转角估算） */
  function minCurvRadius(pts, i0, i1) {
    var minR = 1e9;
    for (var i = i0 + 1; i < i1; i++) {
      var a = pts[i - 1], b = pts[i], c = pts[i + 1];
      var v1x = b.x - a.x, v1y = b.y - a.y, v2x = c.x - b.x, v2y = c.y - b.y;
      var l1 = hypot(v1x, v1y), l2 = hypot(v2x, v2y);
      if (l1 < 1e-6 || l2 < 1e-6) continue;
      var cross = (v1x * v2y - v1y * v2x) / (l1 * l2);
      var dth = Math.abs(Math.asin(clamp(cross, -1, 1)));
      if (dth < 1e-9) continue;
      var R = ((l1 + l2) * 0.5) / dth;
      if (R < minR) minR = R;
    }
    return minR;
  }

  /* ========================= 赛道构建器 ========================= */

  /**
   * 用「直线 / 圆弧 / 正弦波 / 大厅 / 断层凹坑 / 泥沼」六种笔画拼出溜槽中心线。
   * state: 当前位置与航向（弧度，0=+x，PI/2=+y 向下）。
   */
  function Builder(x, y, thDeg) {
    this.pts = [];
    this.ws = [];
    this.rolls = [];
    this.arcLen = 0;      // 已生成中心线的真实弧长（障碍物按它定位，避免 sFrac 估算误差）
    this.pits = [];
    this.muds = [];
    this.waves = [];
    this.x = x; this.y = y; this.th = thDeg * DEG;
    this.w = 200;     // 半宽
    this.roll = 1;    // 滚动阻力倍率（只对接触状态生效，不再给自由落体刹车）
    this.push();
  }
  Builder.prototype.push = function () {
    if (this.pts.length) {
      var p = this.pts[this.pts.length - 1];
      this.arcLen += hypot(this.x - p.x, this.y - p.y);
    }
    this.pts.push({ x: this.x, y: this.y });
    this.ws.push(this.w);
    this.rolls.push(this.roll);
  };
  /** 直线前进 len；可选把半宽线性过渡到 wEnd */
  Builder.prototype.go = function (len, wEnd) {
    var n = Math.max(1, Math.round(len / 40));
    var w0 = this.w, w1 = (wEnd === undefined ? this.w : wEnd);
    var step = len / n;
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      this.x += Math.cos(this.th) * step;
      this.y += Math.sin(this.th) * step;
      this.w = w0 + (w1 - w0) * t;
      this.push();
    }
    return this;
  };
  /** 圆弧转弯：半径 R，航向变化 dthDeg（正=左转，负=右转） */
  Builder.prototype.arc = function (R, dthDeg, wEnd) {
    if (R === 0 || dthDeg === 0) return this;
    var dth = dthDeg * DEG;
    var sign = dth > 0 ? 1 : -1;
    // 圆心在航向的 ±90° 侧；位置角 φ 与航向满足 θ = φ + sign*90°
    var cdir = this.th + sign * Math.PI / 2;
    var cx = this.x + R * Math.cos(cdir);
    var cy = this.y + R * Math.sin(cdir);
    var phi0 = Math.atan2(this.y - cy, this.x - cx);
    var n = Math.max(2, Math.round(Math.abs(dth) / (6 * DEG)));
    var w0 = this.w, w1 = (wEnd === undefined ? this.w : wEnd);
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      var phi = phi0 + dth * t;          // ← 位置角增量就是航向增量
      this.x = cx + R * Math.cos(phi);
      this.y = cy + R * Math.sin(phi);
      this.w = w0 + (w1 - w0) * t;
      this.push();
    }
    this.th += dth;
    return this;
  };
  /**
   * 断层凹坑：沿直线推进 len 的同时朝"地板侧"下沉 depth*(1-cos2πt)/2。
   * 入口曲率极大 → 高速球直接飞越；低速球掉进去再爬出来，只失速不判死。
   */
  Builder.prototype.dip = function (len, depth, wEnd) {
    var i0 = this.pts.length;
    var n = Math.max(8, Math.round(len / 28));
    var w0 = this.w, w1 = (wEnd === undefined ? this.w : wEnd);
    var step = len / n;
    var tx = Math.cos(this.th), ty = Math.sin(this.th);
    var nxp = -ty, nyp = tx;
    if (nyp < 0) { nxp = -nxp; nyp = -nyp; }   // 指向地板侧
    var x0 = this.x, y0 = this.y;
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      var off = depth * (1 - Math.cos(2 * Math.PI * t)) / 2;
      this.x = x0 + tx * (step * i) + nxp * off;
      this.y = y0 + ty * (step * i) + nyp * off;
      this.w = w0 + (w1 - w0) * t;
      this.push();
    }
    this.pits.push({ i0: i0, i1: this.pts.length - 1, depth: depth });
    return this;
  };
  /**
   * 正弦摆动 S 形连续弯：沿当前航向推进 len，横向按
   * amp·sin(2πp·t)·sin²(πt) 偏移（两端包络为 0，进出口航向不变）。
   * 生成后会数值校验曲率半径，达不到 w+40 就自动收小振幅重来。
   */
  Builder.prototype.wave = function (len, amp, periods, wEnd) {
    var i0 = this.pts.length;
    var x0 = this.x, y0 = this.y;
    var w0 = this.w, w1 = (wEnd === undefined ? this.w : wEnd);
    var need = w0 + 40;
    var cur = Math.abs(amp);
    var al0 = this.arcLen;
    for (var attempt = 0; attempt < 8; attempt++) {
      this.pts.length = i0; this.ws.length = i0; this.rolls.length = i0; this.arcLen = al0;
      var n = Math.max(24, Math.round(len / 26));
      var tx = Math.cos(this.th), ty = Math.sin(this.th);
      var nx = -ty, ny = tx;
      for (var i = 1; i <= n; i++) {
        var t = i / n;
        var env = Math.sin(Math.PI * t);
        var off = cur * Math.sin(2 * Math.PI * periods * t) * env * env;
        this.x = x0 + tx * len * t + nx * off;
        this.y = y0 + ty * len * t + ny * off;
        this.w = w0 + (w1 - w0) * t;
        this.push();
      }
      var Rmin = minCurvRadius(this.pts, i0, this.pts.length - 1);
      if (Rmin >= need || attempt === 7) break;
      cur *= Math.pow(Math.max(0.05, (Rmin / need) * 0.98), 0.85);
    }
    this.waves.push({ i0: i0, i1: this.pts.length - 1, amp: cur });
    return this;
  };
  /** 大厅：先放宽到 wMax（≤360）再收回，用来放钉阵 / 风车（中间保持较长的等宽段） */
  Builder.prototype.chamber = function (len, wMax, wEnd) {
    var m = Math.min(wMax, 360);
    var back = (wEnd === undefined ? this.w : wEnd);
    this.go(len * 0.28, m);
    this.go(len * 0.44, m);
    this.go(len * 0.28, back);
    return this;
  };
  /**
   * 泥沼：只把「接触时的滚动阻力倍率」抬高到 mul（外加切向阻尼），不改几何。
   * 关键：空中经过泥沼时完全没有影响 —— 阻力只在 contact=true 时参与积分。
   */
  Builder.prototype.mud = function (len, mul, wEnd) {
    var i0 = this.pts.length;
    var n = Math.max(6, Math.round(len / 40));
    var w0 = this.w, w1 = (wEnd === undefined ? this.w : wEnd);
    var d0 = this.roll, d1 = (mul === undefined ? MUD_ROLL_MUL : mul);
    var step = len / n;
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      var k = t < 0.2 ? (t / 0.2) : (t > 0.8 ? ((1 - t) / 0.2) : 1);
      this.x += Math.cos(this.th) * step;
      this.y += Math.sin(this.th) * step;
      this.w = w0 + (w1 - w0) * t;
      this.roll = d0 + (d1 - d0) * k;
      this.push();
    }
    this.roll = d0;
    this.muds.push({ i0: i0, i1: this.pts.length - 1 });
    return this;
  };

  /* ========================= 赛道：预赛 / 决赛 ========================= */

  var PALETTE = ['#38bdf8', '#a78bfa', '#f472b6', '#34d399', '#fbbf24', '#22d3ee', '#fb7185', '#facc15'];

  function finalize(b, meta) {
    var pts = b.pts, n = pts.length;
    var cum = new Float64Array(n);
    var seg = new Float64Array(n);
    var i;
    for (i = 1; i < n; i++) {
      var d = hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
      seg[i - 1] = d;
      cum[i] = cum[i - 1] + d;
    }
    seg[n - 1] = 1;

    var course = {
      kind: meta.kind, seed: meta.seed, name: meta.name,
      pts: pts, w: b.ws, rollFric: b.rolls, cum: cum, seg: seg,
      total: cum[n - 1], levels: meta.levels, elims: [],
      objects: meta.objects, spawn: meta.spawn,
      pits: [], muds: [], waves: [], throats: [], startS: 0, finishS: cum[n - 1],
    };

    // 凹坑 → 弧长区间（渲染 & 统计用）
    b.pits.forEach(function (p) {
      course.pits.push({ s0: cum[p.i0], s1: cum[p.i1], depth: p.depth, i0: p.i0, i1: p.i1 });
    });
    b.muds.forEach(function (p) {
      course.muds.push({ s0: cum[p.i0], s1: cum[p.i1], i0: p.i0, i1: p.i1 });
    });
    b.waves.forEach(function (p) {
      course.waves.push({ s0: cum[p.i0], s1: cum[p.i1], amp: p.amp, i0: p.i0, i1: p.i1 });
    });

    var minX = 1e9, maxX = -1e9, maxW = 0, minY = 1e9, maxY = -1e9;
    for (i = 0; i < n; i++) {
      var wx = pts[i].x, ww = course.w[i], wy = pts[i].y;
      if (wx - ww < minX) minX = wx - ww;
      if (wx + ww > maxX) maxX = wx + ww;
      if (wy - ww < minY) minY = wy - ww;
      if (wy + ww > maxY) maxY = wy + ww;
      if (ww > maxW) maxW = ww;
    }
    course.minX = minX; course.maxX = maxX; course.maxW = maxW;
    course.minY = minY; course.maxY = maxY;

    // 喉口（收窄到 w ≤ 120 的局部最窄处）→ 渲染做"内向箭头 + 橙色墙体"
    for (i = 6; i < n - 6; i++) {
      if (course.w[i] > 124) continue;
      var isMin = true;
      for (var k2 = i - 6; k2 <= i + 6; k2++) if (course.w[k2] < course.w[i]) { isMin = false; break; }
      if (isMin && (course.throats.length === 0 || cum[i] - course.throats[course.throats.length - 1].s1 > 120)) {
        course.throats.push({ s: cum[i], s0: cum[i] - 130, s1: cum[i] + 130, w: course.w[i], i: i });
      }
    }

    course.levels.forEach(function (lv) {
      lv.s0 = cum[lv.i0];
      lv.s1 = cum[Math.min(lv.i1, n - 1)];
      lv.len = lv.s1 - lv.s0;
    });
    (meta.cutAfter || []).forEach(function (no, idx) {
      var lv = course.levels[no - 1];
      course.elims.push({ s: lv.s1, round: idx + 1, afterLevel: no, done: false });
    });

    var sp = course.spawn[0];
    course.startS = nearestOnCenterline(course, sp.x, sp.y, 0, n).s;
    return course;
  }

  /* ===================== 赛道骨架：缓坡主段 + 发夹掉头 =====================
   * 新物理下球会在陡坡上不断加速，旧版"竖直自由落体 + 35° 斜切"的骨架完全不能用了
   * （落差 20000 会让球一直撞 MAX_SPEED）。改成本骨架：
   *
   *   主段：航向 ±2° 的缓坡，横向走满 X_LO ~ X_HI，半宽 TRACK_W
   *   掉头：180° 半圆弧，半径 TURN_R，掉头段收窄到 TURN_W
   *
   * 180° 弧的位移是「纯竖直 2R、横向 −TURN_DX」（起点终点关于圆心对称），
   * 所以掉头几乎不改变 x；但**弧本身会向内侧鼓出 TURN_R**，因此主段的两个端点
   * X_LO / X_HI 必须为「60 的收窄段 + TURN_R 的鼓出 + 管道半宽」留出余量：
   *   X_LO − 60 − TURN_R − TURN_W ≥ 8      X_HI + 60 + TURN_R + TRACK_W ≤ 1492
   * 落差几乎全部由掉头承担（每折 2R = 280），主段只贡献 2° 的缓降 → 球速在
   * "掉头加速 → 缓坡减速"之间大幅振荡，不再匀速。
   */
  var MAIN_DEG = 12;      // 主段坡度：平衡速度 sqrt(g(sinα−c_roll·cosα)/k_air) ≈ 599
  var TRACK_W = 200;      // 主段半宽
  var TURN_R = 140;       // 掉头半径（要求 TURN_R ≥ TURN_W + 40）
  var TURN_W = 100;       // 掉头段半宽
  var TURN_FOLD = 86;     // 掉头第二段转角：与第一段 70° 相加 = 156° = 180 − 2·MAIN_DEG
  var SHAFT_LEN = 300;    // 掉头中间的竖直下降段：把相邻两折的管道拉开，避免重叠（落差 ≈ 473 > 管道直径 400）
  var X_LO = 340;         // 向左主段的终点 x（已为掉头鼓出留好余量）
  var X_HI = 1080;        // 向右主段的终点 x

  /** 预赛：12 关，缓坡主段 + 发夹掉头，5 条淘汰线（第 5/6/7/9/11 关末） */
  function buildQualifier(seed) {
    var rnd = mulberry32((seed ^ 0x9E3779B9) >>> 0);
    var b = new Builder(750, -600, 90);
    var levels = [];
    var objects = { bars: [], mills: [], plats: [], boosts: [], pegs: [], pendulums: [], bumpers: [] };
    var cur = null, a0 = 0, M = {};
    function begin(name, color, theme, danger) {
      cur = { no: levels.length + 1, name: name, color: color, theme: theme, danger: danger || 0, i0: b.pts.length, i1: 0, s0: 0, s1: 0 };
      levels.push(cur); a0 = b.arcLen; M = {};
    }
    function end() { cur.i1 = b.pts.length; }
    /** 记录「当前位置距本关起点的真实弧长」，障碍物用它定位 */
    function mark(k) { M[k] = b.arcLen - a0; return M[k]; }
    /** 沿当前航向走到绝对 x */
    function legTo(x, wEnd) { var L = (x - b.x) / Math.cos(b.th); if (L > 0) b.go(L, wEnd); }
    /** 发夹掉头：收窄 → 转 90° → 竖直下降 → 再转 86° → 展开
     *  掉头总落差 = 2·R·sin45 + SHAFT_LEN ≈ 460，明显大于管道直径 2·TRACK_W，
     *  相邻两折的管道不会重叠。横向只鼓出 R·sin45 ≈ 99。 */
    function hairpin() {
      var dir = Math.cos(b.th) > 0 ? 1 : -1;
      b.go(60, TURN_W);
      b.arc(TURN_R, dir * 70, TURN_W);
      b.go(SHAFT_LEN, TURN_W);
      b.arc(TURN_R, dir * 86, TURN_W);
      b.go(60, TRACK_W);
    }
    /** 走到当前方向的那一端 */
    function leg(wEnd) { legTo(Math.cos(b.th) < 0 ? X_LO : X_HI, wEnd === undefined ? TRACK_W : wEnd); }

    /* —— 起跑区：超宽竖井自由落体 + 大半径圆弧转入水平 ——
     * 竖井缩短到 240（40 自由落体 + 200 收窄）：入漏斗速度 sqrt(2g·240) ≈ 804，
     * 落在 600~800 的设计区间内。不再靠"阻力刹车"，而是用 R=320 的大圆弧
     * 把竖直速度平滑转成沿坡速度，避免 18 颗球高速砸成一堆。 */
    b.w = 720;
    b.go(40);
    b.go(200, 180);
    b.arc(320, -78, 200);   // 竖直(90°) → 主段坡度 12°
    b.w = TRACK_W;
    hairpin();                  // 起跑区末尾先掉一次头，让第一关从最右端向左跑

    /* ===== 第 1 关：直线加速坡（单折，向左） ===== */
    begin('直线加速坡', '#38bdf8', 'speed');
    b.go(100, 260);
    mark('b0'); b.go(120, 260);
    mark('b1'); b.go(120, 200);
    leg();
    hairpin();
    end();
    objects.boosts.push({ sOff: M.b0 + 50, len: 130, accel: 2500, lat: 60, halfW: 140, lv: 1 });
    objects.boosts.push({ sOff: M.b1 + 50, len: 130, accel: 2500, lat: 60, halfW: 140, lv: 1 });
    // 错位旋转闸门：堵住直通路线，转到顺着赛道时会自然开放，避免形成永久横墙。
    objects.bars.push({ sOff: 140, lat: 0, half: 185, thick: 26, omega: 2.0, phase: rnd() * 6.28, lv: 1 });
    objects.bars.push({ sOff: 430, lat: 0, half: 135, thick: 28, omega: -2.2, phase: rnd() * 6.28, lv: 1 });
    objects.bars.push({ sOff: 620, lat: 70, half: 80, thick: 24, omega: 2.4, phase: rnd() * 6.28, lv: 1 });

    /* ===== 第 2 关：波浪弯道（双折：右 + 左） ===== */
    begin('波浪弯道', '#a78bfa', 'wave');
    b.go(80, 180);
    b.wave(520, 150, 1, 180);
    leg();
    hairpin();
    b.go(80, 180);
    b.wave(520, 150, 1, 180);
    leg();
    hairpin();
    end();

    /* ===== 第 3 关：收窄漏斗 + 连环钉阵（单折，向右） ===== */
    begin('收窄漏斗', '#f472b6', 'funnel', 1);
    b.go(120, 200);
    b.go(60, 320);
    mark('hall3'); b.go(240, 320);      // 满宽大厅：4 排钉墙
    b.go(60, 200);
    mark('throat3'); b.go(100, 105);    // 喉口（半宽 105）
    b.go(80, 105);
    b.go(80, 190);
    leg();
    hairpin();
    end();
    /* 两排错位钉阵：增大圆钉，同时保留球心可连续穿行的斜向间隙。 */
    for (var r3 = 0; r3 < 2; r3++) {
      var lats3 = (r3 % 2) ? [-290, -100, 100, 290] : [-290, -150, 0, 150, 290];
      for (var c3 = 0; c3 < lats3.length; c3++) {
        objects.pegs.push({ sOff: M.hall3 + 30 + r3 * 110, lat: lats3[c3], r: 22, lv: 3 });
      }
    }

    /* ===== 第 4 关：连续旋转挡板（单折，向左，5 根） ===== */
    begin('连续旋转挡板', '#fb7185', 'hazard', 1);
    b.go(80, 200);
    mark('b0'); b.go(150, 200);
    mark('b1'); b.go(150, 200);
    mark('b2'); b.go(150, 200);
    leg();
    hairpin();
    end();
    var barKeys4 = ['b0', 'b1', 'b2'];
    for (var i4 = 0; i4 < barKeys4.length; i4++) {
      objects.bars.push({
        sOff: M[barKeys4[i4]] + 75, lat: 0, half: 135, thick: 28,
        omega: (i4 % 2 === 0 ? 1 : -1) * (2.0 + i4 * 0.12),
        phase: (i4 / barKeys4.length) * Math.PI * 2 + rnd() * 0.4, lv: 4,
      });
    }

    /* ===== 第 5 关：弹簧跳板（单折，主题关 → 3 块踏板） ===== */
    begin('弹簧跳板', '#34d399', 'spring');
    b.go(60, 200);
    mark('d0'); b.dip(120, 60, 200);
    b.go(50, 200);
    mark('d1'); b.dip(120, 60, 200);
    b.go(50, 200);
    mark('g0'); b.go(80, 200);
    mark('g1'); b.go(80, 200);
    mark('g2'); b.go(80, 200);
    leg();
    hairpin();
    end();
    for (var j5 = 0; j5 < 3; j5++) {
      objects.boosts.push({ sOff: M['g' + j5] + 45, len: 130, accel: 2500, lat: 60, halfW: 140, lv: 5 });
    }

    /* ===== 第 6 关：连环钉墙（单折，向右） ===== */
    begin('连环钉墙', '#06b6d4', 'funnel', 1);
    b.go(120, 200);
    b.go(60, 320);
    mark('hall6'); b.go(300, 320);      // 大厅：3 排钉墙
    b.go(60, 200);
    mark('gate6'); b.go(140, 200);
    leg();
    hairpin();
    end();
    for (var r6 = 0; r6 < 2; r6++) {
      var lats6 = (r6 % 2) ? [-290, -100, 100, 290] : [-290, -150, 0, 150, 290];
      for (var c6 = 0; c6 < lats6.length; c6++) {
        objects.pegs.push({ sOff: M.hall6 + 30 + r6 * 110, lat: lats6[c6], r: 24, lv: 6 });
      }
    }
    /* 出口双倍速旋转挡板（w=200 段：half+thick+ball_r = 188 > w−ball_r = 166，整条通道被封） */
    objects.bars.push({ sOff: M.gate6 + 70, lat: 0, half: 100, thick: 26, omega: 3.2, phase: rnd() * 6.28, lv: 6 });

    /* ===== 第 7 关：双风车走廊（单折，向左） ===== */
    begin('双风车走廊', '#8b5cf6', 'gear', 1);
    b.go(120, 200);
    b.go(60, 320);
    mark('hall7'); b.go(300, 320);      // 大厅：2 个反向旋转风车
    b.go(60, 200);
    mark('m7'); b.go(140, 200);
    leg();
    hairpin();
    end();
    objects.mills.push({ sOff: M.hall7 + 75, lat: -65, arms: 5, half: 145, thick: 28, omega: 2.2, phase: rnd() * 6.28, lv: 7 });
    objects.mills.push({ sOff: M.hall7 + 225, lat: 65, arms: 4, half: 145, thick: 28, omega: -2.0, phase: rnd() * 6.28, lv: 7 });

    /* ===== 第 8 关：断层缺口 + 摆锤（单折） ===== */
    begin('断层缺口', '#fbbf24', 'crack', 1);
    b.go(50, 220);
    mark('d8a'); b.dip(120, 65, 220);
    b.go(50, 220);
    mark('p8a'); b.go(70, 220);
    mark('p8b'); b.go(70, 220);
    mark('p8c'); b.go(70, 220);
    mark('d8b'); b.dip(120, 65, 220);
    b.go(50, 220);
    leg();
    hairpin();
    end();
    /* 摆锤只能从枢轴向「地板侧」伸展，所以用负 lat 配长臂覆盖左/中/右三段。 */
    objects.pendulums.push({ sOff: M.p8a + 35, lat: -172, arm: 258, thick: 30, ampDeg: 66, period: 2.0, phase: rnd() * 6.28, lv: 8 });
    objects.pendulums.push({ sOff: M.p8b + 35, lat: -58, arm: 160, thick: 30, ampDeg: 62, period: 2.3, phase: rnd() * 6.28, lv: 8 });
    objects.pendulums.push({ sOff: M.p8c + 35, lat: -186, arm: 96, thick: 30, ampDeg: 68, period: 2.6, phase: rnd() * 6.28, lv: 8 });

    /* ===== 第 9 关：移动平台（单折，向右） ===== */
    begin('移动平台', '#22d3ee', 'platform');
    b.go(60, 230);
    mark('d9a'); b.dip(130, 62, 230);
    b.go(50, 230);
    mark('d9b'); b.dip(130, 62, 230);
    b.go(50, 230);
    mark('p9a'); b.go(80, 230);
    mark('p9b'); b.go(80, 230);
    leg();
    hairpin();
    end();
    objects.plats.push({ sOff: M.d9a + 110, lat: 70, half: 130, thick: 22, amp: 95, period: 2.6, phase: 0.0, axis: 'lat', lv: 9, kind: 'slab' });
    objects.plats.push({ sOff: M.d9b + 115, lat: 70, half: 130, thick: 22, amp: 95, period: 2.6, phase: 2.1, axis: 'lat', lv: 9, kind: 'slab' });
    objects.plats.push({ sOff: M.d9a + 35, lat: 0, half: 130, thick: 26, amp: 95, period: 2.2, phase: 0.7, axis: 'lat', lv: 9, kind: 'gate' });
    objects.plats.push({ sOff: M.p9a + 40, lat: 0, half: 104, thick: 22, amp: 150, period: 2.9, phase: 1.2, axis: 'tan', lv: 9, kind: 'sweeper', orient: 'normal' });
    objects.plats.push({ sOff: M.p9b + 40, lat: 0, half: 104, thick: 22, amp: 150, period: 2.9, phase: 3.4, axis: 'tan', lv: 9, kind: 'sweeper', orient: 'normal' });

    /* ===== 第 10 关：风车大厅（单折，向左，3 风车 + 2 蘑菇） ===== */
    begin('风车大厅', '#f59e0b', 'gear', 1);
    b.go(120, 200);
    b.go(60, 320);
    mark('hall10'); b.go(300, 320);
    b.go(60, 200);
    mark('b10a'); b.go(80, 200);
    mark('b10b'); b.go(80, 200);
    leg();
    hairpin();
    end();
    objects.mills.push({ sOff: M.hall10 + 60, lat: 0, arms: 5, half: 125, thick: 26, omega: 2.1, phase: rnd() * 6.28, lv: 10 });
    objects.mills.push({ sOff: M.hall10 + 155, lat: 0, arms: 4, half: 118, thick: 24, omega: -2.5, phase: rnd() * 6.28, lv: 10 });
    objects.bumpers.push({ sOff: M.b10a + 40, lat: -60, r: 60, kick: 380, lv: 10 });
    objects.bumpers.push({ sOff: M.b10b + 40, lat: 60, r: 60, kick: 380, lv: 10 });

    /* ===== 第 11 关：之字形折返 + 泥沼（单折，向右） ===== */
    begin('之字形折返', '#c084fc', 'zigzag', 1);
    b.go(80, 190);
    b.arc(200, 10, 180);        // 相对主段再下折 10°
    b.go(140, 175);
    b.arc(200, -10, 185);       // 折回主段坡度
    mark('mud11'); b.mud(130, MUD_ROLL_MUL, 185);
    b.go(90, 185);
    mark('k0'); b.go(70, 185);
    mark('k1'); b.go(70, 185);
    leg();
    hairpin();
    end();
    for (var k11 = 0; k11 < 2; k11++) {
      objects.pegs.push({ sOff: M['k' + k11] + 40, lat: (k11 % 2 ? 58 : -58), r: 24, lv: 11 });
    }

    /* ===== 第 12 关：终点冲刺（单折，向左，8 颗弹射蘑菇夹道，无掉头） ===== */
    begin('终点冲刺', '#facc15', 'checker');
    b.go(80, 220);
    for (var m12 = 0; m12 < 2; m12++) { mark('m' + m12); b.go(170, 260); }
    leg();
    end();
    for (var m13 = 0; m13 < 2; m13++) {
      objects.bumpers.push({ sOff: M['m' + m13] + 55, lat: (m13 % 2 ? -90 : 90), r: 56, kick: 520, lv: 12 });
    }

    // 起跑：18 球在起跑竖井【内部】一字排开，从竖井顶部开始自由落体。
    // ⚠️ 旧实现把 spawn 放在 y = -60 —— 那里已经在竖井底部大圆弧之外，而球横跨
    //    x∈[86,1414]（半宽 664）远超该处的管道半宽（TRACK_W = 200），于是球一出生
    //    就在墙外，第一帧就被 channelConstrain 挤回管道 —— 画面上就是「一排球横着
    //    贴在墙上」，而不是在赛道里下落。
    // 起跑：18 球排在起跑竖井【内部】的两排上，从竖井里开始自由落体。
    // ⚠️ 旧实现把 spawn 放在 y = -60 —— 那里已经在竖井底部大圆弧之外，而球横跨
    //    x∈[86,1414]（半宽 664）远超该处的管道半宽（TRACK_W = 200），于是球一出生
    //    就在墙外，第一帧就被 channelConstrain 挤回管道 —— 画面上就是「一排球横着
    //    贴在墙上」，而不是在赛道里下落。
    //
    // 位置必须同时满足两个条件：
    //  ① 在竖井墙内：y=-560 处半宽 720，球心可用 686；
    //  ② 「离竖井中心线比离下方大圆弧更近」—— nearestOnCenterline() 取全局最近点，
    //     而大圆弧向右鼓出到 x = 1070+320 = 1390，所以右侧的球很容易被误投影到圆弧上：
    //     实测 x=1390 的球 cursor 直接指到圆弧中段，第一步就被沿赛道推进 480
    //     （y 从 -560 跳到 -81.9）。解 sqrt((x-1089)²+534²) = x-750 得临界 x ≈ 1340。
    // 于是单排最多只能用 750±550 ≈ 1100 的跨度，放不下 18 球（需要 1224），
    // 所以分成两排、每排 9 球，x 取 750±288（远小于临界值），槽距 576/8 = 72 > 球直径 68。
    // 两排纵向错开 80（= 球直径 + 12），既保证两排球不互相重叠，也不会把出发时间差拉大。
    var spawn = [];
    var q;
    for (q = 0; q < 9; q++) spawn.push({ x: 462 + (1038 - 462) / 8 * q, y: -560 });
    for (q = 0; q < 9; q++) spawn.push({ x: 462 + (1038 - 462) / 8 * q, y: -480 });

    return finalize(b, {
      kind: 'qualifier', seed: seed, name: '预赛 · 18 进 3',
      levels: levels, objects: objects, spawn: spawn, cutAfter: [5, 6, 7, 9, 11],
    });
  }

  /** 决赛：6 关，3 人争先（同一骨架，更窄更险） */
  function buildFinal(seed) {
    var rnd = mulberry32((seed ^ 0x85EBCA6B) >>> 0);
    var b = new Builder(750, -420, 90);
    var levels = [];
    var objects = { bars: [], mills: [], plats: [], boosts: [], pegs: [], pendulums: [], bumpers: [] };
    var cur = null, a0 = 0, M = {};
    function begin(name, color, theme, danger) {
      cur = { no: levels.length + 1, name: name, color: color, theme: theme, danger: danger || 0, i0: b.pts.length, i1: 0, s0: 0, s1: 0 };
      levels.push(cur); a0 = b.arcLen; M = {};
    }
    function end() { cur.i1 = b.pts.length; }
    function mark(k) { M[k] = b.arcLen - a0; return M[k]; }
    function legTo(x, wEnd) { var L = (x - b.x) / Math.cos(b.th); if (L > 0) b.go(L, wEnd); }
    function hairpin() {
      var dir = Math.cos(b.th) > 0 ? 1 : -1;
      b.go(50, 140);
      b.arc(190, dir * 68, 140);
      b.go(150, 140);
      b.arc(190, dir * 88, 140);
      b.go(50, 230);
    }
    function leg(wEnd) { legTo(Math.cos(b.th) < 0 ? 364 : 1040, wEnd === undefined ? 230 : wEnd); }

    var FW = 230;               // 决赛道（球心通道 196，障碍留缝但不宽裕）

    b.w = 300;
    b.go(40);
    b.go(160, FW);
    b.arc(300, -81, FW);
    b.w = FW;
    hairpin();

    begin('决赛起跑', '#38bdf8', 'speed', 1);
    mark('fb0'); b.go(110, FW);
    mark('fb1'); b.go(110, FW);
    leg();
    hairpin();
    end();
    objects.bars.push({ sOff: M.fb0 + 60, lat: -25, half: 130, thick: 26, omega: 2.0, phase: rnd() * 6.28, lv: 1 });

    begin('双旋刃', '#fb7185', 'hazard', 1);
    b.go(80, FW);
    mark('fba'); b.go(110, FW);
    mark('fbb'); b.go(110, FW);
    leg();
    hairpin();
    end();
    objects.bars.push({ sOff: M.fba + 55, lat: -30, half: 130, thick: 26, omega: 2.2, phase: rnd() * 6.28, lv: 2 });
    objects.bars.push({ sOff: M.fbb + 225, lat: 30, half: 130, thick: 26, omega: -2.2, phase: rnd() * 6.28, lv: 2 });

    begin('摆锤与风车', '#f59e0b', 'gear', 1);
    b.go(80, FW);
    b.go(50, 260);
    mark('fh'); b.go(240, 260);
    b.go(50, FW);
    mark('fp'); b.go(100, FW);
    leg();
    hairpin();
    end();
    objects.mills.push({ sOff: M.fh + 80, lat: 0, arms: 5, half: 100, thick: 22, omega: 2.5, phase: rnd() * 6.28, lv: 3 });
    objects.pendulums.push({ sOff: M.fp + 50, lat: -150, arm: 215, thick: 28, ampDeg: 65, period: 2.2, phase: rnd() * 6.28, lv: 3 });

    begin('双旋刃·险峰', '#a78bfa', 'hazard', 1);
    b.go(80, FW);
    mark('fca'); b.go(110, FW);
    mark('fcb'); b.go(110, FW);
    leg();
    hairpin();
    end();
    objects.bars.push({ sOff: M.fca + 55, lat: 30, half: 140, thick: 28, omega: -2.4, phase: rnd() * 6.28, lv: 4 });
    objects.bars.push({ sOff: M.fcb + 225, lat: -30, half: 140, thick: 28, omega: 2.4, phase: rnd() * 6.28, lv: 4 });

    begin('断崖升降台', '#fbbf24', 'crack', 1);
    b.go(60, FW);
    mark('fd0'); b.dip(120, 55, FW);
    b.go(50, FW);
    mark('fd1'); b.dip(120, 55, FW);
    b.go(50, FW);
    mark('fpa'); b.go(80, FW);
    mark('fpb'); b.go(80, FW);
    leg();
    hairpin();
    end();
    objects.plats.push({ sOff: M.fd0 + 120, lat: 62, half: 130, thick: 22, amp: 100, period: 2.4, phase: 0, axis: 'lat', lv: 5, kind: 'slab' });
    objects.plats.push({ sOff: M.fd1 + 125, lat: 62, half: 130, thick: 22, amp: 100, period: 2.4, phase: 2.1, axis: 'lat', lv: 5, kind: 'slab' });

    begin('冠军冲刺', '#facc15', 'checker', 1);
    b.go(70, FW);
    mark('fz'); b.go(140, FW);
    mark('fma'); b.go(100, FW);
    mark('fmb'); b.go(100, FW);
    leg();
    end();
    objects.boosts.push({ sOff: M.fz + 60, len: 130, accel: 2300, lat: 60, halfW: 140, lv: 6 });
    objects.bumpers.push({ sOff: M.fma + 40, lat: -70, r: 60, kick: 300, lv: 6 });
    objects.bumpers.push({ sOff: M.fmb + 40, lat: 70, r: 60, kick: 300, lv: 6 });

    // 3 球同样放在【决赛起跑竖井内部】一字排开下落。
    // 决赛竖井首点 y=-420 的半宽只有 200（Builder 构造时 w=200 并立即 push），
    // b.w=300 要到 y=-380 才生效，所以取 y=-380：该处半宽 300（球心可用 266）；
    // 决赛圆弧向右鼓出到 x = 750+300+300 = 1350 更远，x 取 750±140 完全不会被误投影。
    var spawn = [{ x: 610, y: -380 }, { x: 750, y: -380 }, { x: 890, y: -380 }];
    return finalize(b, {
      kind: 'final', seed: seed, name: '决赛 · 3 人争冠',
      levels: levels, objects: objects, spawn: spawn, cutAfter: [],
    });
  }

  /* ========================= 几何查询 ========================= */

  /**
   * 在中心线上找离 (x,y) 最近的点（只搜 cursor ± win 段，O(1)）。
   * 返回弧长 s、最近点、距离 d、地板侧法线 (nx,ny)、带符号横向偏移 lat。
   */
  function nearestOnCenterline(course, x, y, cursor, win) {
    var pts = course.pts, n = pts.length;
    if (win === undefined) win = 50;
    if (!(cursor >= 0)) cursor = 0;
    var lo = Math.max(0, cursor - win), hi = Math.min(n - 2, cursor + win);
    var bestD2 = Infinity, bi = lo, bt = 0, bx = 0, by = 0;
    for (var i = lo; i <= hi; i++) {
      var ax = pts[i].x, ay = pts[i].y;
      var dx = pts[i + 1].x - ax, dy = pts[i + 1].y - ay;
      var L2 = dx * dx + dy * dy;
      var t = L2 > 1e-9 ? ((x - ax) * dx + (y - ay) * dy) / L2 : 0;
      if (t < 0) t = 0; else if (t > 1) t = 1;
      var px = ax + dx * t, py = ay + dy * t;
      var d2 = (x - px) * (x - px) + (y - py) * (y - py);
      if (d2 < bestD2) { bestD2 = d2; bi = i; bt = t; bx = px; by = py; }
    }
    var segLen = course.seg[bi] || 1;
    var tx = (pts[bi + 1].x - pts[bi].x) / segLen;
    var ty = (pts[bi + 1].y - pts[bi].y) / segLen;
    var nx = -ty, ny = tx;
    if (ny < 0) { nx = -nx; ny = -ny; }        // 法线指向"地板"侧
    var d = Math.sqrt(bestD2);
    var lat = (x - bx) * nx + (y - by) * ny;
    return { i: bi, t: bt, d: d, px: bx, py: by, s: course.cum[bi] + bt * segLen, nx: nx, ny: ny, lat: lat };
  }

  /** 按弧长取局部坐标架（渲染与物件摆放共用） */
  function frameAt(course, s) {
    var cum = course.cum, n = cum.length;
    if (s <= 0) s = 0;
    if (s >= cum[n - 1]) s = cum[n - 1];
    var lo = 0, hi = n - 1;
    while (lo + 1 < hi) { var mid = (lo + hi) >> 1; if (cum[mid] <= s) lo = mid; else hi = mid; }
    var i = lo;
    var segLen = course.seg[i] || 1;
    var t = clamp((s - cum[i]) / segLen, 0, 1);
    var a = course.pts[i], b2 = course.pts[i + 1];
    var tx = (b2.x - a.x) / segLen, ty = (b2.y - a.y) / segLen;
    var nx = -ty, ny = tx;
    if (ny < 0) { nx = -nx; ny = -ny; }
    var w = course.w[i] + (course.w[i + 1] - course.w[i]) * t;
    return { x: a.x + (b2.x - a.x) * t, y: a.y + (b2.y - a.y) * t, tx: tx, ty: ty, nx: nx, ny: ny, w: w, i: i };
  }

  /* ========================= 比赛（单轮） ========================= */

  /** Fisher-Yates（用固定种子 PRNG，保证可复现） */
  function shuffled(n, rnd) {
    var a = [];
    for (var i = 0; i < n; i++) a.push(i);
    for (var j = n - 1; j > 0; j--) {
      var k = Math.floor(rnd() * (j + 1));
      var t = a[j]; a[j] = a[k]; a[k] = t;
    }
    return a;
  }

  function createRace(opts) {
    var course = opts.course;
    var players = opts.players;
    var kind = opts.kind;
    var seed = opts.seed >>> 0;

    // 起跑位置：按 course.spawn 的分排结构布局。
    // 旧实现是「在整条起跑宽度上全范围随机 + 向左推开 + 整体平移」：随机点偏在一侧时，
    // 推开会把最后一个点顶出边界、再整体左移，最边的球被挤出起跑竖井（实测 |lat| 达 815，
    // 而竖井半宽只有 720）—— 球一出生就在墙外，这是"横向贴墙"的直接原因之一。
    // 现在改成：每排内把槽位等分，每球只在自己的格子内小幅随机（抖动上限取
    // (槽距 − 球直径 − 4)/2，保证任意两球间距 ≥ 球直径 + 4），再由 shuffled() 决定
    // 「哪个球去哪个槽位」—— 位置随机性仍然保留，但球一定落在起跑竖井内。
    var laneRnd = mulberry32((seed ^ 0x5EEDBEEF ^ (kind === 'final' ? 0x7F4A7C15 : 0)) >>> 0);
    var spawnSlots = (function () {
      var n = players.length;
      var rows = [];
      for (var i = 0; i < course.spawn.length; i++) {
        var sp0 = course.spawn[i];
        var last = rows[rows.length - 1];
        if (!last || Math.abs(last.y - sp0.y) > 1) { last = { y: sp0.y, xs: [] }; rows.push(last); }
        last.xs.push(sp0.x);
      }
      var order = shuffled(n, laneRnd);
      var out = new Array(n);
      var slot = 0, r, k;
      for (r = 0; r < rows.length; r++) {
        var xs = rows[r].xs, m = xs.length;
        var step = m > 1 ? (xs[m - 1] - xs[0]) / (m - 1) : 0;
        var jit = m > 1 ? Math.max(0, (step - (BALL_R * 2 + 4)) * 0.5) : 0;
        for (k = 0; k < m && slot < n; k++) {
          var x = m > 1 ? xs[k] + (laneRnd() * 2 - 1) * jit : xs[0];
          out[order[slot]] = { x: x, y: rows[r].y };
          slot++;
        }
      }
      // 兜底：槽位比球少时（名单被改过）剩下的球并到第一排
      for (; slot < n; slot++) out[order[slot]] = { x: rows[0].xs[0], y: rows[0].y };
      return out;
    }());

    var balls = players.map(function (p, idx) {
      var slot = idx;
      var sp = spawnSlots[idx];
      return {
        idx: idx, slot: slot, qq: p.qq, name: p.name, role: p.role,
        x: sp.x, y: sp.y, vx: 0, vy: 0, r: BALL_R,
        m: BALL_M, I: BALL_I,            // 质量与转动惯量：所有球完全一致（公平性）
        w: 0, angle: 0,                  // 角速度（逆时针为正，rad/s）与累计转角（渲染用）
        contact: false, contactMag: 0, contactN: { x: 0, y: 1 },   // 本步接触状态与主接触法线
        cursor: 0, progress: 0, best: 0, lat: 0,
        alive: true, dying: false, dieT: 0, dieVx: 0, dieVy: 0, dieRot: 0,
        finished: false, finishT: 0, rank: 0,
        stuckT: 0, lowSpdT: 0, lastBest: 0, rescued: 0, lastHit: -9, boostFx: -9,
        obstacleHits: 0, obstacleBlocks: 0, lastObstacleT: -9, lastBlockT: -9,
      };
    });
    balls.forEach(function (b) {
      var q = nearestOnCenterline(course, b.x, b.y, 0, course.pts.length);
      b.cursor = q.i; b.progress = q.s; b.best = q.s; b.lat = q.lat; b.lastBest = q.s;
    });

    var race = {
      kind: kind, course: course, seed: seed, balls: balls, players: players,
      t: 0, phase: 'countdown', countdown: 3.0, raceTime: 0,
      events: [], eliminations: [], cuts: [], vfx: [], rescueLog: [],
      finishedOrder: [], firstFinishT: -1, done: false, standings: null, reason: '',
      maxSpeedHits: 0,      // MAX_SPEED 保险触发的子步数（应接近 0）
      stat: { n: 0, sum: 0, sumSq: 0, air: 0, steps: 0, hist: new Int32Array(HIST_N) },
    };
    course.elims.forEach(function (e) { e.done = false; });
    course.levels.forEach(function (lv) { lv.announced = false; });

    function log(type, text, ball) {
      race.events.push({ t: race.raceTime, type: type, text: text, qq: ball ? ball.qq : null, ball: ball ? ball.idx : -1 });
      if (race.events.length > 160) race.events.splice(0, race.events.length - 160);
    }
    race.log = log;

    /* ===================== 统一接触求解（冲量法） =====================
     * 墙 / 胶囊障碍 / 圆钉 / 弹射蘑菇 / 球与球 全部走这里，不再有各自的反射系数。
     * 一次接触包含：位置修正 → 法向冲量（含速度相关恢复系数）→ 切向库仑摩擦（耦合转动）。
     * 切向摩擦同时改线速度和角速度，所以球撞墙会被带转、在地面上会从滑动自然过渡到纯滚动。
     */

    /** 恢复系数随碰撞速度变化：低速视为静止接触，避免球在地面上一直小幅弹跳 */
    function restitutionFor(e, vnAbs) {
      if (vnAbs < E_STATIC) return 0;
      if (vnAbs < E_KNEE) return e * (vnAbs - E_STATIC) / (E_KNEE - E_STATIC);
      return e;
    }

    /** 记录「最主要的接触」：法线 + 冲量大小，供下一步的滚动阻力使用 */
    function noteContact(b, nx, ny, jn) {
      var mg = Math.abs(jn);
      if (!b.contact || mg > b.contactMag) {
        b.contactN.x = nx; b.contactN.y = ny; b.contactMag = mg;
      }
      b.contact = true;
    }

    /**
     * 球 vs 静态/运动障碍的统一接触求解。
     *   n     单位法线，指向「把球推离障碍」的方向
     *   pen   穿透深度
     *   svx/svy 接触点处障碍自身的速度（旋转挡板 / 风车 / 摆锤 / 平台的线速度）
     *   mat   MATERIALS 中的材质（e 恢复系数、μ 摩擦系数）
     * 返回 { jn, jt, vn }；jn 同时用于撞击特效强度。
     */
    function resolveBallContact(b, nx, ny, pen, svx, svy, mat) {
      var beforeVx = b.vx, beforeVy = b.vy;
      var corr = (pen - PEN_SLOP) * PEN_CORRECT;
      if (corr > 0) { b.x += nx * corr; b.y += ny * corr; }
      var rx = -nx * b.r, ry = -ny * b.r;                 // 接触点相对球心
      var pvx = b.vx + b.w * (-ry), pvy = b.vy + b.w * rx; // 球在接触点处的速度 = v + ω×r
      var rvx = pvx - svx, rvy = pvy - svy;
      var vn = rvx * nx + rvy * ny;
      var res = { jn: 0, jt: 0, vn: vn };
      if (vn >= 0) return res;                            // 正在分离
      var e = restitutionFor(mat.e, -vn);
      var jn = -(1 + e) * vn * b.m;
      b.vx += nx * jn / b.m; b.vy += ny * jn / b.m;
      res.jn = jn;
      var tx = -ny, ty = nx;
      pvx = b.vx + b.w * (-ry); pvy = b.vy + b.w * rx;
      var vt = (pvx - svx) * tx + (pvy - svy) * ty;
      var kt = 1 / b.m + (b.r * b.r) / b.I;
      var jt = -vt / kt;
      var maxJt = mat.mu * Math.abs(jn);
      if (jt > maxJt) jt = maxJt; else if (jt < -maxJt) jt = -maxJt;
      b.vx += tx * jt / b.m; b.vy += ty * jt / b.m;
      b.w += (rx * (ty * jt) - ry * (tx * jt)) / b.I;     // 2D 叉积 r × (jt·t)
      res.jt = jt;
      noteContact(b, nx, ny, jn);
      if (mat !== MATERIALS.bumper) recordObstacleImpact(b, beforeVx, beforeVy, mat, jn);
      if (Math.abs(vn) > VFX_VN && race.raceTime - b.lastHit > 0.09) {
        b.lastHit = race.raceTime;
        race.vfx.push({
          type: 'hit', x: b.x - nx * b.r, y: b.y - ny * b.r,
          power: clamp(Math.abs(jn) / 700, 0, 1.4), t: race.raceTime,
        });
      }
      return res;
    }

    // 明显的真实障碍碰撞；墙和球球排除，同一接触子步去重，减速统计与画面特效无关。
    function recordObstacleImpact(b, beforeVx, beforeVy, mat, jn) {
      if (mat !== MATERIALS.wall && jn >= 80) {
        if (race.raceTime - b.lastObstacleT >= 0.1) {
          b.obstacleHits++; b.lastObstacleT = race.raceTime;
        }
        if (race.raceTime - b.lastBlockT < 0.1) return;
        var cf = frameAt(course, b.progress);
        var forwardBefore = beforeVx * cf.tx + beforeVy * cf.ty;
        var forwardAfter = b.vx * cf.tx + b.vy * cf.ty;
        if (forwardBefore > 80 && forwardBefore - forwardAfter >= 60 && race.raceTime - b.lastBlockT >= 0.1) {
          b.obstacleBlocks++; b.lastBlockT = race.raceTime;
        }
      }
    }

    /* ---------- 管道约束（球永远滚不出赛道） ---------- */

    function channelConstrain(b, iterations) {
      for (var it = 0; it < iterations; it++) {
        var q = nearestOnCenterline(course, b.x, b.y, b.cursor, 50);
        b.cursor = q.i;
        b.lat = q.lat;
        if (q.s > b.progress) b.progress = q.s;
        if (q.s > b.best) b.best = q.s;
        var wNode = course.w[q.i] + (course.w[Math.min(q.i + 1, course.w.length - 1)] - course.w[q.i]) * q.t - b.r;
        if (wNode < 6) wNode = 6;
        var dx = b.x - q.px, dy = b.y - q.py;
        var d = hypot(dx, dy);
        if (d <= wNode) return;
        var nx, ny;
        if (d < 1e-6) { nx = 0; ny = 1; d = 1e-6; } else { nx = dx / d; ny = dy / d; }
        // 法线取「把球推回管道内侧」的方向
        resolveBallContact(b, -nx, -ny, d - wNode, 0, 0, MATERIALS.wall);
      }
    }

    /* ---------- 球 vs 胶囊（挡板 / 风车 / 摆锤 / 平台共用） ---------- */

    function capsuleContact(b, cx, cy, ax, ay, bx2, by2, rad, vcx, vcy, omega, mat) {
      var dx = bx2 - ax, dy = by2 - ay;
      var L2 = dx * dx + dy * dy;
      var t = L2 > 1e-9 ? ((b.x - ax) * dx + (b.y - ay) * dy) / L2 : 0;
      t = clamp(t, 0, 1);
      var px = ax + dx * t, py = ay + dy * t;
      var ddx = b.x - px, ddy = b.y - py;
      var d = hypot(ddx, ddy);
      var rr = b.r + rad;
      if (d >= rr) return false;
      var nx, ny;
      if (d < 1e-6) { nx = 0; ny = -1; d = 1e-6; } else { nx = ddx / d; ny = ddy / d; }
      var svx = vcx, svy = vcy;
      if (omega) { svx += -omega * (py - cy); svy += omega * (px - cx); }   // 刚体旋转在接触点的线速度
      resolveBallContact(b, nx, ny, rr - d, svx, svy, mat);
      return true;
    }

    /* ---------- 受力积分（半隐式欧拉） ----------
     * 空中（contact=false）：只受重力 + 空气阻力 a = (0,g) − k_air·|v|·v
     * 接触（contact=true）：再叠加滚动阻力 c_roll·|N|/m（方向与接触点切向速度相反）
     *                       与泥沼的额外切向阻尼。
     * 注意：空气阻力永远生效；滚动阻力只在接触时生效 —— 空中经过泥沼不会减速。 */

    function integrateForces(b, dt) {
      var sp = hypot(b.vx, b.vy);
      var kd = K_AIR * sp;
      var ax = -kd * b.vx;
      var ay = GRAVITY - kd * b.vy;

      if (b.contact) {
        var n = b.contactN;
        var rollMul = course.rollFric[clamp(b.cursor, 0, course.rollFric.length - 1)] || 1;
        var Nn = GRAVITY * Math.abs(n.y);        // |N|/m = g·|n_y|
        var fr = ROLL_FRIC * rollMul * Nn;
        var vnu = b.vx * n.x + b.vy * n.y;
        var ttx = b.vx - vnu * n.x, tty = b.vy - vnu * n.y;
        var tsp = hypot(ttx, tty);
        if (tsp > 1e-6) {
          var fmag = fr + (rollMul > 1.5 ? MUD_TAN_DAMP * tsp : 0);
          ax -= fmag * ttx / tsp;
          ay -= fmag * tty / tsp;
        }
      }
      b.vx += ax * dt;
      b.vy += ay * dt;

      var sp2 = hypot(b.vx, b.vy);
      if (sp2 > MAX_SPEED) {                    // 数值保险，正常比赛不应触发
        b.vx *= MAX_SPEED / sp2; b.vy *= MAX_SPEED / sp2;
        race.maxSpeedHits++;
      }
    }

    /* ---------- 球与球：等质量冲量交换（动量守恒、动能不增） ---------- */

    function resolveBallBall(a, b) {
      var dx = b.x - a.x, dy = b.y - a.y;
      var d = hypot(dx, dy);
      var rr = a.r + b.r;
      if (d >= rr || d < 1e-9) return;
      var nx = dx / d, ny = dy / d;
      var corr = (rr - d - PEN_SLOP) * 0.7 * PEN_CORRECT;
      if (corr > 0) { a.x -= nx * corr; a.y -= ny * corr; b.x += nx * corr; b.y += ny * corr; }
      var rax = nx * a.r, ray = ny * a.r;
      var rbx = -nx * b.r, rby = -ny * b.r;
      var pavx = a.vx + a.w * (-ray), pavy = a.vy + a.w * rax;
      var pbvx = b.vx + b.w * (-rby), pbvy = b.vy + b.w * rbx;
      var rvx = pbvx - pavx, rvy = pbvy - pavy;
      var vn = rvx * nx + rvy * ny;
      if (vn >= 0) return;
      var mat = MATERIALS.ball;
      var e = restitutionFor(mat.e, -vn);
      var jn = -(1 + e) * vn / (1 / a.m + 1 / b.m);
      a.vx -= nx * jn / a.m; a.vy -= ny * jn / a.m;
      b.vx += nx * jn / b.m; b.vy += ny * jn / b.m;
      var tx = -ny, ty = nx;
      pavx = a.vx + a.w * (-ray); pavy = a.vy + a.w * rax;
      pbvx = b.vx + b.w * (-rby); pbvy = b.vy + b.w * rbx;
      var vt = (pbvx - pavx) * tx + (pbvy - pavy) * ty;
      var zta = rax * ty - ray * tx, ztb = rbx * ty - rby * tx;
      var kt = 1 / a.m + 1 / b.m + (zta * zta) / a.I + (ztb * ztb) / b.I;
      var jt = -vt / kt;
      var maxJt = mat.mu * Math.abs(jn);
      if (jt > maxJt) jt = maxJt; else if (jt < -maxJt) jt = -maxJt;
      a.vx -= tx * jt / a.m; a.vy -= ty * jt / a.m;
      b.vx += tx * jt / b.m; b.vy += ty * jt / b.m;
      a.w += (rax * (-ty * jt) - ray * (-tx * jt)) / a.I;
      b.w += (rbx * (ty * jt) - rby * (tx * jt)) / b.I;
      var power = clamp(Math.abs(jn) / 550, 0, 1.2);
      if (power > 0.18 && race.raceTime - a.lastHit > 0.12) {
        a.lastHit = race.raceTime;
        race.vfx.push({ type: 'hit', x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, power: power * 0.8, t: race.raceTime });
      }
    }

    /* ---------- 场景物件预处理 ---------- */

    /* ---------- 场景物件预处理 ---------- */

    /* 所有障碍都用「相对本关起点的真实弧长 sOff」定位（构建时由 Builder.arcLen 精确记录），
     * 不再用 sFrac 估算 —— 凹坑 / 波浪会让估算偏差好几个百分点。 */
    function objS(o) { return course.levels[o.lv - 1].s0 + o.sOff; }
    function buildDynamicObjects() {
      var objs = course.objects;
      objs.bars.forEach(function (bar) {
        var f = frameAt(course, objS(bar));
        bar.cx = f.x + f.nx * bar.lat;
        bar.cy = f.y + f.ny * bar.lat;
      });
      objs.plats.forEach(function (p) {
        var f = frameAt(course, objS(p));
        p.bx = f.x; p.by = f.y;
        p.nx = f.nx; p.ny = f.ny; p.tx = f.tx; p.ty = f.ty;
      });
      objs.boosts.forEach(function (g) {
        g.s0 = objS(g);
        g.s1 = g.s0 + g.len;
        var f = frameAt(course, g.s0 + g.len * 0.5);
        g.cx = f.x + f.nx * g.lat; g.cy = f.y + f.ny * g.lat;
        g.nxs = f.nx; g.nys = f.ny; g.txs = f.tx; g.tys = f.ty; g.midS = g.s0 + g.len * 0.5;
      });
      objs.pegs.forEach(function (pg) {
        var f = frameAt(course, objS(pg));
        pg.cx = f.x + f.nx * pg.lat; pg.cy = f.y + f.ny * pg.lat;
        pg.s = objS(pg);
      });
      objs.pendulums.forEach(function (pd) {
        var f = frameAt(course, objS(pd));
        pd.px = f.x + f.nx * pd.lat;
        pd.py = f.y + f.ny * pd.lat;
        pd.rx = f.nx; pd.ry = f.ny;              // 静止时指向地板
        pd.amp = (pd.ampDeg || 45) * DEG;
        pd.w = 2 * Math.PI / (pd.period || 2.6);
      });
      objs.mills.forEach(function (m) {
        var f = frameAt(course, objS(m));
        m.cx = f.x + f.nx * m.lat; m.cy = f.y + f.ny * m.lat;
      });
      objs.bumpers.forEach(function (bp) {
        var f = frameAt(course, objS(bp));
        bp.cx = f.x + f.nx * bp.lat; bp.cy = f.y + f.ny * bp.lat;
      });
      course.levels.forEach(function (lv) { lv.frame = frameAt(course, lv.s0 + 70); });
    }
    buildDynamicObjects();
    race.objects = course.objects;

    function applyObjects(b, dt, t) {
      var objs = course.objects, i;
      for (i = 0; i < objs.bars.length; i++) {
        var bar = objs.bars[i];
        var ang = bar.phase + bar.omega * t;
        var ca = Math.cos(ang), sa = Math.sin(ang);
        capsuleContact(b, bar.cx, bar.cy,
          bar.cx - ca * bar.half, bar.cy - sa * bar.half,
          bar.cx + ca * bar.half, bar.cy + sa * bar.half,
          bar.thick, 0, 0, bar.omega, MATERIALS.spinner);
      }
      for (i = 0; i < objs.plats.length; i++) {
        var p = objs.plats[i];
        var ph = (t / p.period) * Math.PI * 2 + p.phase;
        var off = Math.sin(ph) * p.amp;
        var voff = Math.cos(ph) * p.amp * (Math.PI * 2 / p.period);
        var mx, my, mvx, mvy;
        if (p.axis === 'tan') {                       // 沿切线往复（横扫推杆）
          mx = p.bx + p.tx * (p.lat + off); my = p.by + p.ty * (p.lat + off);
          mvx = p.tx * voff; mvy = p.ty * voff;
        } else {                                      // 沿法线往复（升降台 / 闸门）
          mx = p.bx + p.nx * (p.lat + off); my = p.by + p.ny * (p.lat + off);
          mvx = p.nx * voff; mvy = p.ny * voff;
        }
        var axx = p.orient === 'normal' ? p.nx : p.tx;   // 本体长轴方向
        var ayy = p.orient === 'normal' ? p.ny : p.ty;
        capsuleContact(b, mx, my,
          mx - axx * p.half, my - ayy * p.half,
          mx + axx * p.half, my + ayy * p.half,
          p.thick, mvx, mvy, 0, MATERIALS.platform);
      }
      // 摆锤：枢轴固定，锤头随 θ=A·sin(ωt+φ) 摆动
      for (i = 0; i < objs.pendulums.length; i++) {
        var pd = objs.pendulums[i];
        var ph2 = pd.w * t + pd.phase;
        var thp = pd.amp * Math.sin(ph2);
        var omg = pd.amp * pd.w * Math.cos(ph2);
        var cp = Math.cos(thp), sp2 = Math.sin(thp);
        var ddx = pd.rx * cp - pd.ry * sp2;
        var ddy = pd.rx * sp2 + pd.ry * cp;
        capsuleContact(b, pd.px, pd.py, pd.px, pd.py,
          pd.px + ddx * pd.arm, pd.py + ddy * pd.arm,
          pd.thick, 0, 0, omg, MATERIALS.spinner);
      }
      // 风车：同一圆心 n 根挡板，相位相差 2π/n
      for (i = 0; i < objs.mills.length; i++) {
        var ml = objs.mills[i];
        for (var arm = 0; arm < ml.arms; arm++) {
          var ang2 = ml.phase + ml.omega * t + arm * 2 * Math.PI / ml.arms;
          var c1 = Math.cos(ang2), s1 = Math.sin(ang2);
          capsuleContact(b, ml.cx, ml.cy,
            ml.cx - c1 * ml.half, ml.cy - s1 * ml.half,
            ml.cx + c1 * ml.half, ml.cy + s1 * ml.half,
            ml.thick, 0, 0, ml.omega, MATERIALS.spinner);
        }
      }
      // 弹射蘑菇：统一接触求解（恢复系数见材质表），kick 与侧向偏转在求解之后单独叠加
      for (i = 0; i < objs.bumpers.length; i++) {
        var bp = objs.bumpers[i];
        var kdx = b.x - bp.cx, kdy = b.y - bp.cy;
        var kd = hypot(kdx, kdy), krr = b.r + bp.r;
        if (kd < krr && kd > 1e-6) {
          var knx = kdx / kd, kny = kdy / kd;
          var beforeBumpVx = b.vx, beforeBumpVy = b.vy;
          var bumpContact = resolveBallContact(b, knx, kny, krr - kd, 0, 0, MATERIALS.bumper);
          if (race.raceTime - (b.bumpT || -9) > 0.25) {
            b.bumpT = race.raceTime;
            b.vx += knx * bp.kick; b.vy += kny * bp.kick;
            var fb = frameAt(course, b.progress);
            var side = b.lat > 0 ? -1 : 1;
            b.vx += fb.nx * side * 210; b.vy += fb.ny * side * 210;
            var ksp = hypot(b.vx, b.vy);
            if (ksp > MAX_SPEED) { b.vx *= MAX_SPEED / ksp; b.vy *= MAX_SPEED / ksp; race.maxSpeedHits++; }
            b.lastHit = race.raceTime;
            race.vfx.push({ type: 'bumper', x: bp.cx + knx * bp.r, y: bp.cy + kny * bp.r, idx: i, power: 0.9, t: race.raceTime });
          }
          recordObstacleImpact(b, beforeBumpVx, beforeBumpVy, MATERIALS.bumper, bumpContact.jn);
        }
      }
      // 圆钉
      for (i = 0; i < objs.pegs.length; i++) {
        var pg = objs.pegs[i];
        var pgdx = b.x - pg.cx, pgdy = b.y - pg.cy;
        var pgd = hypot(pgdx, pgdy), pgrr = b.r + pg.r;
        if (pgd < pgrr && pgd > 1e-6) {
          var pnx = pgdx / pgd, pny = pgdy / pgd;
          var rc = resolveBallContact(b, pnx, pny, pgrr - pgd, 0, 0, MATERIALS.peg);
          if (rc.jn !== 0 && race.raceTime - b.lastHit > 0.12) {
            b.lastHit = race.raceTime;
            race.vfx.push({ type: 'peg', x: pg.cx, y: pg.cy, idx: i, power: clamp(Math.abs(rc.jn) / 500, 0.2, 1.2), t: race.raceTime });
          }
        }
      }
      // 弹簧跳板：横向带内沿切线加速
      for (i = 0; i < objs.boosts.length; i++) {
        var g = objs.boosts[i];
        if (b.progress >= g.s0 && b.progress <= g.s1 &&
            b.lat >= g.lat - g.halfW && b.lat <= g.lat + g.halfW) {
          var fg = frameAt(course, b.progress);
          b.vx += fg.tx * g.accel * dt;
          b.vy += fg.ty * g.accel * dt;
          if (race.raceTime - b.boostFx > 0.4) {
            b.boostFx = race.raceTime;
            race.vfx.push({ type: 'boost', x: b.x, y: b.y, idx: i, t: race.raceTime });
          }
        }
      }
    }

    /* ---------- 全场统计（速度分布 / 空中占比 / MAX_SPEED 触发） ---------- */

    function recordStats(list) {
      var st = race.stat;
      for (var i = 0; i < list.length; i++) {
        var b = list[i];
        var sp = hypot(b.vx, b.vy);
        var bi = (sp / HIST_BIN) | 0;
        if (bi >= HIST_N) bi = HIST_N - 1;
        if (bi < 0) bi = 0;
        st.hist[bi]++;
        st.sum += sp; st.sumSq += sp * sp; st.n++;
        if (!b.contact) st.air++;
        st.steps++;
      }
    }

    /* ---------- 卡死脱困 ---------- */
    /* 判据用「进度停滞」而不是「低速」：球在凹坑里来回振荡时速度时高时低，
       旧的低速判据永远不触发，会看到大部队永久冻在同一个坑里。 */
    function checkStuck(b, dt) {
      var spd = hypot(b.vx, b.vy);
      if (spd < STUCK_SLOW) b.lowSpdT += dt; else b.lowSpdT = 0;
      if (b.best - b.lastBest > 30) { b.lastBest = b.best; b.stuckT = 0; b.lowSpdT = 0; }
      else b.stuckT += dt;
      /* 判据 = 进度停滞 且 确实低速：球在旋转挡板 / 弹射蘑菇之间来回弹跳时速度很高，
       * 那是正常比赛行为而不是卡死；只有真的停下来才算卡住。 */
      if ((b.stuckT > STUCK_TIME && b.lowSpdT > 1.5) || b.stuckT > STUCK_HARD) {
        var f = frameAt(course, b.progress);
        // 脱困改成冲量（而不是直接覆盖速度）：沿切线 +700、沿 −n 抬离 +320
        b.vx += f.tx * 700 - f.nx * 320;
        b.vy += f.ty * 700 - f.ny * 320;
        var ksp2 = hypot(b.vx, b.vy);
        if (ksp2 > MAX_SPEED) { b.vx *= MAX_SPEED / ksp2; b.vy *= MAX_SPEED / ksp2; race.maxSpeedHits++; }
        b.stuckT = 0;
        b.lowSpdT = 0;
        b.lastBest = b.best;
        b.rescued++;
        race.rescueLog.push({ qq: b.qq, name: b.name, s: b.best, t: race.raceTime });
        race.vfx.push({ type: 'rescue', x: b.x, y: b.y, t: race.raceTime });
        log('rescue', b.name + ' 停滞 3 秒 → 脱困弹射', b);
      }
    }

    /* ---------- 淘汰 / 终点 ---------- */

    function aliveBalls() {
      var out = [];
      for (var i = 0; i < balls.length; i++) if (balls[i].alive) out.push(balls[i]);
      return out;
    }

    function doCut(line) {
      line.done = true;
      var alive = aliveBalls();
      alive.sort(function (a, b) {
        if (b.best !== a.best) return b.best - a.best;
        return a.idx - b.idx;
      });
      var n = Math.min(CUT_SIZE, Math.max(0, alive.length - 1));
      var out = alive.slice(alive.length - n);
      out.sort(function (a, b) { return a.idx - b.idx; });
      var names = [];
      out.forEach(function (b) {
        b.alive = false;
        b.dying = true;
        b.dieT = 0;
        b.dieVx = b.vx * 0.5;
        b.dieVy = b.vy * 0.3 - 130;
        b.dieRot = 0;
        race.eliminations.push({
          qq: b.qq, name: b.name, role: b.role,
          order: race.eliminations.length + 1,
          round: line.round, afterLevel: line.afterLevel,
          t: race.raceTime, progress: b.best,
        });
        race.vfx.push({ type: 'elim', x: b.x, y: b.y, idx: b.idx, t: race.raceTime });
        log('elim', b.name + ' 被淘汰', b);
        names.push(b.name);
      });
      race.cuts.push({
        round: line.round, afterLevel: line.afterLevel, t: race.raceTime,
        out: out.map(function (b) { return { qq: b.qq, name: b.name, role: b.role }; }),
        aliveAfter: aliveBalls().length,
      });
      log('cut', '第 ' + line.round + ' 轮淘汰（第 ' + line.afterLevel + ' 关终点）：' + names.join(' / ') + ' 出局', null);
    }

    function checkProgress() {
      var i, k;
      var alive = aliveBalls();
      for (i = 0; i < course.levels.length; i++) {
        var lv = course.levels[i];
        if (lv.announced) continue;
        for (k = 0; k < alive.length; k++) {
          if (alive[k].best >= lv.s0 + 30) {
            lv.announced = true;
            log('level', alive[k].name + ' 率先进入 第 ' + lv.no + ' 关「' + lv.name + '」', alive[k]);
            break;
          }
        }
      }
      for (i = 0; i < course.elims.length; i++) {
        var line = course.elims[i];
        if (line.done) continue;
        for (k = 0; k < alive.length; k++) {
          if (alive[k].best >= line.s) { doCut(line); break; }
        }
      }
      for (i = 0; i < balls.length; i++) {
        var b = balls[i];
        if (!b.alive || b.finished) continue;
        if (b.best >= course.finishS - 1) {
          b.finished = true;
          b.finishT = race.raceTime;
          race.finishedOrder.push(b.idx);
          b.rank = race.finishedOrder.length;
          log('finish', b.name + ' 冲过终点（第 ' + race.finishedOrder.length + ' 名）', b);
          race.vfx.push({ type: 'finish', x: b.x, y: b.y, idx: b.idx, t: race.raceTime });
          if (race.firstFinishT < 0) race.firstFinishT = race.raceTime;
        }
      }
    }

    function endRound(reason) {
      if (race.done) return;
      race.done = true;
      race.phase = 'done';
      race.reason = reason;
      var rest = race.balls.filter(function (b) { return b.alive && !b.finished; });
      rest.sort(function (a, b) { return b.best - a.best; });
      race.standings = {
        finished: race.finishedOrder.slice(),
        rest: rest.map(function (b) { return b.idx; }),
      };
    }

    /* ---------- 单步推进 ---------- */

    race.step = function () {
      if (race.phase === 'countdown') {
        race.countdown -= DT;
        if (race.countdown <= 0) {
          race.phase = 'racing';
          log('go', race.kind === 'qualifier' ? '预赛开始！18 球同时出发' : '决赛开始！3 球争冠', null);
        }
        return;
      }
      if (race.phase !== 'racing') return;

      race.t += DT;
      race.raceTime += DT;

      var i, j, b;
      var alive = aliveBalls();
      /* 子步数只由当前状态（最快球速）决定 —— 没有随机、没有计时，
       * 所以同一 seed 仍然逐字节可复现。每个子步位移 ≤ 0.35·r ≈ 11.9，薄障碍也不会被穿透。 */
      var maxSp = 0;
      for (i = 0; i < alive.length; i++) {
        var si = hypot(alive[i].vx, alive[i].vy);
        if (si > maxSp) maxSp = si;
      }
      var sub = clamp(Math.ceil(maxSp * DT / SUB_TRAVEL), 1, SUB_MAX) | 0;
      var sdt = DT / sub;
      for (var k = 0; k < sub; k++) {
        var st = race.t + sdt * (k + 1);
        // 注意顺序：积分用的是「上一步结束时」的接触状态，所以 contact 必须在
        // 位置更新之后、碰撞求解之前清零 —— 否则滚动阻力永远不会生效。
        for (i = 0; i < alive.length; i++) integrateForces(alive[i], sdt);      // 1) 速度
        for (i = 0; i < alive.length; i++) {                                    // 2) 位置 + 转角
          b = alive[i];
          b.x += b.vx * sdt; b.y += b.vy * sdt; b.angle += b.w * sdt;
        }
        for (i = 0; i < alive.length; i++) { alive[i].contact = false; alive[i].contactMag = 0; }
        for (i = 0; i < alive.length; i++) {                                    // 3) 管道约束 + 障碍
          b = alive[i];
          channelConstrain(b, 2);
          applyObjects(b, sdt, st);
          channelConstrain(b, 1);
        }
        for (i = 0; i < alive.length; i++) {                                    // 4) 球与球
          for (j = i + 1; j < alive.length; j++) resolveBallBall(alive[i], alive[j]);
        }
        recordStats(alive);                                                     // 5) 统计
      }
      for (i = 0; i < alive.length; i++) checkStuck(alive[i], DT);
      for (i = 0; i < balls.length; i++) {
        b = balls[i];
        if (!b.dying) continue;
        b.dieT += DT;
        b.dieVy += GRAVITY * 1.1 * DT;
        b.x += b.dieVx * DT;
        b.y += b.dieVy * DT;
        b.dieRot += DT * 7;
        if (b.dieT > DEATH_TIME) b.dying = false;
      }
      checkProgress();

      if (race.kind === 'qualifier') {
        var left = aliveBalls().filter(function (x) { return !x.finished; });
        if (left.length === 0 && aliveBalls().length > 0) endRound('all-finished');
      } else {
        var left2 = aliveBalls().filter(function (x) { return !x.finished; });
        if (left2.length === 0) endRound('all-finished');
        else if (race.firstFinishT > 0 && race.raceTime - race.firstFinishT > 18) endRound('timeout');
      }
      if (!race.done && race.raceTime > MAX_RACE_TIME) endRound('fuse');
      if (race.vfx.length > 420) race.vfx.splice(0, race.vfx.length - 420);
    };

    race.rankAlive = function () {
      var a = aliveBalls();
      a.sort(function (x, y) {
        if (y.best !== x.best) return y.best - x.best;
        return x.idx - y.idx;
      });
      return a;
    };
    race.aliveCount = function () { return aliveBalls().length; };
    race.progressPct = function (b) {
      var den = course.finishS - course.startS;
      return clamp((b.best - course.startS) / (den || 1), 0, 1);
    };
    /** 速度分布 / 空中占比 / MAX_SPEED 触发次数（验收用） */
    race.stats = function () {
      var st = race.stat;
      if (!st.n) return null;
      var mean = st.sum / st.n;
      var varr = Math.max(0, st.sumSq / st.n - mean * mean);
      var sd = Math.sqrt(varr);
      var pct = function (p) {
        var target = st.n * p, acc = 0;
        for (var i = 0; i < HIST_N; i++) {
          acc += st.hist[i];
          if (acc >= target) return (i + 0.5) * HIST_BIN;
        }
        return HIST_N * HIST_BIN;
      };
      return {
        samples: st.n, steps: st.steps,
        mean: mean, sd: sd, cv: mean > 1 ? sd / mean : 0,
        p10: pct(0.10), p50: pct(0.50), p90: pct(0.90), p99: pct(0.99),
        airRatio: st.steps ? st.air / st.steps : 0,
        maxSpeedHits: race.maxSpeedHits,
        raceTime: race.raceTime,
      };
    };
    race.snapshot = function () {
      return {
        kind: race.kind, seed: race.seed, done: race.done, reason: race.reason,
        finished: race.finishedOrder.slice(),
        eliminations: race.eliminations.map(function (e) { return e.qq; }),
        cuts: race.cuts.map(function (c) { return c.out.map(function (o) { return o.qq; }); }),
        progress: race.balls.map(function (b) { return Math.round(b.best * 1000) / 1000; }),
        raceTime: Math.round(race.raceTime * 1000) / 1000,
      };
    };
    return race;
  }

  /* ========================= 整场比赛 ========================= */

  function createMatch(opts) {
    var players = opts.players;
    var seed = opts.seed >>> 0;
    var match = {
      players: players, seed: seed, stage: 'qualifier',
      race: null, finalRace: null, interT: 0, standings: null,
      cutLog: [], finalists: [],
    };

    match.race = createRace({
      course: buildCourse(seed, 'qualifier'), players: players, seed: seed, kind: 'qualifier',
    });

    match.step = function () {
      if (match.stage === 'qualifier') {
        match.race.step();
        if (match.race.done) {
          match.finalists = match.race.balls.filter(function (b) { return b.alive; })
            .map(function (b) { return b.qq; }).slice(0, 3);
          match.cutLog = match.race.cuts.map(function (c) { return { round: c.round, out: c.out.slice() }; });
          match.stage = 'intermission';
          match.interT = 2.6;
        }
      } else if (match.stage === 'intermission') {
        match.interT -= DT;
        if (match.interT <= 0) {
          var fp = match.players.filter(function (p) { return match.finalists.indexOf(p.qq) >= 0; });
          fp.sort(function (a, b) { return match.finalists.indexOf(a.qq) - match.finalists.indexOf(b.qq); });
          match.finalRace = createRace({
            course: buildCourse(seed, 'final'), players: fp, seed: seed, kind: 'final',
          });
          match.stage = 'final';
        }
      } else if (match.stage === 'final') {
        match.finalRace.step();
        if (match.finalRace.done) {
          match.buildStandings();
          match.stage = 'done';
        }
      }
    };

    match.currentRace = function () {
      return (match.stage === 'final' || match.stage === 'done') && match.finalRace ? match.finalRace : match.race;
    };

    match.buildStandings = function () {
      var i;
      var ranking = [];
      var fin = match.finalRace.finishedOrder.slice();
      var finalAlive = match.finalRace.balls.slice();
      finalAlive.sort(function (a, b) {
        var ia = fin.indexOf(a.idx), ib = fin.indexOf(b.idx);
        if (ia >= 0 && ib >= 0) return ia - ib;
        if (ia >= 0) return -1;
        if (ib >= 0) return 1;
        return b.best - a.best;
      });
      finalAlive.forEach(function (b, k) {
        ranking.push({
          qq: b.qq, name: b.name, role: b.role, rank: k + 1, stage: 'final',
          finished: b.finished, time: b.finished ? b.finishT : null,
        });
      });
      var elims = match.race.eliminations;
      for (i = elims.length - 1; i >= 0; i--) {
        var e = elims[i];
        ranking.push({
          qq: e.qq, name: e.name, role: e.role,
          rank: 4 + (elims.length - 1 - i), stage: 'qualifier',
          cutRound: e.round, afterLevel: e.afterLevel, progress: e.progress, time: e.t,
        });
      }
      players.forEach(function (p) {
        if (!ranking.some(function (r) { return r.qq === p.qq; })) {
          ranking.push({ qq: p.qq, name: p.name, role: p.role, rank: ranking.length + 1, stage: 'unknown' });
        }
      });
      ranking.sort(function (a, b) { return a.rank - b.rank; });
      match.standings = ranking;
    };

    /** 无渲染直接跑完（校验 / 快进用），返回步数 */
    match.runToEnd = function (maxSteps) {
      var steps = 0, cap = maxSteps || 400000;
      while (match.stage !== 'done' && steps < cap) { match.step(); steps++; }
      if (match.stage === 'done' && !match.standings) match.buildStandings();
      return steps;
    };
    match.snapshot = function () {
      return {
        seed: match.seed,
        qualifier: match.race ? match.race.snapshot() : null,
        final: match.finalRace ? match.finalRace.snapshot() : null,
        standings: match.standings ? match.standings.map(function (r) { return r.qq; }) : null,
      };
    };
    return match;
  }

  function buildCourse(seed, kind) {
    return kind === 'final' ? buildFinal(seed >>> 0) : buildQualifier(seed >>> 0);
  }

  /* ========================= 导出 ========================= */

  global.PeppaSim = {
    getAirDrag: function () { return K_AIR; },
    DT: DT, BALL_R: BALL_R, GRAVITY: GRAVITY, WORLD_W: WORLD_W,
    BALL_M: BALL_M, BALL_I: BALL_I, K_AIR: K_AIR, MAX_SPEED: MAX_SPEED,
    ROLL_FRIC: ROLL_FRIC, MUD_ROLL_MUL: MUD_ROLL_MUL, MUD_TAN_DAMP: MUD_TAN_DAMP,
    SUB_TRAVEL: SUB_TRAVEL, SUB_MAX: SUB_MAX, E_STATIC: E_STATIC, E_KNEE: E_KNEE,
    PEN_SLOP: PEN_SLOP, PEN_CORRECT: PEN_CORRECT, MATERIALS: MATERIALS,
    CUT_SIZE: CUT_SIZE, CUT_COUNT: CUT_COUNT, DEATH_TIME: DEATH_TIME,
    MAX_RACE_TIME: MAX_RACE_TIME, STUCK_TIME: STUCK_TIME, STUCK_SLOW: STUCK_SLOW, STUCK_HARD: STUCK_HARD,
    mulberry32: mulberry32,
    buildCourse: buildCourse,
    createRace: createRace,
    createMatch: createMatch,
    frameAt: frameAt,
    nearestOnCenterline: nearestOnCenterline,
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);

(function (global) { global.PeppaSimVersions = global.PeppaSimVersions || {}; global.PeppaSimVersions['recording-20261009-v2'] = global.PeppaSim; })(typeof window !== 'undefined' ? window : globalThis);
