/**
 * 每日观赛 · 本地联赛计算（纯静态版）
 * ---------------------------------------------------------------------------
 * 原站点靠 Cloudflare Worker + D1 保存"每天真随机 3 场"的结果。因为真随机不可复现，
 * 所以必须有服务器。现在种子改为【由北京时间日期派生】：
 *
 *     seed(day, i) = FNV1a('peppa-race:' + day + ':' + i)
 *
 * 于是任意一天（包括还没到的日期）都能离线算出结果，整站退化成纯静态：
 *   · data/league.json 由 tools/gen-league.mjs 预生成，只存名次顺序 / 种子 / 用时；
 *   · 浏览器读它并累加积分，不再请求任何接口；
 *   · 回放改为用该场种子在本地重跑物理并录制轨迹。
 *
 * ⚠️ seedFor 必须与 tools/gen-league.mjs 里的实现逐字节一致。
 */
(function () {
  'use strict';
  var START_DAY = '2026-10-09';
  var MATCHES_PER_DAY = 3;
  var SIM_VERSION = 'league-20261009-static-v1';

  /** 与 tools/gen-league.mjs 的 seedFor 完全一致（FNV-1a 32 位） */
  function seedFor(day, index) {
    var s = 'peppa-race:' + day + ':' + index;
    var h = 2166136261 >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  function beijingDay(now) {
    return new Date((now === undefined ? Date.now() : now) + 8 * 3600000).toISOString().slice(0, 10);
  }
  function nextDay(day) { return new Date(Date.parse(day + 'T00:00:00Z') + 86400000).toISOString().slice(0, 10); }
  function pointsFor(rank, size) { return size + 1 - rank; }

  var doc = null, loadPromise = null;

  function accept(json) {
    if (!json || json.version !== 1 || !json.days || !Array.isArray(json.players)) throw new Error('赛程数据格式不正确');
    doc = json;
    return doc;
  }

  function load() {
    if (loadPromise) return loadPromise;
    // 优先用 <script src="data/league.js"> 注入的数据：file:// 下浏览器禁止 fetch 本地 json，
    // 而这个站既要能部署在 http(s) 上，也要能双击本地打开调试。
    if (window.PEPPA_LEAGUE) {
      loadPromise = Promise.resolve().then(function () { return accept(window.PEPPA_LEAGUE); });
      return loadPromise;
    }
    loadPromise = fetch('data/league.json', { cache: 'no-cache' }).then(function (r) {
      if (!r.ok) throw new Error('赛程数据载入失败（HTTP ' + r.status + '）');
      return r.json();
    }).then(accept);
    return loadPromise;
  }

  /** 把紧凑的一场还原成站点需要的 standings 结构 */
  function expandMatch(dayDoc, match, number, players) {
    var day = dayDoc.day;
    var byIdx = {};
    (match.cuts || []).forEach(function (c) { c[2].forEach(function (idx) { byIdx[idx] = c[0]; }); });
    var standings = match.order.map(function (idx, i) {
      var p = players[idx];
      var rank = i + 1;
      var cutRound = byIdx[idx];
      return {
        rank: rank, qq: p.qq, name: p.name, role: p.role,
        points: pointsFor(rank, players.length),
        // 结算页按这两个字段描述结局：进决赛 / 预赛第几轮淘汰
        stage: cutRound ? 'qualifier' : 'final',
        cutRound: cutRound || 0,
      };
    });
    return {
      id: day + '-' + number, number: number, seed: match.seed, simVersion: SIM_VERSION,
      qualifierTime: match.qt, finalTime: match.ft,
      duration: Number((match.qt + 2.6 + match.ft).toFixed(3)),
      standings: standings,
      cuts: (match.cuts || []).map(function (c) { return { round: c[0], afterLevel: c[1], out: c[2].map(function (i) { return players[i].qq; }) }; }),
    };
  }

  function rankRows(rows, key) {
    rows.sort(function (a, b) { return b[key] - a[key] || a.qq.localeCompare(b.qq); });
    var previous, rank = 0;
    return rows.map(function (row, i) { if (row[key] !== previous) rank = i + 1; previous = row[key]; return Object.assign({}, row, { rank: rank }); });
  }

  /**
   * 组装某一天的 feed：
   *  · 当天三场来自预生成数据；
   *  · 今日积分 = 当天三场之和；
   *  · 累计积分 = 从 startDay 到该天所有场次之和（全部来自静态文件，无需请求）。
   */
  function buildFeed(day) {
    if (!doc) throw new Error('赛程数据尚未载入');
    var days = Object.keys(doc.days).sort();
    if (!days.length) throw new Error('赛程数据为空');
    var latest = days[days.length - 1];
    if (day > latest) throw new Error('赛程数据只预生成到 ' + latest + '，请重新运行 tools/gen-league.mjs 续算。');
    if (day < doc.startDay) throw new Error('赛季从 ' + doc.startDay + ' 开始。');
    if (!doc.days[day]) throw new Error(day + ' 这一天的比赛数据缺失。');

    var players = doc.players.map(function (p) {
      return Object.assign({}, p, { todayPoints: 0, totalPoints: 0, totalWins: 0, matchesPlayed: 0 });
    });
    var byQq = {};
    players.forEach(function (p) { byQq[p.qq] = p; });

    // 累计：从起始日算到目标日
    for (var d = doc.startDay; d <= day; d = nextDay(d)) {
      var dd = doc.days[d];
      if (!dd) continue;
      dd.forEach(function (m) {
        m.order.forEach(function (idx, i) {
          var p = players[idx];
          var pts = pointsFor(i + 1, players.length);
          p.matchesPlayed++;
          p.totalPoints += pts;
          if (i === 0) p.totalWins++;
          if (d === day) p.todayPoints += pts;
        });
      });
    }

    var matches = (doc.days[day] || []).map(function (m, i) {
      return expandMatch({ day: day }, m, i + 1, doc.players);
    });
    if (matches.length !== MATCHES_PER_DAY) throw new Error(day + ' 的比赛场数不是 ' + MATCHES_PER_DAY);

    return {
      day: day, startDay: doc.startDay, endDay: doc.endDay, timezone: 'Asia/Shanghai',
      remainingDays: 0,
      players: players,
      matches: matches,
      dailyBoard: rankRows(players.map(function (p) { return Object.assign({}, p); }), 'todayPoints'),
      totalBoard: rankRows(players.map(function (p) { return Object.assign({}, p); }), 'totalPoints'),
    };
  }

  window.PeppaLeague = Object.freeze({
    START_DAY: START_DAY, MATCHES_PER_DAY: MATCHES_PER_DAY, SIM_VERSION: SIM_VERSION,
    seedFor: seedFor, beijingDay: beijingDay, load: load, buildFeed: buildFeed,
    isReady: function () { return !!doc; },
    range: function () { return doc ? { start: doc.startDay, end: doc.endDay, days: Object.keys(doc.days).length } : null; },
  });
})();
