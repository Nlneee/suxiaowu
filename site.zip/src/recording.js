/**
 * 回放录制（浏览器版）
 * ---------------------------------------------------------------------------
 * 原来回放轨迹存在服务端（D1 的 race_recordings 表），浏览器只做插值播放。
 * 纯静态化之后改成：用该场的【确定性种子】在本地重跑一次物理并录制轨迹。
 * 因为种子由日期派生，任何人任何设备跑出来的轨迹都一致；
 * 而且播放时依然只插值、不重新求解碰撞，所以名次不会因浮点差异变化。
 *
 * 与 worker/recording.mjs 的编码格式完全一致（STRIDE=10、每 8 步一帧、15fps）。
 */
(function () {
  'use strict';
  var STRIDE = 10;
  function encode(balls) {
    var bytes = new Uint8Array(balls.length * STRIDE * 4), view = new DataView(bytes.buffer);
    balls.forEach(function (b, i) {
      var values = [b.x, b.y, b.vx, b.vy, b.angle, b.best, b.dieT, b.dieRot,
        (b.alive ? 1 : 0) | (b.dying ? 2 : 0) | (b.finished ? 4 : 0), b.finishT];
      values.forEach(function (v, j) { view.setFloat32((i * STRIDE + j) * 4, v, true); });
    });
    var s = '';
    for (var k = 0; k < bytes.length; k++) s += String.fromCharCode(bytes[k]);
    return btoa(s);
  }
  function recordMatch(match) {
    var frames = [], metas = [];
    var step = 0, oldStage = '', metaKey = '', meta = -1;
    function capture() {
      var r = match.currentRace();
      var key = r.kind + ':' + r.events.length + ':' + ((r.events[r.events.length - 1] || {}).t || 0) + ':' + r.cuts.length + ':' + r.finishedOrder.length;
      if (key !== metaKey) {
        metaKey = key; meta = metas.length;
        metas.push(JSON.parse(JSON.stringify({ events: r.events.slice(-5), eliminations: r.eliminations, cuts: r.cuts })));
      }
      frames.push({
        at: step * window.PeppaSim.DT, stage: match.stage, interT: match.interT,
        t: r.t, raceTime: r.raceTime, phase: r.phase, countdown: r.countdown, done: r.done,
        firstFinishT: r.firstFinishT, finished: r.finishedOrder.slice(), meta: meta, body: encode(r.balls),
      });
      oldStage = match.stage;
    }
    capture();
    while (match.stage !== 'done' && step < 400000) {
      match.step(); step++;
      var race = match.currentRace();
      if (step % 8 === 0 || match.stage !== oldStage || race.cuts.length !== metas[meta].cuts.length || race.finishedOrder.length !== frames[frames.length - 1].finished.length) capture();
      race.vfx.length = 0;
    }
    if (match.stage !== 'done') throw new Error('这一场没有跑完，无法生成回放');
    return {
      stride: STRIDE, fps: 15, duration: step * window.PeppaSim.DT,
      finalists: match.finalists, metas: metas, frames: frames,
    };
  }
  /** 用确定性种子本地录制一场（与官方预生成结果同源） */
  function recordBySeed(day, number, players) {
    var seed = window.PeppaLeague.seedFor(day, number - 1);
    var match = window.PeppaSim.createMatch({ seed: seed, players: players });
    var rec = recordMatch(match);
    return Object.assign({ id: day + '-' + number, seed: seed, simVersion: window.PeppaLeague.SIM_VERSION }, rec);
  }
  window.PeppaRecording = Object.freeze({ recordMatch: recordMatch, recordBySeed: recordBySeed, STRIDE: STRIDE });
})();
