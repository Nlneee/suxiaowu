(function () {
  'use strict';
  window.PEPPA_SPECTATOR = true;
  var feed = null, error = '', loading = true, tab = 'today', expanded = null, homeTimer = null;
  var VERSION = 'league-20261009-static-v1';
  var recordings = new Map(), watchPending = false;
  function esc(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function avatar(player) { return '<img class="daily-avatar" src="' + esc(player.avatar) + '" alt="" loading="lazy">'; }
  function playerOf(id) { return feed.players.filter(function (p) { return p.qq === id; })[0]; }
  function matchOf(id) { return feed && feed.matches.filter(function (m) { return m.id === id; })[0]; }
  async function watch(id) {
    if (watchPending || !matchOf(id)) return;
    watchPending = true;
    document.querySelectorAll('[data-watch]').forEach(function (button) { button.disabled = true; if (button.dataset.watch === id) button.textContent = '正在载入回放…'; });
    try {
      if (!recordings.has(id)) {
        // 纯静态版：不再向服务端要轨迹，改用该场的确定性种子在本地重跑并录制。
        // 种子由日期派生（PeppaLeague.seedFor），所以任何设备跑出的轨迹都一致；
        // 播放时仍然只插值、不重新求解碰撞，名次不会因浮点差异改变。
        var number = Number(id.slice(id.lastIndexOf('-') + 1));
        var day = id.slice(0, id.lastIndexOf('-'));
        if (!/^\d{4}-\d{2}-\d{2}$/.test(day) || !(number >= 1 && number <= 3)) throw Error('只能观看今日三场官方比赛。');
        if (!window.PeppaRecording || !window.PeppaLeague) throw Error('回放模块未能载入，请刷新后重试。');
        var recording = await new Promise(function (resolve) { setTimeout(function () { resolve(window.PeppaRecording.recordBySeed(day, number, feed.players)); }, 0); });
        if (recording.id !== id || recording.stride !== 10 || !recording.frames || recording.frames.length < 2 || recording.frames[recording.frames.length - 1].stage !== 'done') throw Error('回放数据暂不完整，请重试。');
        recordings.set(id, recording);
      }
      if (!window.PeppaPlayback.watch(id)) throw Error('这场回放暂时无法载入，请刷新后重试。');
    } catch (e) { error = e.message; renderHome(); }
    finally { watchPending = false; }
  }
  function standingsHtml(match) {
    return '<div class="daily-scroll"><table class="daily-table"><caption>第 ' + match.number + ' 场完整名次与积分</caption><thead><tr><th>名次</th><th>群友</th><th>本场积分</th><th>比赛结果</th></tr></thead><tbody>'
      + match.standings.map(function (r) {
        var player = playerOf(r.qq);
        var result = r.rank === 1 ? '冠军' : (r.stage === 'final' ? '进入决赛' : '预赛第 ' + r.cutRound + ' 轮淘汰');
        return '<tr><td>' + r.rank + '</td><td><span class="daily-person">' + avatar(player) + '<span>' + esc(r.name) + '</span></span></td><td class="daily-points">+' + r.points + '</td><td>' + result + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  function leaderboardHtml() {
    var rows = tab === 'total' ? feed.totalBoard : feed.dailyBoard;
    var key = tab === 'total' ? 'totalPoints' : 'todayPoints';
    return '<section class="daily-ranking"><div class="daily-section-head"><h2>' + (tab === 'total' ? '累计积分榜' : '今日积分榜') + '</h2><span>' + rows.length + ' 位群友</span></div><div class="daily-scroll"><table class="daily-table"><caption class="sr-only">' + (tab === 'total' ? '累计积分排名' : '今日积分排名') + '</caption><thead><tr><th>排名</th><th>群友</th><th>今日积分</th><th>总积分</th></tr></thead><tbody>'
      + rows.map(function (row, i) {
        var tied = rows.some(function (other) { return other.qq !== row.qq && other[key] === row[key]; });
        return '<tr class="' + (row.rank <= 3 ? 'daily-top' : '') + '"><td><span class="daily-rank rank-' + row.rank + '">' + row.rank + '</span>' + (tied ? '<small>并列</small>' : '') + '</td><td><span class="daily-person">' + avatar(row) + '<span>' + esc(row.name) + '</span></span></td><td class="' + (key === 'todayPoints' ? 'daily-points' : '') + '">' + row.todayPoints + '</td><td class="' + (key === 'totalPoints' ? 'daily-points' : '') + '">' + row.totalPoints + '</td></tr>';
      }).join('') + '</tbody></table></div></section>';
  }
  function rulesHtml() {
    return '<section class="daily-rules"><h2>观赛与积分规则</h2><p>北京时间每天统一生成 3 场随机比赛，18 位群友的头像小球依次闯关，预赛每轮淘汰末位 3 人，最后 3 人进入决赛。</p><p>每场按最终名次计分：第 1 名 18 分、第 2 名 17 分，依次递减，第 18 名 1 分。每日积分为三场积分之和，个人每天最多 54 分。</p><p>总积分从 ' + esc(feed.startDay) + ' 开始累计。相同积分并列排名，同分群友以固定顺序显示。重复观看、倍速和刷新不会重新比赛，也不会重复计分。</p><p>所有群友看到同一份官方结果；此网页仅供观看，不提供开局、随机种子或积分提交。</p></section>';
  }
  function renderHome() {
    var menu = document.getElementById('menu');
    if (!menu || menu.hidden) return;
    var wrap = menu.querySelector('.menu-wrap');
    if (!wrap) return;
    var html = '<header class="daily-header"><div><p class="daily-eyebrow">苏小屋 · 每日观赛</p><h1>群友大逃杀</h1><p class="daily-subtitle">每天三场，见证今日冠军。</p></div><div class="daily-date">' + (feed ? esc(feed.day) : '正在载入今日比赛') + '<small>北京时间 · 只读观赛</small></div></header>';
    if (loading && !feed) html += '<div class="daily-message" role="status">正在载入今日三场比赛和积分榜…</div>';
    else if (error) html += '<div class="daily-message" role="alert">' + esc(error) + '<button class="daily-button" id="daily-retry">重新载入</button></div>';
    if (feed) {
      if (feed.remainingDays) html += '<div class="daily-message" role="status">正在补齐 ' + feed.remainingDays + ' 天的历史比赛，总积分暂未完整，请稍候。</div>';
      html += '<section class="daily-matches" aria-label="今日三场比赛">' + feed.matches.map(function (match) {
        var champion = match.standings[0], player = playerOf(champion.qq);
        return '<article class="daily-match"><div class="daily-match-meta"><span>第 ' + match.number + ' 场</span><span>已结束</span></div><div class="daily-winner">' + avatar(player) + '<div><small>本场冠军</small><h2>' + esc(champion.name) + '</h2><span>冠军积分 +18</span></div></div><p class="daily-duration">预赛 ' + match.qualifierTime.toFixed(1) + ' 秒 · 决赛 ' + match.finalTime.toFixed(1) + ' 秒</p><div class="daily-actions"><button class="daily-button primary" data-watch="' + esc(match.id) + '">观看过程</button><button class="daily-button" data-result="' + esc(match.id) + '" aria-expanded="' + (expanded === match.id) + '">查看结果</button></div></article>';
      }).join('') + '</section>';
      if (expanded && matchOf(expanded)) html += '<section class="daily-detail"><div class="daily-section-head"><h2>第 ' + matchOf(expanded).number + ' 场结果</h2><button class="daily-button" id="daily-close-result">收起</button></div>' + standingsHtml(matchOf(expanded)) + '</section>';
      html += '<nav class="daily-tabs" aria-label="观赛页面"><button data-tab="today" aria-pressed="' + (tab === 'today') + '">今日积分</button><button data-tab="total" aria-pressed="' + (tab === 'total') + '">累计积分</button><button data-tab="rules" aria-pressed="' + (tab === 'rules') + '">比赛规则</button></nav>';
      html += tab === 'rules' ? rulesHtml() : leaderboardHtml();
      html += '<footer class="daily-footer">今日固定 3 场 · 全群共享结果 · 累计从 ' + esc(feed.startDay) + ' 起计</footer>';
    }
    wrap.innerHTML = html;
    wrap.querySelectorAll('[data-watch]').forEach(function (button) { button.onclick = function () { watch(button.dataset.watch); }; });
    wrap.querySelectorAll('[data-result]').forEach(function (button) { button.onclick = function () { expanded = expanded === button.dataset.result ? null : button.dataset.result; renderHome(); }; });
    wrap.querySelectorAll('[data-tab]').forEach(function (button) { button.onclick = function () { tab = button.dataset.tab; renderHome(); }; });
    var close = document.getElementById('daily-close-result'); if (close) close.onclick = function () { expanded = null; renderHome(); };
    var retry = document.getElementById('daily-retry'); if (retry) retry.onclick = refresh;
  }
  function validate(data) {
    if (!data || !/^\d{4}-\d{2}-\d{2}$/.test(data.day) || !Array.isArray(data.matches) || data.matches.length !== 3 || !Array.isArray(data.players) || data.players.length !== 18 || !Array.isArray(data.dailyBoard) || data.dailyBoard.length !== 18 || !Array.isArray(data.totalBoard) || data.totalBoard.length !== 18) throw Error('今日比赛数据暂不完整，请稍后重试。');
    var ids = new Set(data.players.map(function (p) { return p.qq; }));
    data.matches.forEach(function (match) {
      if (match.simVersion !== VERSION || !Array.isArray(match.standings) || match.standings.length !== 18 || new Set(match.standings.map(function (r) { return r.qq; })).size !== 18 || match.standings.some(function (r) { return !ids.has(r.qq); })) throw Error('回放版本或比赛数据暂不匹配，请稍后重试。');
    });
    return data;
  }
  async function refresh() {
    loading = true; error = ''; renderHome();
    clearTimeout(homeTimer);
    try {
      // 纯静态版：结果与积分全部来自预生成的 data/league.json，不再请求任何接口。
      // 种子由北京时间日期派生，所以"每天三场、全群一致"依旧成立，只是不再需要服务器。
      if (!window.PeppaLeague) throw Error('赛程模块未能载入，请刷新后重试。');
      await window.PeppaLeague.load();
      var next = validate(window.PeppaLeague.buildFeed(window.PeppaLeague.beijingDay()));
      // A replay keeps its original day's snapshot until the viewer returns.
      if (document.getElementById('game-screen').hidden) { if (feed && feed.day !== next.day) recordings.clear(); feed = next; }
      homeTimer = setTimeout(refresh, 60000);
    } catch (e) {
      error = e.message || '网络连接暂时不可用，请重试。';
      homeTimer = setTimeout(refresh, 30000);
    }
    loading = false; renderHome();
  }
  function showReplayResult(el, match, replayStandings) {
    if (!el.hidden && el.dataset.seed === String(match.seed)) return;
    el.dataset.seed = String(match.seed);
    var agrees = replayStandings.every(function (r, i) { return r.qq === match.standings[i].qq; });
    el.innerHTML = '<div class="res-card"><div class="res-head"><h2>第 ' + match.number + ' 场 · 官方结果</h2><div class="res-sub">' + esc(feed.day) + ' · ' + (agrees ? '回放已结束，本场积分已统一计入排行榜。' : '回放版本存在差异，下方以已保存的官方结果为准。') + '</div></div>' + standingsHtml(match) + '<div class="res-foot"><button class="btn primary" id="daily-rewatch">重新观看本场</button><button class="btn" id="daily-home">返回今日观赛</button></div></div>';
    el.hidden = false;
    document.getElementById('daily-rewatch').onclick = function () { watch(match.id); };
    document.getElementById('daily-home').onclick = window.PeppaPlayback.home;
  }
  window.PeppaDaily = Object.freeze({ VERSION: VERSION, renderHome: renderHome, init: refresh, getMatch: matchOf, getRecording: function (id) { return recordings.get(id); }, getPlayers: function () { return feed ? feed.players : []; }, showReplayResult: showReplayResult });
})();
