(function () {
  'use strict';
  function decode(frame) {
    if (frame.values) return frame.values;
    var raw = atob(frame.body), bytes = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    var view = new DataView(bytes.buffer), values = [];
    for (var j = 0; j < bytes.length; j += 4) values.push(view.getFloat32(j, true));
    frame.values = values;
    return values;
  }
  window.PeppaRecorded = Object.freeze({
    create: function (record, recording, players) {
      var sim = window.PeppaSimVersions && window.PeppaSimVersions[record.simVersion];
      if (!sim) throw Error('不支持此比赛的赛道版本');
      var match = sim.createMatch({ seed: record.seed, players: players });
      var time = 0, cursor = 0, appliedMeta = -1, previous = null;
      match.finalists = recording.finalists.slice();
      function apply() {
        var frames = recording.frames;
        while (cursor + 1 < frames.length && frames[cursor + 1].at <= time + 1e-8) cursor++;
        var frame = frames[cursor], next = frames[Math.min(cursor + 1, frames.length - 1)];
        match.stage = frame.stage;
        if ((frame.stage === 'final' || frame.stage === 'done') && !match.finalRace) {
          var finalists = recording.finalists.map(function (id) { return players.filter(function (p) { return p.qq === id; })[0]; });
          match.finalRace = sim.createRace({ course: sim.buildCourse(record.seed, 'final'), players: finalists, seed: record.seed, kind: 'final' });
        }
        var race = match.currentRace(), a = decode(frame), b = decode(next);
        var mix = next.stage === frame.stage && next.at > frame.at ? Math.min(1, (time - frame.at) / (next.at - frame.at)) : 0;
        if (mix === 0) b = a;
        match.interT = frame.interT;
        race.t = frame.t + (next.t - frame.t) * mix;
        race.raceTime = frame.raceTime + (next.raceTime - frame.raceTime) * mix;
        race.phase = frame.phase; race.countdown = frame.countdown + (next.countdown - frame.countdown) * mix;
        race.done = frame.done; race.firstFinishT = frame.firstFinishT; race.finishedOrder = frame.finished.slice();
        if (appliedMeta !== frame.meta) {
          appliedMeta = frame.meta;
          var meta = recording.metas[frame.meta];
          race.events = meta.events; race.eliminations = meta.eliminations; race.cuts = meta.cuts;
          race.course.elims.forEach(function (gate, i) { gate.done = i < race.cuts.length; });
          if (previous && previous.stage === frame.stage && meta.cuts.length > previous.cuts) {
            meta.cuts[meta.cuts.length - 1].out.forEach(function (p) {
              var ball = race.balls.filter(function (ball) { return ball.qq === p.qq; })[0];
              if (ball) race.vfx.push({ type: 'elim', x: ball.x, y: ball.y, idx: ball.idx, t: race.raceTime });
            });
          }
        }
        race.balls.forEach(function (ball, i) {
          var offset = i * recording.stride;
          for (var j = 0; j < 8; j++) {
            var key = ['x', 'y', 'vx', 'vy', 'angle', 'best', 'dieT', 'dieRot'][j];
            // Interpolate motion, retaining discrete elimination/finish state.
            ball[key] = a[offset + j] + (b[offset + j] - a[offset + j]) * mix;
          }
          var flags = a[offset + 8];
          ball.alive = !!(flags & 1); ball.dying = !!(flags & 2); ball.finished = !!(flags & 4);
          ball.finishT = a[offset + 9];
        });
        previous = { stage: frame.stage, cuts: race.cuts.length };
        if (match.stage === 'done') {
          // Derive ranks from the recorded finish/elimination sequence, independently
          // of the supplied official table, so a mismatched recording is detectable.
          match.buildStandings();
        }
      }
      match.step = function () { if (match.stage === 'done') return; time = Math.min(recording.duration, time + sim.DT); apply(); };
      apply();
      return match;
    }
  });
})();
