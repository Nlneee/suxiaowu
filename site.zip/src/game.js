/*!
 * 群友大逃杀 · 滚球竞速淘汰赛 —— 渲染 / HUD / 交互层
 * ---------------------------------------------------------------------------
 * 纯 Canvas 2D + 原生 DOM，无框架、无 CDN、无外部字体、无网络请求。
 * 头像走本地相对路径 avatars/<QQ>.jpg，全程不读取像素（只用 clip 裁剪），
 * 因此在 file:// 下也不会触发 Canvas 污染 / CORS。
 */
(function () {
  'use strict';

  var SIM = window.PeppaSim;
  var SPECTATOR = window.PEPPA_SPECTATOR === true;
  var spectatorRecord = null;
  var DT = SIM.DT;
  var PARTICLE_MAX = 260;      // 粒子上限（旧上限 700，是剩下的主要 fill 来源之一）
  var BALL_R = SIM.BALL_R;

  /* ============================ 小工具 ============================ */

  function $(id) { return document.getElementById(id); }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function hypot(x, y) { return Math.sqrt(x * x + y * y); }
  function fmtTime(t) {
    if (!(t >= 0)) t = 0;
    var m = Math.floor(t / 60), s = t - m * 60;
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s.toFixed(1);
  }
  /** 按可见字素截断（正确处理代理对，如 †𝔸𝕟𝕘𝕖𝕝†） */
  function firstGrapheme(name) { var a = Array.from(String(name)); return a.length ? a[0] : '?'; }
  function fitText(ctx, text, maxW) {
    text = String(text);
    if (ctx.measureText(text).width <= maxW) return text;
    var chars = Array.from(text), lo = 0, hi = chars.length;
    while (lo < hi) {
      var mid = (lo + hi + 1) >> 1;
      if (ctx.measureText(chars.slice(0, mid).join('') + '…').width <= maxW) lo = mid; else hi = mid - 1;
    }
    return chars.slice(0, Math.max(1, lo)).join('') + '…';
  }
  function shortTime(t) { return (t < 10 ? '0' : '') + t.toFixed(2); }

  /* ============================ 名单加载 ============================ */

  /**
   * file:// 下浏览器禁止 fetch/XHR 读本地 json，所以运行时名单来自
   * tools/fetch-avatars.mjs 生成的 data/players.js（<script> 可直接加载）。
   * 若通过 http(s) 打开，则再尝试读取 data/players.json，方便在线改名单。
   */
  function loadRoster() {
    var roster = window.PEPPA_ROSTER;
    var list = [];
    if (roster && Array.isArray(roster.players)) {
      list = roster.players.map(function (p) {
        return { qq: String(p.qq), name: String(p.name), role: p.role || 'member', avatar: p.avatar || null };
      });
    }
    if (!list.length && (location.protocol === 'http:' || location.protocol === 'https:')) {
      // 只补名单，不请求未落地的头像 → 不会产生 404
      fetch('data/players.json', { cache: 'no-cache' }).then(function (r) {
        return r.ok ? r.json() : null;
      }).then(function (json) {
        if (!Array.isArray(json) || !json.length) return;
        var byQq = {};
        list.forEach(function (p) { byQq[p.qq] = p; });
        var merged = json.map(function (p) {
          var qq = String(p.qq);
          var known = byQq[qq];
          return {
            qq: qq, name: String(p.name), role: p.role || 'member',
            avatar: known ? known.avatar : null,   // 没下载过头像就走占位，避免 404
          };
        });
        if (merged.length) { state.players = merged; startMatch(state.seed, false); }
      }).catch(function () { /* file:// 或权限问题：忽略 */ });
    }
    return list;
  }

  /* ============================ 音效（WebAudio 现场合成） ============================ */

  var Sound = {
    ctx: null, on: false, lastHit: 0,
    ensure: function () {
      if (this.ctx) return this.ctx;
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      return this.ctx;
    },
    toggle: function () {
      this.on = !this.on;
      if (this.on) { this.ensure(); if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }
      return this.on;
    },
    /** 回主页时静音：不创建 AudioContext，纯粹关掉开关 */
    mute: function () {
      this.on = false;
      if (this.ctx && this.ctx.state === 'running') { try { this.ctx.suspend(); } catch (e) { } }
      return false;
    },
    blip: function (freq, dur, type, vol, slide) {
      if (!this.on) return;
      var ctx = this.ensure(); if (!ctx) return;
      var t = ctx.currentTime;
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type || 'triangle';
      o.frequency.setValueAtTime(freq, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, slide), t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(this.master);
      o.start(t); o.stop(t + dur + 0.02);
    },
    noise: function (dur, vol, freq) {
      if (!this.on) return;
      var ctx = this.ensure(); if (!ctx) return;
      var t = ctx.currentTime;
      var len = Math.floor(ctx.sampleRate * dur);
      var buf = ctx.createBuffer(1, len, ctx.sampleRate);
      var d = buf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      var src = ctx.createBufferSource(); src.buffer = buf;
      var f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq || 900;
      var g = ctx.createGain(); g.gain.value = vol;
      src.connect(f); f.connect(g); g.connect(this.master);
      src.start(t);
    },
    hit: function (power) {
      if (!this.on) return;
      var now = performance.now();
      if (now - this.lastHit < 55) return;
      this.lastHit = now;
      this.noise(0.06, clamp(0.05 + power * 0.12, 0, 0.22), 600 + power * 1800);
    },
    elim: function () {
      this.blip(420, 0.5, 'sawtooth', 0.16, 90);
      this.noise(0.3, 0.12, 500);
    },
    boost: function () { this.blip(300, 0.18, 'square', 0.1, 900); },
    win: function () {
      var self = this;
      [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) {
        setTimeout(function () { self.blip(f, 0.42, 'triangle', 0.2); }, i * 130);
      });
    },
    cut: function () { this.blip(180, 0.35, 'sawtooth', 0.14, 70); },
  };

  /* ============================ 全局状态 ============================ */

  var state = {
    players: [], seed: 0, match: null, race: null,
    paused: false, speed: 1, alpha: 0, acc: 0, last: 0,
    particles: [], vfxRnd: null, started: 0, stageBanner: '', stageBannerT: 0,
    errors: [], frameCount: 0, hudTick: 0, champIdx: -1,
    shake: { t: 0, power: 0 }, shakeOn: true, frameMs: 0,
    // 独立欢迎界面 / 记录
    menuOpen: false, menuPage: 'main', menuDetail: null, menuFocus: null,
    seedHint: null, recDay: null, confirmOpen: false,
    recId: '', recWritten: false, recMode: 'new', recCount: 0,
    // 性能相关
    dpr: 1, quality: 'auto', autoDpr: 1.5, fpsAcc: 0, fpsN: 0, frameRank: [],
    skipRender: false, tileBuilt: 0,
  };

  /** 欢迎界面没有比赛背景，只有比赛界面使用正式 race。 */
  function activeRace() { return state.menuOpen ? null : state.race; }

  var gameFrameId = null, lastGameFrame = 0;
  function stopGameLoop() {
    if (gameFrameId !== null) cancelAnimationFrame(gameFrameId);
    gameFrameId = null;
  }
  function resumeGameLoop() {
    if (state.menuOpen || !state.race || gameFrameId !== null) return;
    lastGameFrame = performance.now();
    gameFrameId = requestAnimationFrame(gameFrame);
  }
  function gameFrame(now) {
    gameFrameId = null;
    if (state.menuOpen || !state.race) return;
    var dt = Math.min(0.05, Math.max(0, (now - lastGameFrame) / 1000));
    lastGameFrame = now;
    tick(dt);
    render(dt);
    state.frameCount++;
    if (state.frameCount % 6 === 0) updateHud();
    if (!state.menuOpen) gameFrameId = requestAnimationFrame(gameFrame);
  }

  var cv = $('stage'), ctx = cv.getContext('2d');
  var view = { scale: 0.5, cx: 750, top: -800, availW: 800, w: 800, h: 600, minX: 0, maxX: 1500 };

  /* ============================ 头像 ============================ */

  function loadAvatar(p) {
    if (!p.avatar) { p.img = null; p.imgOk = false; return; }
    var img = new Image();
    img.decoding = 'async';
    img.onload = function () { p.img = img; p.imgOk = true; };
    img.onerror = function () { p.img = null; p.imgOk = false; };
    img.src = p.avatar;
    p.img = null; p.imgOk = false;
  }

  /* ============================ 配色 ============================ */

  function hash32(s) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  /**
   * 色环 = 按 QQ 号哈希取色，稳定且每人不同（规格要求）；
   * role 只用在外圈描边与排行榜徽标上（群主金黄 / 管理天蓝）。
   */
  function palette(qq, role) {
    var hue = hash32(qq) % 360;
    var hash = 'hsl(' + hue + ' 92% 64%)';
    var glow = role === 'owner' ? 'rgba(255,215,94,'
      : role === 'admin' ? 'rgba(125,211,252,'
        : 'hsla(' + hue + ' 92% 64% / ';
    return {
      ring: hash, glow: glow, hue: hue, fill: '#131a2d',
      roleRing: role === 'owner' ? '#ffd75e' : (role === 'admin' ? '#7dd3fc' : null),
      badge: role === 'owner' ? '群主' : (role === 'admin' ? '管理' : ''),
    };
  }

  /* ============================ 布局与相机 ============================ */

  function computeLayout() {
    var w = window.innerWidth, h = window.innerHeight;
    var panelW = w >= 1280 ? 320 : (w >= 980 ? 256 : 0);
    if (panelW > 0 && h < 560) panelW = Math.min(panelW, 230);
    var availW = w - panelW;
    var race = activeRace();
    if (!race) {
      view.w = w; view.h = h; view.availW = w;
      return; // 欢迎界面使用 DOM 布局，不为隐藏画布创建赛道。
    }
    var course = race.course;
    var spanX = (course.maxX - course.minX) + 150;
    var scale = Math.max(availW / spanX, 14 / BALL_R);      // 球最小可视半径 ≥ 14 CSS px
    var visW = availW / scale;
    var cx = (course.minX + course.maxX) / 2;
    if (visW < course.maxX - course.minX) {
      var sx = 0, n = 0, bs = activeRace() ? activeRace().balls : [];
      for (var i = 0; i < bs.length; i++) if (bs[i].alive) { sx += bs[i].x; n++; }
      var meanX = n ? sx / n : cx;
      cx = clamp(meanX, course.minX + visW / 2, course.maxX - visW / 2);
    }
    view.scale = scale; view.cx = cx; view.availW = availW; view.w = w; view.h = h;
    view.minX = course.minX; view.maxX = course.maxX;
    document.documentElement.style.setProperty('--panel-w', panelW + 'px');
    document.body.classList.toggle('narrow', panelW === 0);
  }

  function toScreenX(wx) { return (wx - view.cx) * view.scale + view.availW / 2; }
  function toScreenY(wy) { return (wy - view.top) * view.scale; }
  function viewHWorld() { return view.h / view.scale; }

  function updateCamera(dt) {
    var race = activeRace(); if (!race) return;
    // “最快”按赛程排名理解：锁定第一名，而不是瞬时速度最大的球。
    // 用与头像相同的插值坐标，暂停、换领先者、切决赛都不会产生相机追赶误差。
    state.frameRank = race.rankAlive();
    var lead = state.frameRank[0];
    if (race.finishedOrder.length) lead = race.balls[race.finishedOrder[0]];
    state.cameraTarget = lead ? lead.qq : null;
    if (!lead) return;
    var pos = ballScreen(lead);
    view.cx = pos.x;
    view.top = pos.y - viewHWorld() / 2;
  }

  /* ============================ 材质 / 缓存 ============================ */

  var TEX_CACHE = {};       // 关卡主题 → CanvasPattern（只创建一次）
  var LIGHT_CACHE = {};     // 颜色 → 提亮后的颜色

  function hexA(hex, a) {
    var c = String(hex).replace('#', '');
    if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
    var n = parseInt(c, 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function lighten(hex, amt) {
    var key = hex + '|' + amt;
    if (LIGHT_CACHE[key]) return LIGHT_CACHE[key];
    var c = String(hex).replace('#', '');
    if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
    var n = parseInt(c, 16);
    var r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    r = Math.round(r + (255 - r) * amt);
    g = Math.round(g + (255 - g) * amt);
    b = Math.round(b + (255 - b) * amt);
    var out = 'rgb(' + r + ',' + g + ',' + b + ')';
    LIGHT_CACHE[key] = out;
    return out;
  }
  function mixHex(a, b, t) {
    var ca = parseInt(String(a).replace('#', ''), 16), cb = parseInt(String(b).replace('#', ''), 16);
    var r = Math.round(((ca >> 16) & 255) * (1 - t) + ((cb >> 16) & 255) * t);
    var g = Math.round(((ca >> 8) & 255) * (1 - t) + ((cb >> 8) & 255) * t);
    var bl = Math.round((ca & 255) * (1 - t) + (cb & 255) * t);
    return 'rgb(' + r + ',' + g + ',' + bl + ')';
  }

  /** 每关一种底面纹理，用离屏 canvas 画一次后缓存成 pattern */
  function themePattern(theme, color) {
    var key = theme + '|' + color;
    if (TEX_CACHE[key]) return TEX_CACHE[key];
    var S = 64;
    var cv = document.createElement('canvas');
    cv.width = cv.height = S;
    var g = cv.getContext('2d');
    var line = hexA(color, 0.55);
    g.clearRect(0, 0, S, S);
    g.lineWidth = 2;
    g.strokeStyle = line;
    g.fillStyle = line;
    var i;
    switch (theme) {
      case 'speed':                     // 加速坡：速度线
        for (i = 0; i < 6; i++) {
          g.beginPath();
          g.moveTo(0, i * 11 + 4); g.lineTo(S, i * 11 - 2);
          g.stroke();
        }
        break;
      case 'wave':                      // 波浪弯道：正弦纹
        for (i = 0; i < 2; i++) {
          g.beginPath();
          for (var x = 0; x <= S; x += 4) g.lineTo(x, 20 + i * 24 + Math.sin(x / 10) * 7);
          g.stroke();
        }
        break;
      case 'funnel':                    // 漏斗：收拢斜纹
        for (i = -S; i < S * 2; i += 16) {
          g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 26, S); g.stroke();
        }
        break;
      case 'hazard':                    // 挡板关：黄黑警示条（用在墙上）
        g.fillStyle = '#facc15'; g.fillRect(0, 0, S, S);
        g.fillStyle = '#111318';
        for (i = -S; i < S * 2; i += 24) {
          g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 12, 0); g.lineTo(i + 12 - S, S); g.lineTo(i - S, S); g.closePath(); g.fill();
        }
        break;
      case 'spring':                    // 跳板关：绿色网格
        for (i = 0; i <= S; i += 16) {
          g.beginPath(); g.moveTo(i, 0); g.lineTo(i, S); g.stroke();
          g.beginPath(); g.moveTo(0, i); g.lineTo(S, i); g.stroke();
        }
        break;
      case 'crack':                     // 断层关：红色裂纹
        for (i = 0; i < 5; i++) {
          g.beginPath();
          var cx = (i * 17) % S, cy = (i * 29) % S;
          g.moveTo(cx, cy);
          for (var k = 0; k < 4; k++) { cx += ((i * 7 + k * 13) % 17) - 8; cy += 9; g.lineTo(cx, cy); }
          g.stroke();
        }
        break;
      case 'platform':                  // 平台关：青色电路
        for (i = 0; i <= S; i += 21) {
          g.beginPath(); g.moveTo(0, i); g.lineTo(S * 0.6, i); g.lineTo(S * 0.6, i + 21); g.lineTo(S, i + 21); g.stroke();
        }
        g.beginPath(); g.arc(S * 0.5, S * 0.5, 4, 0, Math.PI * 2); g.fill();
        break;
      case 'gear':                      // 风车大厅：橙色齿纹
        for (i = 0; i < 8; i++) {
          g.save(); g.translate(S / 2, S / 2); g.rotate(i * Math.PI / 4);
          g.beginPath(); g.rect(-3, -S / 2, 6, 12); g.fill();
          g.restore();
        }
        g.beginPath(); g.arc(S / 2, S / 2, 12, 0, Math.PI * 2); g.stroke();
        break;
      case 'zigzag':                    // 折返关：紫色斜纹
        for (i = -S; i < S * 2; i += 18) {
          g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 18, 0); g.lineTo(i + 18 + S, S); g.lineTo(i + S, S); g.closePath(); g.fill();
        }
        break;
      case 'checker':                   // 冲刺关：金色棋盘
        for (i = 0; i < 4; i++) {
          for (var j = 0; j < 4; j++) {
            if ((i + j) % 2) continue;
            g.fillRect(i * 16, j * 16, 16, 16);
          }
        }
        break;
      default:
        for (i = -S; i < S * 2; i += 20) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 20, S); g.stroke(); }
    }
    var pat = ctx.createPattern(cv, 'repeat');
    TEX_CACHE[key] = pat;
    return pat;
  }

  /** 纹理随世界滚动：给 pattern 设置平移（拿不到 DOMMatrix 就退回不平移） */
  function syncPattern(pat) {
    if (!pat || !pat.setTransform) return;
    try {
      var ox = (-view.cx * view.scale + view.availW / 2) % 64;
      var oy = (-view.top * view.scale) % 64;
      pat.setTransform(new DOMMatrix([1, 0, 0, 1, ox, oy]));
    } catch (e) { /* 忽略 */ }
  }

  /* ============================ 几何缓存 ============================ */

  function precomputeNormals(course) {
    if (course._nrm) return;
    var pts = course.pts, n = pts.length;
    var nx = new Float64Array(n), ny = new Float64Array(n);
    for (var i = 0; i < n; i++) {
      var a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
      var dx = b.x - a.x, dy = b.y - a.y;
      var L = hypot(dx, dy) || 1;
      var tx = dx / L, ty = dy / L;
      var mx = -ty, my = tx;
      if (my < 0) { mx = -mx; my = -my; }
      nx[i] = mx; ny[i] = my;
    }
    course._nrm = { nx: nx, ny: ny };
    // 点索引 → 关卡序号
    var lvOf = new Int16Array(n);
    course.levels.forEach(function (lv, k) {
      for (var i = lv.i0; i <= Math.min(lv.i1, n - 1); i++) lvOf[i] = k;
    });
    course._lvOf = lvOf;
  }
  function levelOfIndex(course, i) {
    return course.levels[course._lvOf ? course._lvOf[i] : 0];
  }

  /**
   * 按「沿中心线一串半径 w 的圆盘并集」构建管道轮廓。
   * 每段一个四边形（用该段自己的法线，不用平均法线），转角处补一个圆盘盖住接缝；
   * 所有子路径同绕向 → 一次 fill() 就是精确并集：半透明不会因重叠变深，
   * 凹坑 / 急弯处也不会像"中心线 ± 平均法线 × w"那样自交打结。
   */
  function buildTubePath(course, idx, extra) {
    var pts = course.pts, w = course.w, n = idx.length, k;
    ctx.beginPath();
    for (k = 0; k + 1 < n; k++) {
      var a = idx[k], b = idx[k + 1];
      var ax = pts[a].x, ay = pts[a].y, bx = pts[b].x, by = pts[b].y;
      var dx = bx - ax, dy = by - ay;
      var L = hypot(dx, dy) || 1;
      var nx = -dy / L, ny = dx / L;
      var wa = w[a] + extra, wb = w[b] + extra;
      ctx.moveTo(toScreenX(ax - nx * wa), toScreenY(ay - ny * wa));
      ctx.lineTo(toScreenX(bx - nx * wb), toScreenY(by - ny * wb));
      ctx.lineTo(toScreenX(bx + nx * wb), toScreenY(by + ny * wb));
      ctx.lineTo(toScreenX(ax + nx * wa), toScreenY(ay + ny * wa));
      ctx.closePath();
    }
    for (k = 0; k < n; k++) {
      var j = idx[k], need = (k === 0 || k === n - 1);
      if (!need && k > 0 && k + 1 < n) {
        var p0 = pts[idx[k - 1]], p1 = pts[j], p2 = pts[idx[k + 1]];
        var v1x = p1.x - p0.x, v1y = p1.y - p0.y, v2x = p2.x - p1.x, v2y = p2.y - p1.y;
        var l1 = hypot(v1x, v1y) || 1, l2 = hypot(v2x, v2y) || 1;
        var cr = (v1x * v2y - v1y * v2x) / (l1 * l2);
        need = Math.abs(cr) > 0.012;
      }
      if (!need) continue;
      var R = (w[j] + extra) * view.scale;
      if (R < 0.6) continue;
      var sx = toScreenX(pts[j].x), sy = toScreenY(pts[j].y);
      ctx.moveTo(sx + R, sy);
      ctx.arc(sx, sy, R, 0, Math.PI * 2);
    }
  }

  /* ============================ 渲染：背景 ============================ */

  function drawBackdrop() {
    var w = view.availW, h = view.h;
    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, w, h);
    var step = 120, x0 = Math.floor((view.cx - view.availW / view.scale / 2) / step) * step;
    var y0 = Math.floor(view.top / step) * step;
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, view.availW, h);
    ctx.clip();
    ctx.strokeStyle = 'rgba(96,165,250,0.035)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (var x = x0; x < view.cx + view.availW / view.scale; x += step) {
      var sx = Math.round(toScreenX(x)) + 0.5;
      ctx.moveTo(sx, 0); ctx.lineTo(sx, h);
    }
    for (var y = y0; y < view.top + viewHWorld() + step; y += step) {
      var sy = Math.round(toScreenY(y)) + 0.5;
      ctx.moveTo(0, sy); ctx.lineTo(view.availW, sy);
    }
    ctx.stroke();
    ctx.restore();
  }

  function drawLevelBands(race) {
    var course = race.course;
    var h = view.h;
    for (var i = 0; i < course.levels.length; i++) {
      var lv = course.levels[i];
      var y0 = SIM.frameAt(course, lv.s0).y, y1 = SIM.frameAt(course, lv.s1).y;
      var s0 = toScreenY(y0 - 300), s1 = toScreenY(y1 + 300);
      if (s1 < 0 || s0 > h) continue;
      var g = ctx.createLinearGradient(0, s0, 0, s1);
      g.addColorStop(0, 'rgba(255,255,255,0)');
      g.addColorStop(0.5, hexA(lv.color, 0.045 + lv.danger * 0.02));
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, s0, view.availW, s1 - s0);
    }
  }

  /* ============================ 渐变 / 瓦片缓存 ============================ */

  var GRAD = { backdropH: -1, backdrop: null };
  /** 背景渐变只依赖窗口高度，缓存起来不要每帧 createLinearGradient */
  function backdropGrad(h) {
    if (GRAD.backdropH !== h) {
      var g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#04060d');
      g.addColorStop(0.55, '#070b18');
      g.addColorStop(1, '#04060d');
      GRAD.backdropH = h; GRAD.backdrop = g;
    }
    return GRAD.backdrop;
  }

  /**
   * 静态赛道瓦片缓存
   * ---------------------------------------------------------------------------
   * 管道的光晕 / 墙体 / 高光 / 交界渐变 / 危险区墙体 / 底面渐变 / 关卡纹理 /
   * 泥沼底色 / 凹坑红色底光 / 关卡门框 / 终点棋盘格 —— 这些都是静态的，
   * 每帧重画要几千次 Canvas 调用（实测 arc 2000+、lineTo 7000+），是帧率的主因。
   *
   * 做法：按世界 y 切块（每块 TILE_H 屏幕像素高、宽度覆盖整条赛道），
   * 用「临时把全局 ctx 指向离屏 canvas + 把 view.top 挪到瓦片顶部」的巧劲，
   * 直接复用同一批绘制函数渲染瓦片，不需要重写任何绘制逻辑。
   *
   * 缓存键 = 赛道 + scale + availW + view.h + dpr；瓦片横向锚定世界坐标，镜头移动不作废（窗口缩放 /
   * 切决赛赛道 / 重开一局 / 自适应画质降档）。最多同时保留 TILE_MAX 块，LRU 淘汰。
   */
  var TILE_H = 1024;          // 每块瓦片的屏幕高度（CSS px）
  var TILE_MAX = 8;           // 同时保留的瓦片数
  var tiles = { key: '', map: Object.create(null) };
  var tilesEnabled = true;      // false 时退化为每帧实时绘制（对照实验用）

  function invalidateTiles() { tiles.key = ''; tiles.map = Object.create(null); }

  function tileWorldH() { return TILE_H / view.scale; }
  /**
   * 瓦片基准世界 y：以赛道 minY 上方 600 为基准，并按瓦片高度对齐。
   * ⚠️ 不能用 view.minY —— view 上根本没有这个字段，旧写法算出 NaN，
   * 于是 tileIndexAt 返回 NaN、瓦片循环一次都不执行（缓存形同虚设）。
   */
  function tileBaseY(race) {
    var wH = tileWorldH();
    var key = race.course.minY + ':' + wH;
    if (tiles.baseKey !== key) {
      tiles.baseKey = key;
      tiles.base = Math.floor((race.course.minY - 600) / wH) * wH;
    }
    return tiles.base;
  }
  function tileTopWorld(i, race) { return tileBaseY(race) + i * tileWorldH(); }
  function tileIndexAt(worldY, race) { return Math.floor((worldY - tileBaseY(race)) / tileWorldH()); }

  function tileKeyOf(race) {
    if (!race) return '';
    return view.scale.toFixed(6) + '|' + view.availW + 'x' + view.h
      + '|' + state.dpr;
  }

  function buildTile(i, race) {
    var dpr = state.dpr;
    var cv = document.createElement('canvas');
    // 瓦片固定在世界坐标；相机横移只改变贴图位置，不重建也不拉伸赛道。
    var midX = (race.course.minX + race.course.maxX) / 2;
    var width = Math.ceil((race.course.maxX - race.course.minX + 240) * view.scale * dpr) / dpr;
    var leftX = midX - width / view.scale / 2;
    cv.width = Math.max(1, Math.round(width * dpr));
    cv.height = Math.max(1, Math.ceil(TILE_H * dpr));
    var savedCtx = ctx, savedTop = view.top, savedH = view.h;
    var savedX = view.cx, savedW = view.availW;
    ctx = cv.getContext('2d');
    try {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      view.cx = midX; view.availW = width;
      view.top = tileTopWorld(i, race);
      // 关键：瓦片要按整块高度渲染（backdrop 的 fillRect 与各绘制函数的 clip/culling
      // 都读 view.h）。若这里保留视口高度，瓦片内容就只有 view.h 那么高，
      // 一旦贴图偏移为负（瓦片顶部在视口上方），视口底部就会出现一条没被覆盖的空白带。
      view.h = TILE_H;
      drawBackdrop();
      drawLevelBands(race);
      drawChannel(race, 'static');
      drawMarkers(race, 'static');
    } catch (e) { state.errors.push('tile:' + e.message); }
    finally {
      ctx = savedCtx; view.top = savedTop; view.h = savedH;
      view.cx = savedX; view.availW = savedW;
    }
    state.tileBuilt++;
    return { cv: cv, leftX: leftX, width: width };
  }

  function getTile(i, race) {
    var k = String(i);
    var t = tiles.map[k];
    if (!t) {
      // 超上限：先丢掉最久未用的（用瓦片编号到视口的距离近似"最近使用"）
      var keys = Object.keys(tiles.map);
      if (keys.length >= TILE_MAX) {
        keys.sort(function (a, b) { return Math.abs(+a - i) - Math.abs(+b - i); });
        for (var j = keys.length - 1; j >= TILE_MAX - 1; j--) delete tiles.map[keys[j]];
      }
      t = buildTile(i, race);
      tiles.map[k] = t;
    }
    return t;
  }

  function drawTiles(race) {
    if (!tilesEnabled) {
      drawBackdrop(); drawLevelBands(race); drawChannel(race, 'static'); drawMarkers(race, 'static');
      return;
    }
    var dpr = state.dpr;
    drawBackdrop();
    var key = tileKeyOf(race);
    // 赛道换对象（重开一局 / 切决赛道）、scale / dpr / 宽度变化 → 整体作废
    if (tiles.course !== race.course || key !== tiles.key) {
      tiles.course = race.course; tiles.key = key; tiles.map = Object.create(null);
    }
    var i0 = tileIndexAt(view.top - 60, race);
    var i1 = tileIndexAt(view.top + viewHWorld() + 60, race);
    for (var i = i0; i <= i1; i++) {
      var tile = getTile(i, race), cv = tile.cv;
      var dstY = (tileTopWorld(i, race) - view.top) * view.scale;
      // 亚像素精确贴图：不做 round。
      // 把目标 y 取整会引入最多 0.5 设备像素的整体偏移，让瓦片与"实时绘制"在管道边缘
      // 产生明显的抗锯齿差异（实测中心区 10%）；而相邻瓦片的世界坐标本身就是精确连续的，
      // 不取整也不会出现缝隙。
      ctx.drawImage(cv, 0, 0, cv.width, cv.height, toScreenX(tile.leftX), dstY, tile.width, TILE_H);
    }
  }

  /**
   * 自适应画质：最近 60 帧的平均帧间隔 > 22ms 就把 dpr 降到 1。
   * 带迟滞（hysteresis）：只有稳定低于 13ms 才升回 1.5 —— 否则会在阈值附近
   * 反复降档/升档，每次都触发 resize + 瓦片全部重建，反而更卡。
   */
  function adaptQuality(dt) {
    if (state.quality !== 'auto') return;
    state.fpsAcc += dt; state.fpsN++;
    if (state.fpsN < 60) return;
    var avgMs = state.fpsAcc / state.fpsN * 1000;
    state.fpsAcc = 0; state.fpsN = 0;
    var want = state.autoDpr;
    if (avgMs > 22 && state.autoDpr > 1) want = 1;
    else if (avgMs < 13 && state.autoDpr < 1.5) want = 1.5;
    state.lastAvgMs = avgMs;
    if (want !== state.autoDpr) {
      state.autoDpr = want;
      var raw = window.devicePixelRatio > 1 ? Math.min(window.devicePixelRatio, 2) : 1;
      var nd = Math.min(raw, want);
      if (nd !== state.dpr) { state.dpr = nd; resize(); }
    }
  }

  function effectiveDpr() {
    var raw = window.devicePixelRatio > 1 ? Math.min(window.devicePixelRatio, 2) : 1;
    if (state.quality === 'low') return 1;
    if (state.quality === 'high') return Math.min(raw, 2);
    return Math.min(raw, state.autoDpr);
  }

  /**
   * 赛道标记（灯带每 90 世界单位、流向箭头每 180）的预计算。
   * 旧实现每帧从 s=0 遍历到 course.total 逐个 SIM.frameAt（二分查找），
   * 以 21755 世界单位、90 间隔算就是每帧 240+ 次无用查找。
   * 预计算后每帧只是遍历数组做 toScreenY 比较。
   */
  var MARKS = { course: null, lights: [], arrows: [] };
  function markerCache(course) {
    if (MARKS.course === course) return MARKS;
    var lights = [], arrows = [], s, f;
    for (s = 0; s < course.total; s += 90) { f = SIM.frameAt(course, s); lights.push({ s: s, f: f }); }
    for (s = 0; s < course.total; s += 180) { f = SIM.frameAt(course, s); arrows.push({ s: s, f: f }); }
    MARKS = { course: course, lights: lights, arrows: arrows };
    return MARKS;
  }

  /* ============================ 渲染：管道 ============================ */

  /** 管道最小绘制尺寸兜底：墙带至少 4 CSS px */
  function pxFix() {
    return Math.max(1, 4 / (10 * view.scale));
  }

  function wallColorOf(lv) {
    return lv.danger ? mixHex(lv.color, '#f97316', 0.25) : lv.color;
  }

  /**
   * 把画布裁成「只保留弧长 s 在 [sLo, sHi] 一侧」的区域。
   * 做法：在区间两端各放一个横跨管道的局部矩形，用 evenodd 把它挖掉。
   * 只在端点附近局部生效（矩形尺寸 ≈ 管道宽 × 管道宽），不会误伤远处绕回来的赛道。
   * 用途：按关卡分段绘制时，相邻两段的端点圆盘会互相盖住（半透明叠深 / 底面被墙色覆盖），
   * 裁剪后每个像素只归属一段，交界处是一条干净的横切线。
   */
  function clipSRange(course, sLo, sHi) {
    var ends = [];
    if (sLo > course.cum[0] + 1) ends.push({ s: sLo, dir: -1 });
    if (sHi < course.total - 1) ends.push({ s: sHi, dir: 1 });
    ends.forEach(function (e) {
      var f = SIM.frameAt(course, e.s);
      var R = f.w + 64 * pxFix() + 40;           // 覆盖光晕层
      var D = f.w + 64 * pxFix() + 160;          // 往被裁掉的一侧伸多深
      var tx = f.tx * e.dir, ty = f.ty * e.dir;
      ctx.beginPath();
      ctx.rect(-10, -10, view.availW + 20, view.h + 20);
      ctx.moveTo(toScreenX(f.x + f.nx * R), toScreenY(f.y + f.ny * R));
      ctx.lineTo(toScreenX(f.x + f.nx * R + tx * D), toScreenY(f.y + f.ny * R + ty * D));
      ctx.lineTo(toScreenX(f.x - f.nx * R + tx * D), toScreenY(f.y - f.ny * R + ty * D));
      ctx.lineTo(toScreenX(f.x - f.nx * R), toScreenY(f.y - f.ny * R));
      ctx.closePath();
      ctx.clip('evenodd');
    });
  }

  /** 弧长区间 → 中心线点索引（两端各多带 pad 个点，交给 clipSRange 去切齐） */
  function idxInRange(course, s0, s1, pad) {
    var cum = course.cum, n = cum.length, out = [];
    for (var j = 0; j < n; j++) if (cum[j] >= s0 && cum[j] <= s1) out.push(j);
    if (!out.length) return out;
    var a = out[0], b = out[out.length - 1];
    for (var p = 1; p <= pad; p++) {
      if (a - p >= 0) out.unshift(a - p);
      if (b + p < n) out.push(b + p);
    }
    return out;
  }

  /**
   * 一段关卡的完整管道（光晕 → 墙 → 高光 → 底面 → 纹理）。
   * 调用方已用 clipSRange 把它裁在本关弧长范围内；关卡交界处 ±60 单位的墙体
   * 用沿切线的线性渐变从上一关颜色过渡到下一关（两侧在交界线上同为 50% 混色，接缝连续）。
   */
  function drawTubeSeg(course, idx, lv, prevLv, nextLv, sLo, sHi) {
    if (idx.length < 2) return;
    var k = pxFix();
    var wallColor = wallColorOf(lv);
    // a. 外光晕
    ctx.globalAlpha = 0.05;
    buildTubePath(course, idx, 44 * k);
    ctx.fillStyle = wallColor; ctx.fill();
    ctx.globalAlpha = 1;
    // 实体托盘：投影、厚实钢制外壳、彩色安全边和亮面倒角。
    // 仍用管道圆盘并集，急弯不会产生自交的边线。
    ctx.save(); ctx.translate(6 * k, 12 * k);
    buildTubePath(course, idx, 32 * k);
    ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fill(); ctx.restore();
    buildTubePath(course, idx, 30 * k);
    var shell = ctx.createLinearGradient(toScreenX(course.minX), 0, toScreenX(course.maxX), 0);
    shell.addColorStop(0, '#1b2937'); shell.addColorStop(0.45, '#718597'); shell.addColorStop(1, '#253645');
    ctx.fillStyle = shell; ctx.fill();
    // b. 墙体本体（挡板关用黄黑警示条纹）
    buildTubePath(course, idx, 16 * k);
    if (lv.theme === 'hazard') {
      var pat = themePattern('hazard', wallColor);
      syncPattern(pat);
      ctx.fillStyle = pat;
    } else {
      ctx.fillStyle = wallColor;
    }
    ctx.fill();
    // c. 墙体高光
    buildTubePath(course, idx, 6 * k);
    ctx.fillStyle = '#c7d6df'; ctx.fill();
    // b'/c'. 交界渐变：只在交界点附近的局部圆内重涂墙与高光（底面随后会盖住内侧）
    [[prevLv, lv, sLo], [lv, nextLv, sHi]].forEach(function (pair) {
      if (!pair[0] || !pair[1]) return;
      var f = SIM.frameAt(course, pair[2]);
      var R = (f.w + 60 * k + 60) * view.scale;
      var cx = toScreenX(f.x), cy = toScreenY(f.y);
      if (cy < -R || cy > view.h + R) return;
      var x0 = toScreenX(f.x - f.tx * 60), y0 = toScreenY(f.y - f.ty * 60);
      var x1 = toScreenX(f.x + f.tx * 60), y1 = toScreenY(f.y + f.ty * 60);
      var cA = wallColorOf(pair[0]), cB = wallColorOf(pair[1]);
      ctx.save();
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.clip();
      var gw = ctx.createLinearGradient(x0, y0, x1, y1);
      gw.addColorStop(0, cA); gw.addColorStop(1, cB);
      buildTubePath(course, idx, 16 * k);
      ctx.fillStyle = gw; ctx.fill();
      var gh = ctx.createLinearGradient(x0, y0, x1, y1);
      gh.addColorStop(0, lighten(cA, 0.35)); gh.addColorStop(1, lighten(cB, 0.35));
      buildTubePath(course, idx, 6 * k);
      ctx.fillStyle = gh; ctx.fill();
      ctx.restore();
    });
    fillTrackFloor(course, idx, lv);
  }

  function fillTrackFloor(course, idx, lv) {
    buildTubePath(course, idx, 0);
    var g = ctx.createLinearGradient(toScreenX(course.minX), 0, toScreenX(course.maxX), 0);
    g.addColorStop(0, '#22313f'); g.addColorStop(0.48, '#41586a'); g.addColorStop(1, '#243340');
    ctx.fillStyle = g; ctx.fill();
    var tex = themePattern(lv.theme, lv.color);
    if (tex) {
      syncPattern(tex);
      ctx.globalAlpha = 0.12;
      ctx.fillStyle = tex; ctx.fill();
      ctx.globalAlpha = 1;
    }
    // 面板拼缝和铆钉固定在世界坐标，并缓存进瓦片。
    ctx.save(); ctx.clip();
    var s0 = course.cum[idx[0]], s1 = course.cum[idx[idx.length - 1]];
    for (var s = Math.ceil(s0 / 240) * 240; s <= s1; s += 240) {
      var f = SIM.frameAt(course, s);
      var ax = toScreenX(f.x - f.nx * (f.w - 8)), ay = toScreenY(f.y - f.ny * (f.w - 8));
      var bx = toScreenX(f.x + f.nx * (f.w - 8)), by = toScreenY(f.y + f.ny * (f.w - 8));
      ctx.strokeStyle = 'rgba(3,9,15,0.46)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
      ctx.strokeStyle = 'rgba(206,225,237,0.18)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(ax + f.tx * 2, ay + f.ty * 2); ctx.lineTo(bx + f.tx * 2, by + f.ty * 2); ctx.stroke();
      ctx.fillStyle = '#9aafbf'; ctx.beginPath();
      for (var side = -1; side <= 1; side += 2) {
        var x = toScreenX(f.x + f.nx * (f.w - 22) * side);
        var y = toScreenY(f.y + f.ny * (f.w - 22) * side);
        ctx.moveTo(x + 2, y); ctx.arc(x, y, 2, 0, Math.PI * 2);
      }
      ctx.fill();
    }
    ctx.restore();
  }

  /** 在管道底面上叠一层（泥沼 / 喉口等局部区域），严格限制在 [s0,s1] 且不越出底面 */
  function overlayFloor(course, s0, s1, extra, fill, alpha) {
    var idx = idxInRange(course, s0, s1, 2);
    if (idx.length < 2) return;
    ctx.save();
    clipSRange(course, s0, s1);
    buildTubePath(course, idx, extra);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = fill; ctx.fill();
    ctx.restore();
  }

  /**
   * 管道绘制。phase:
   *   'static'  —— 只画与时间无关的部分（供瓦片缓存：管道本体 / 凹坑底光）
   *   'dynamic' —— 只画随时间变化的部分（流向箭头 / 跑马灯 / 凹坑脉冲 / 喉口箭头）
   *   不传      —— 两者都画（旧行为，保留给对照截图）
   */
  function drawChannel(race, phase) {
    var ST = phase !== 'dynamic', DY = phase !== 'static';
    var course = race.course;
    precomputeNormals(course);
    var pts = course.pts, n = pts.length, i, k;
    var yTop = view.top - 420, yBot = view.top + viewHWorld() + 420;

    ctx.save();

    if (ST) {
      // 1) 管道本体：每关单独一段，用 clipSRange 切在本关弧长范围内。
      var levels = course.levels, L = levels.length;
      var bounds = [course.cum[0]];
      for (k = 1; k < L; k++) bounds.push(levels[k].s0);
      bounds.push(course.total);
      for (k = 0; k < L; k++) {
        var sLo = bounds[k], sHi = bounds[k + 1];
        var idx = idxInRange(course, sLo, sHi, 3).filter(function (j) {
          return pts[j].y >= yTop - 600 && pts[j].y <= yBot + 600;
        });
        if (idx.length < 2) continue;
        var runs2 = [], cur2 = [idx[0]];
        for (i = 1; i < idx.length; i++) {
          if (idx[i] === idx[i - 1] + 1) cur2.push(idx[i]);
          else { runs2.push(cur2); cur2 = [idx[i]]; }
        }
        runs2.push(cur2);
        ctx.save();
        clipSRange(course, sLo, sHi);
        for (i = 0; i < runs2.length; i++) {
          drawTubeSeg(course, runs2[i], levels[k], levels[k - 1] || null, levels[k + 1] || null, sLo, sHi);
        }
        // 危险区墙体重涂：喉口 → 橙色墙；凹坑 → 黄黑警示条纹墙。
        var zones = [];
        course.throats.forEach(function (th) { zones.push({ s0: th.s0, s1: th.s1, kind: 'throat' }); });
        course.pits.forEach(function (p) { zones.push({ s0: p.s0 - 20, s1: p.s1 + 20, kind: 'pit' }); });
        zones.forEach(function (z) {
          if (z.s1 < sLo || z.s0 > sHi) return;
          var fz = SIM.frameAt(course, (z.s0 + z.s1) / 2);
          var syz = toScreenY(fz.y);
          if (syz < -400 || syz > view.h + 400) return;
          var zi = idxInRange(course, z.s0, z.s1, 2);
          if (zi.length < 2) return;
          var kz = pxFix();
          ctx.save();
          clipSRange(course, Math.max(z.s0, sLo), Math.min(z.s1, sHi));
          buildTubePath(course, zi, 16 * kz);
          if (z.kind === 'pit') {
            var hp = themePattern('hazard', '#facc15');
            syncPattern(hp);
            ctx.fillStyle = hp;
          } else {
            ctx.fillStyle = '#f97316';
          }
          ctx.fill();
          buildTubePath(course, zi, 6 * kz);
          ctx.fillStyle = z.kind === 'pit' ? '#fde047' : '#fdba74'; ctx.fill();
          for (var r2 = 0; r2 < runs2.length; r2++) {
            fillTrackFloor(course, runs2[r2], levels[k]);
          }
          ctx.restore();
        });
        ctx.restore();
      }

      // 5a) 危险区：凹坑底面的红色径向光（静态部分）
      course.pits.forEach(function (p) {
        var f = SIM.frameAt(course, (p.s0 + p.s1) / 2);
        var sy = toScreenY(f.y);
        if (sy < -260 || sy > view.h + 260) return;
        var R = p.depth * view.scale;
        var sx = toScreenX(f.x + f.nx * p.depth * 0.5), syy = toScreenY(f.y + f.ny * p.depth * 0.5);
        ctx.save();
        buildTubePath(course, idxInRange(course, p.s0 - 320, p.s1 + 320, 0), 0);
        ctx.clip();
        var g = ctx.createRadialGradient(sx, syy, 0, sx, syy, R * 1.9);
        g.addColorStop(0, 'rgba(248,113,113,0.42)');
        g.addColorStop(1, 'rgba(248,113,113,0)');
        ctx.fillStyle = g;
        ctx.fillRect(sx - R * 2, syy - R * 2, R * 4, R * 4);
        ctx.restore();
      });
    }

    if (DY) {
      // 3) 底面流向箭头（每 180 世界单位一个，缓慢向下流动）
      var aStep = 180;
      var s1 = course.total;
      var phaseA = (activeRace() ? activeRace().t * 55 : 0) % aStep;
      var mk = markerCache(course);
      var aShift = Math.round(phaseA / aStep) * aStep;
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'rgba(186,230,253,0.12)';
      ctx.beginPath();
      for (var ai = 0; ai < mk.arrows.length; ai++) {
        var s = mk.arrows[ai].s + aShift;
        if (s > s1) continue;
        var f = mk.arrows[ai].f;
        var sy = toScreenY(f.y);
        if (sy < -60 || sy > view.h + 60) continue;
        var w = f.w - 46;
        if (w < 10) continue;
        var nx = f.nx, ny = f.ny, tx = f.tx, ty = f.ty;
        for (var side = -1; side <= 1; side += 2) {
          var ox = f.x + nx * w * side, oy = f.y + ny * w * side;
          var bx = ox - tx * 16 + nx * 11 * side, by = oy - ty * 16 + ny * 11 * side;
          ctx.moveTo(toScreenX(bx), toScreenY(by));
          ctx.lineTo(toScreenX(ox), toScreenY(oy));
          ctx.lineTo(toScreenX(ox - tx * 16 - nx * 11 * side), toScreenY(oy - ty * 16 - ny * 11 * side));
        }
      }
      ctx.stroke();

      // 4) 两侧墙上的跑道灯带（每 90 世界单位），领先球附近做跑马灯。
      //    按「常态灯」与「跑马灯」两种颜色各合并成一条路径，一次 fill —— 旧实现每个点
      //    一次 beginPath + fill（几百次 fill），是剩下的主要开销之一。
      var lead = state.frameRank.length ? state.frameRank[0] : null;
      var basePts = [], litPts = [];
      var mk2 = markerCache(course);
      for (var li = 0; li < mk2.lights.length; li++) {
        var s2 = mk2.lights[li].s;
        var f2 = mk2.lights[li].f;
        var sy2 = toScreenY(f2.y);
        if (sy2 < -40 || sy2 > view.h + 40) continue;
        var on = lead ? Math.max(0, 1 - Math.abs(lead.best - s2) / 600) : 0;
        var rr = 1.6 + on * 2.4;
        for (var sd = -1; sd <= 1; sd += 2) {
          var px = toScreenX(f2.x + f2.nx * (f2.w - 9) * sd);
          var py = toScreenY(f2.y + f2.ny * (f2.w - 9) * sd);
          (on > 0.02 ? litPts : basePts).push(px, py, rr);
        }
      }
      if (basePts.length) {
        ctx.fillStyle = 'rgba(125,211,252,0.28)';
        ctx.beginPath();
        for (i = 0; i < basePts.length; i += 3) { ctx.moveTo(basePts[i] + basePts[i + 2], basePts[i + 1]); ctx.arc(basePts[i], basePts[i + 1], basePts[i + 2], 0, Math.PI * 2); }
        ctx.fill();
      }
      if (litPts.length) {
        ctx.fillStyle = 'rgba(250,204,21,0.85)';
        ctx.beginPath();
        for (i = 0; i < litPts.length; i += 3) { ctx.moveTo(litPts[i] + litPts[i + 2], litPts[i + 1]); ctx.arc(litPts[i], litPts[i + 1], litPts[i + 2], 0, Math.PI * 2); }
        ctx.fill();
      }

      // 5b) 凹坑脉冲环 + ⚠（动态部分）
      var t = activeRace() ? activeRace().t : 0;
      course.pits.forEach(function (p) {
        var f = SIM.frameAt(course, (p.s0 + p.s1) / 2);
        var sy = toScreenY(f.y);
        if (sy < -260 || sy > view.h + 260) return;
        var R = p.depth * view.scale;
        var sx = toScreenX(f.x + f.nx * p.depth * 0.5), syy = toScreenY(f.y + f.ny * p.depth * 0.5);
        var pulse = 0.5 + 0.5 * Math.sin(t * 4);
        ctx.strokeStyle = 'rgba(248,113,113,' + (0.35 + pulse * 0.45) + ')';
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(sx, syy, R * (0.5 + pulse * 0.35), 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = 'rgba(254,202,202,0.95)';
        ctx.font = '700 ' + Math.max(12, 18 * Math.min(1.4, view.scale)) + 'px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('⚠', sx, syy);
      });

      // 6) 危险区：收窄喉口的内向箭头
      ctx.strokeStyle = 'rgba(249,115,22,0.9)';
      ctx.lineWidth = 3;
      for (var ti = 0; ti < course.throats.length; ti++) {
        var th = course.throats[ti];
        var ft = SIM.frameAt(course, th.s);
        var syt = toScreenY(ft.y);
        if (syt < -200 || syt > view.h + 200) continue;
        ctx.beginPath();
        for (var sd2 = -1; sd2 <= 1; sd2 += 2) {
          var ox2 = ft.x + ft.nx * sd2 * (ft.w + 70), oy2 = ft.y + ft.ny * sd2 * (ft.w + 70);
          var ix = ft.x + ft.nx * sd2 * (ft.w + 30), iy = ft.y + ft.ny * sd2 * (ft.w + 30);
          ctx.moveTo(toScreenX(ox2 + ft.tx * 22), toScreenY(oy2 + ft.ty * 22));
          ctx.lineTo(toScreenX(ix), toScreenY(iy));
          ctx.lineTo(toScreenX(ox2 - ft.tx * 22), toScreenY(oy2 - ft.ty * 22));
        }
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  /* ============================ 渲染：检查点 / 淘汰线 / 终点 ============================ */

  /**
   * 关卡门框 / 淘汰线 / 终点。phase 同 drawChannel：
   *   'static'  —— 门框（立柱 + 横梁 + 横幅）、终点棋盘格与旗杆
   *   'dynamic' —— 淘汰线激光、旗面波动、FINISH 文字
   */
  function drawMarkers(race, phase) {
    var ST = phase !== 'dynamic', DY = phase !== 'static';
    var course = race.course;
    var t = race.t;
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, view.availW, view.h); ctx.clip();
    ctx.textBaseline = 'middle';

    if (ST) {
      // —— 关卡入口：横跨赛道的发光门（两端立柱 + 横梁），横幅文字保持正立 ——
      course.levels.forEach(function (lv) {
        var f = lv.frame;
        var sy = toScreenY(f.y);
        if (sy < -240 || sy > view.h + 240) return;
        var sx = toScreenX(f.x);
        var span = f.w + 16;
        var ax = toScreenX(f.x + f.nx * span), ay = toScreenY(f.y + f.ny * span);
        var bx = toScreenX(f.x - f.nx * span), by = toScreenY(f.y - f.ny * span);
        ctx.save();
        ctx.lineCap = 'round';
        // 发光用「粗半透明 + 细亮」两层模拟，不用 shadowBlur（软件光栅化下很贵）
        ctx.strokeStyle = hexA(lv.color, 0.22);
        ctx.lineWidth = 18;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        ctx.strokeStyle = hexA(lv.color, 0.12);
        ctx.lineWidth = 26;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        ctx.strokeStyle = lv.color;
        ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        [[ax, ay], [bx, by]].forEach(function (pt) {
          ctx.fillStyle = '#0b1222';
          ctx.beginPath(); ctx.arc(pt[0], pt[1], 9, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = lv.color; ctx.lineWidth = 3; ctx.stroke();
          ctx.fillStyle = lighten(lv.color, 0.5);
          ctx.beginPath(); ctx.arc(pt[0], pt[1], 3.5, 0, Math.PI * 2); ctx.fill();
        });
        ctx.font = '800 17px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
        var title = '第 ' + lv.no + ' 关';
        var w1 = ctx.measureText(title).width;
        ctx.font = '600 12px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
        var w2 = ctx.measureText(lv.name).width;
        var bw = Math.min(Math.max(w1, w2) + 30, 220), bh = 44;
        var bxx = clamp(sx - bw / 2, 6, view.availW - bw - 6);
        // 固定到门框的世界位置；不能按瓦片/视口高度 clamp，否则邻接瓦片各多出一块同名招牌。
        var byy = Math.min(ay, by, sy) - bh - 14;
        ctx.fillStyle = 'rgba(6,10,22,0.9)';
        roundRect(bxx, byy, bw, bh, 10); ctx.fill();
        ctx.strokeStyle = lv.color; ctx.lineWidth = 2;
        roundRect(bxx, byy, bw, bh, 10); ctx.stroke();
        ctx.textAlign = 'center';
        ctx.fillStyle = lv.color;
        ctx.font = '800 17px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
        ctx.fillText(title, bxx + bw / 2, byy + 15);
        ctx.fillStyle = 'rgba(226,240,255,0.92)';
        ctx.font = '600 12px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
        ctx.fillText(fitText(ctx, lv.name, bw - 16), bxx + bw / 2, byy + 33);
        ctx.restore();
      });

      // —— 终点：棋盘格 + 两侧旗杆（静态部分） ——
      var ff = SIM.frameAt(course, course.finishS - 6);
      var fsy = toScreenY(ff.y);
      if (fsy > -220 && fsy < view.h + 220) {
        var fsx = toScreenX(ff.x);
        var fw = ff.w * 2 * view.scale;
        var fang = Math.atan2(ff.ny, ff.nx) - Math.PI / 2;
        ctx.save();
        ctx.translate(fsx, fsy);
        ctx.rotate(fang);
        var cols = 12, cw = fw / cols, ch = 16;
        for (var r = 0; r < 2; r++) {
          for (var c = 0; c < cols; c++) {
            ctx.fillStyle = ((r + c) % 2 === 0) ? 'rgba(255,255,255,0.95)' : 'rgba(17,24,39,0.95)';
            ctx.fillRect(-fw / 2 + c * cw, -ch + r * ch, cw, ch);
          }
        }
        ctx.strokeStyle = 'rgba(250,204,21,0.95)'; ctx.lineWidth = 3;
        ctx.strokeRect(-fw / 2, -ch, fw, ch * 2);
        for (var sside = -1; sside <= 1; sside += 2) {
          var poleX = sside * (fw / 2 + 16);
          ctx.strokeStyle = 'rgba(226,232,240,0.9)';
          ctx.lineWidth = 3;
          ctx.beginPath(); ctx.moveTo(poleX, ch); ctx.lineTo(poleX, -110); ctx.stroke();
        }
        ctx.restore();
      }
    }

    if (DY) {
      // —— 淘汰线：红色激光栅栏 ——
      course.elims.forEach(function (line) {
        var f = SIM.frameAt(course, line.s);
        var sy = toScreenY(f.y);
        if (sy < -90 || sy > view.h + 90) return;
        var sx = toScreenX(f.x);
        var wpx = f.w * view.scale;
        var ang = Math.atan2(f.ny, f.nx) - Math.PI / 2;
        ctx.save();
        ctx.translate(sx, sy);
        ctx.rotate(ang);
        if (!line.done) {
          var flick = 0.55 + 0.45 * Math.sin(t * 18 + line.round);
          // 发光用两层粗半透明描边模拟，不用 shadowBlur
          for (var k = -1; k <= 1; k++) {
            ctx.strokeStyle = 'rgba(248,113,113,' + (k === 0 ? 0.95 : 0.5) * flick + ')';
            ctx.lineWidth = k === 0 ? 3.5 : 1.6;
            ctx.beginPath();
            ctx.moveTo(-wpx, k * 7); ctx.lineTo(wpx, k * 7);
            ctx.stroke();
          }
          ctx.strokeStyle = 'rgba(248,113,113,' + (0.14 * flick) + ')';
          ctx.lineWidth = 12;
          ctx.beginPath(); ctx.moveTo(-wpx, 0); ctx.lineTo(wpx, 0); ctx.stroke();
          ctx.fillStyle = 'rgba(254,202,202,0.98)';
          ctx.font = '800 13px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('淘汰线 · 末位 3 人出局', 0, -22);
        } else {
          var a = line.flashT > 0 ? Math.min(1, line.flashT) : 0;
          ctx.strokeStyle = 'rgba(148,163,184,0.45)';
          ctx.setLineDash([5, 9]); ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-wpx, 0); ctx.lineTo(wpx, 0); ctx.stroke();
          ctx.setLineDash([]);
          if (a > 0) {
            ctx.strokeStyle = 'rgba(255,255,255,' + a + ')';
            ctx.lineWidth = 10 * a;
            ctx.beginPath(); ctx.moveTo(-wpx, 0); ctx.lineTo(wpx, 0); ctx.stroke();
          }
        }
        ctx.restore();
      });

      // —— 终点旗面（sin 波动）+ FINISH 文字 ——
      var ff2 = SIM.frameAt(course, course.finishS - 6);
      var fsy2 = toScreenY(ff2.y);
      if (fsy2 > -220 && fsy2 < view.h + 220) {
        var fsx2 = toScreenX(ff2.x);
        var fw2 = ff2.w * 2 * view.scale;
        var fang2 = Math.atan2(ff2.ny, ff2.nx) - Math.PI / 2;
        var ch2 = 16;
        ctx.save();
        ctx.translate(fsx2, fsy2);
        ctx.rotate(fang2);
        for (var ss = -1; ss <= 1; ss += 2) {
          var poleX2 = ss * (fw2 / 2 + 16);
          ctx.beginPath();
          ctx.moveTo(poleX2, -110);
          for (var q = 0; q <= 10; q++) {
            ctx.lineTo(poleX2 + ss * q * 4.5, -110 + Math.sin(t * 5 + q * 0.7 + ss) * 4 + q * 0.6);
          }
          for (var q2 = 10; q2 >= 0; q2--) {
            ctx.lineTo(poleX2 + ss * q2 * 4.5, -84 + Math.sin(t * 5 + q2 * 0.7 + ss) * 4 + q2 * 0.6);
          }
          ctx.closePath();
          ctx.fillStyle = ss > 0 ? 'rgba(250,204,21,0.92)' : 'rgba(56,189,248,0.92)';
          ctx.fill();
        }
        ctx.restore();
        if (fsy2 > 0 && fsy2 < view.h) {
          ctx.fillStyle = 'rgba(250,204,21,0.98)';
          ctx.font = '800 17px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('FINISH · 终点', fsx2, fsy2 - 130);
        }
      }
    }
    ctx.restore();
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /* ============================ 渲染：障碍物 ============================ */

  function drawCapsule(ax, ay, bx, by, half, colA, colB, glow, motif) {
    var ang = Math.atan2(by - ay, bx - ax);
    var nx = -Math.sin(ang), ny = Math.cos(ang);
    var g = ctx.createLinearGradient(ax + nx * half, ay + ny * half, ax - nx * half, ay - ny * half);
    g.addColorStop(0, colA);
    g.addColorStop(1, colB);
    ctx.lineCap = 'round';
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = half * 2 + 2;
    ctx.beginPath(); ctx.moveTo(ax + 2, ay + 4); ctx.lineTo(bx + 2, by + 4); ctx.stroke();
    if (glow) {
      ctx.strokeStyle = glow;
      ctx.lineWidth = half * 2 + 6;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
    }
    ctx.strokeStyle = g;
    ctx.lineWidth = half * 2;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = Math.max(1, half * 0.14);
    ctx.beginPath(); ctx.moveTo(ax - nx * half * 0.55, ay - ny * half * 0.55);
    ctx.lineTo(bx - nx * half * 0.55, by - ny * half * 0.55); ctx.stroke();
    if (motif) {
      var len = hypot(bx - ax, by - ay);
      ctx.save(); ctx.translate((ax + bx) / 2, (ay + by) / 2); ctx.rotate(ang);
      // 花纹只画在碰撞实体内部；阴影和光晕保持半透明。
      roundRect(-len / 2 - half, -half, len + half * 2, half * 2, half); ctx.clip();
      if (motif === 'bar' || motif === 'gate') {
        ctx.fillStyle = motif === 'gate' ? '#241b10' : '#35102e';
        for (var x = -len / 2 - half * 2; x < len / 2 + half; x += half * 2.3) {
          ctx.beginPath(); ctx.moveTo(x, half); ctx.lineTo(x + half * 0.8, half);
          ctx.lineTo(x + half * 2.1, -half); ctx.lineTo(x + half * 1.3, -half); ctx.closePath(); ctx.fill();
        }
      } else {
        ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 1.5;
        for (var x2 = -len / 2 + half; x2 < len / 2 - half; x2 += Math.max(18, half * 2.2)) {
          ctx.beginPath();
          if (motif === 'mill' || motif === 'sweeper') {
            ctx.moveTo(x2 - half * 0.3, -half * 0.5); ctx.lineTo(x2 + half * 0.3, 0); ctx.lineTo(x2 - half * 0.3, half * 0.5);
          } else {
            ctx.moveTo(x2, -half * 0.6); ctx.lineTo(x2, half * 0.6);
          }
          ctx.stroke();
        }
      }
      ctx.restore();
    }
  }

  function drawBars(race, t, objs) {
    objs.bars.forEach(function (bar) {
      var ang = bar.phase + bar.omega * t;
      var ca = Math.cos(ang), sa = Math.sin(ang);
      var pose = SIM.circleAt ? SIM.circleAt(bar, t) : { x: bar.cx, y: bar.cy };
      var cx = toScreenX(pose.x), cy = toScreenY(pose.y);
      var hx = ca * bar.half * view.scale, hy = sa * bar.half * view.scale;
      if (Math.max(cy - Math.abs(hy), cy + Math.abs(hy)) < -80 && cy < -80) return;
      if (cy < -140 || cy > view.h + 140) return;
      var hw = Math.max(2, bar.thick * view.scale);
      // 地面扫掠圆：提示危险范围
      ctx.strokeStyle = 'rgba(244,114,182,0.18)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 8]);
      ctx.beginPath();
      ctx.arc(cx, cy, (bar.half + bar.thick) * view.scale, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      // 2 帧拖影（旧实现 3 帧；只在屏幕内的障碍才画）
      for (var k = 2; k >= 1; k--) {
        var a2 = ang - bar.omega * 0.055 * k;
        var c2 = Math.cos(a2), s2 = Math.sin(a2);
        ctx.globalAlpha = 0.16 * (3 - k);
        drawCapsule(cx - c2 * bar.half * view.scale, cy - s2 * bar.half * view.scale,
          cx + c2 * bar.half * view.scale, cy + s2 * bar.half * view.scale, hw,
          '#be185d', '#f472b6', null);
        ctx.globalAlpha = 1;
      }
      drawCapsule(cx - hx, cy - hy, cx + hx, cy + hy, hw, '#a31368', '#ff9edb', 'rgba(244,114,182,0.25)', 'bar');
      // 两端金属铆钉：半径必须落在胶囊本体（半宽 hw）之内，否则画面会大于碰撞体
      [-1, 1].forEach(function (s) {
        ctx.fillStyle = '#e5e7eb';
        ctx.beginPath(); ctx.arc(cx + hx * s, cy + hy * s, hw * 0.9, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(17,24,39,0.7)';
        ctx.beginPath(); ctx.arc(cx + hx * s, cy + hy * s, hw * 0.45, 0, Math.PI * 2); ctx.fill();
      });
      // 中心齿轮轴：撞的是挡板本体，齿轮轴不能比 hw 大太多
      var hubR = hw * 1.1;
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      for (var g2 = 0; g2 < 16; g2++) {
        var ga = g2 * Math.PI / 8 + ang;
        var gr = g2 % 2 ? hubR * 0.78 : hubR;
        ctx[g2 ? 'lineTo' : 'moveTo'](cx + Math.cos(ga) * gr, cy + Math.sin(ga) * gr);
      }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath(); ctx.arc(cx, cy, hubR * 0.5, 0, Math.PI * 2); ctx.fill();
    });
  }

  function drawMills(race, t, objs) {
    objs.mills.forEach(function (m) {
      var pose = SIM.circleAt ? SIM.circleAt(m, t) : { x: m.cx, y: m.cy };
      var cx = toScreenX(pose.x), cy = toScreenY(pose.y);
      if (cy < -160 || cy > view.h + 160) return;
      var half = m.half * view.scale, hw = Math.max(2.5, m.thick * view.scale);
      for (var a = 0; a < m.arms; a++) {
        var ang = m.phase + m.omega * t + a * 2 * Math.PI / m.arms;
        var c1 = Math.cos(ang), s1 = Math.sin(ang);
        drawCapsule(cx - c1 * half, cy - s1 * half, cx + c1 * half, cy + s1 * half, hw,
          '#a6530c', '#ffe37b', 'rgba(251,191,36,0.22)', 'mill');
        // 叶尖发光：不超出叶片本体半宽
        ctx.fillStyle = 'rgba(253,224,71,0.95)';
        ctx.beginPath(); ctx.arc(cx + c1 * half, cy + s1 * half, hw * 0.95, 0, Math.PI * 2); ctx.fill();
      }
      var hubR = hw * 1.1;
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      for (var g2 = 0; g2 < 20; g2++) {
        var ga = g2 * Math.PI / 10 - m.omega * t;
        var gr = g2 % 2 ? hubR * 0.8 : hubR;
        ctx[g2 ? 'lineTo' : 'moveTo'](cx + Math.cos(ga) * gr, cy + Math.sin(ga) * gr);
      }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#fde68a';
      ctx.beginPath(); ctx.arc(cx, cy, hubR * 0.42, 0, Math.PI * 2); ctx.fill();
    });
  }

  function drawPendulums(race, t, objs) {
    objs.pendulums.forEach(function (pd) {
      var ph = pd.w * t + pd.phase;
      var th = pd.amp * Math.sin(ph);
      var cp = Math.cos(th), sp = Math.sin(th);
      var dx = pd.rx * cp - pd.ry * sp, dy = pd.rx * sp + pd.ry * cp;
      var px = toScreenX(pd.px), py = toScreenY(pd.py);
      var bx = toScreenX(pd.px + dx * pd.arm), by = toScreenY(pd.py + dy * pd.arm);
      if (Math.max(py, by) < -120 || Math.min(py, by) > view.h + 120) return;
      var hw = Math.max(2, pd.thick * view.scale);
      // 2 帧拖影（旧实现 3 帧）
      for (var k = 2; k >= 1; k--) {
        var ph2 = ph - 0.09 * k;
        var th2 = pd.amp * Math.sin(ph2);
        var c2 = Math.cos(th2), s2 = Math.sin(th2);
        var dx2 = pd.rx * c2 - pd.ry * s2, dy2 = pd.rx * s2 + pd.ry * c2;
        ctx.globalAlpha = 0.17 * (3 - k);
        drawCapsule(px, py, toScreenX(pd.px + dx2 * pd.arm), toScreenY(pd.py + dy2 * pd.arm), hw,
          '#7f1d1d', '#ef4444', null);
        ctx.globalAlpha = 1;
      }
      // 整根摆臂也是胶囊碰撞体，画实心红色机械臂，避免“链条可穿过”的误解。
      drawCapsule(px, py, bx, by, hw, '#891f2a', '#fb7185', null, 'pendulum');
      // 锁链嵌在实体臂中
      var segs = 10;
      ctx.strokeStyle = 'rgba(203,213,225,0.75)';
      ctx.lineWidth = Math.max(1.2, hw * 0.5);
      ctx.beginPath();
      for (var i2 = 0; i2 <= segs; i2++) {
        var tt = i2 / segs;
        var lx = px + (bx - px) * tt, ly = py + (by - py) * tt;
        if (i2 === 0) ctx.moveTo(lx, ly); else ctx.lineTo(lx, ly);
      }
      ctx.stroke();
      // 锤头（带尖刺）—— 尺寸服从物理：碰撞体是半径 thick 的胶囊，
      // 所以本体半径 = hw，尖刺最远 1.1×hw（略小于 1.15 的外接比阈值），
      // 光晕 1.4×hw 是半透明的、不计入实心外接半径。
      // 旧实现本体 3.4×hw、尖刺 4.9×hw、光晕 5.8×hw，球看起来是直接穿过锤子。
      var R = hw;
      ctx.fillStyle = 'rgba(239,68,68,0.28)';
      ctx.beginPath(); ctx.arc(bx, by, R * 1.4, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath();
      for (var sp2 = 0; sp2 < 16; sp2++) {
        var sa2 = sp2 * Math.PI / 8;
        var sr = sp2 % 2 ? R * 1.1 : R;
        ctx[sp2 ? 'lineTo' : 'moveTo'](bx + Math.cos(sa2) * sr, by + Math.sin(sa2) * sr);
      }
      ctx.closePath();
      var gg = ctx.createRadialGradient(bx - R * 0.3, by - R * 0.3, 0, bx, by, R);
      gg.addColorStop(0, '#fecaca');
      gg.addColorStop(1, '#b91c1c');
      ctx.fillStyle = gg; ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.5; ctx.stroke();
      // 枢轴（固定在臂的另一端，半径不超过臂本体）
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath(); ctx.arc(px, py, hw * 0.9, 0, Math.PI * 2); ctx.fill();
    });
  }

  function drawPlats(race, t, objs) {
    objs.plats.forEach(function (p) {
      var ph = (t / p.period) * Math.PI * 2 + p.phase;
      var off = Math.sin(ph) * p.amp;
      var voff = Math.cos(ph);
      var dir = p.axis === 'tan' ? { x: p.tx, y: p.ty } : { x: p.nx, y: p.ny };
      var cxw = p.bx + dir.x * (p.lat + off), cyw = p.by + dir.y * (p.lat + off);
      var axD = p.orient === 'normal' ? p.nx : p.tx, ayD = p.orient === 'normal' ? p.ny : p.ty;
      var ax = toScreenX(cxw - axD * p.half), ay = toScreenY(cyw - ayD * p.half);
      var bx = toScreenX(cxw + axD * p.half), by = toScreenY(cyw + ayD * p.half);
      if (Math.max(ay, by) < -100 || Math.min(ay, by) > view.h + 100) return;
      var hw = Math.max(3, p.thick * view.scale);
      var nearEnd = Math.abs(voff) > 0.86;
      var blink = nearEnd ? (0.5 + 0.5 * Math.sin(t * 22)) : 0;
      // 行程轨
      var rx0 = toScreenX(p.bx + dir.x * (p.lat - p.amp)), ry0 = toScreenY(p.by + dir.y * (p.lat - p.amp));
      var rx1 = toScreenX(p.bx + dir.x * (p.lat + p.amp)), ry1 = toScreenY(p.by + dir.y * (p.lat + p.amp));
      ctx.strokeStyle = 'rgba(34,211,238,0.28)';
      ctx.setLineDash([4, 6]); ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(rx0, ry0); ctx.lineTo(rx1, ry1); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(34,211,238,0.5)';
      [[rx0, ry0], [rx1, ry1]].forEach(function (pt) {
        ctx.beginPath(); ctx.arc(pt[0], pt[1], 3, 0, Math.PI * 2); ctx.fill();
      });
      // 本体
      if (p.kind === 'sweeper') {
        drawCapsule(ax, ay, bx, by, hw, '#6d28d9', '#ddd6fe', 'rgba(167,139,250,0.22)', 'sweeper');
        // 扫掠方向箭头
        ctx.fillStyle = 'rgba(165,243,252,0.95)';
        var mx = (ax + bx) / 2, my = (ay + by) / 2;
        var sgn = voff >= 0 ? 1 : -1;
        ctx.beginPath();
        ctx.moveTo(mx + dir.x * 14 * sgn, my + dir.y * 14 * sgn);
        ctx.lineTo(mx - dir.y * 9 * sgn - dir.x * 5 * sgn, my + dir.x * 9 * sgn - dir.y * 5 * sgn);
        ctx.lineTo(mx + dir.y * 9 * sgn - dir.x * 5 * sgn, my - dir.x * 9 * sgn - dir.y * 5 * sgn);
        ctx.closePath(); ctx.fill();
      } else if (p.kind === 'gate') {
        drawCapsule(ax, ay, bx, by, hw, '#a16207', '#fde68a', 'rgba(250,204,21,0.22)', 'gate');
      } else {
        // 金属板：顶面亮、侧面暗
        drawCapsule(ax, ay, bx, by, hw, '#075985', '#bae6fd', 'rgba(56,189,248,0.25)', 'platform');
      }
      if (blink > 0) {
        ctx.strokeStyle = 'rgba(250,204,21,' + (0.8 * blink) + ')';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
      }
    });
  }

  function drawBoosts(race, t, objs) {
    objs.boosts.forEach(function (g) {
      var f = SIM.frameAt(race.course, g.s0 + g.len * 0.5);
      var sx = toScreenX(f.x + f.nx * g.lat), sy = toScreenY(f.y + f.ny * g.lat);
      if (sy < -90 || sy > view.h + 90) return;
      var flash = g.flashT > 0 ? g.flashT : 0;
      var halfLen = g.len * 0.5 * view.scale, halfW = g.halfW * view.scale;
      var ang = Math.atan2(f.ty, f.tx);
      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(ang);
      ctx.fillStyle = 'rgba(16,185,129,' + (0.22 + flash * 0.5) + ')';
      ctx.fillRect(-halfLen, -halfW, halfLen * 2, halfW * 2);
      ctx.fillStyle = '#123f39';
      ctx.fillRect(-halfLen, -halfW, halfLen * 2, 5);
      ctx.fillRect(-halfLen, halfW - 5, halfLen * 2, 5);
      ctx.strokeStyle = 'rgba(52,211,153,0.85)';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(-halfLen, -halfW, halfLen * 2, halfW * 2);
      // 3 个流动箭头
      for (var k = 0; k < 3; k++) {
        var ph = ((t * 1.6 + k / 3) % 1);
        var axx = -halfLen + ph * halfLen * 2;
        var lit = ph > 0.66 ? 1 : 0.35;
        ctx.strokeStyle = 'rgba(167,243,208,' + (lit * (0.6 + flash * 0.4)) + ')';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(axx - 8, -halfW * 0.55);
        ctx.lineTo(axx + 8, 0);
        ctx.lineTo(axx - 8, halfW * 0.55);
        ctx.stroke();
      }
      if (flash > 0) {
        ctx.fillStyle = 'rgba(220,252,231,' + (flash * 0.45) + ')';
        ctx.fillRect(-halfLen, -halfW, halfLen * 2, halfW * 2);
      }
      ctx.restore();
    });
  }

  function drawRoundObstacles(race, t, objs) {
    objs.pegs.forEach(function (pg) {
      var pose = SIM.circleAt ? SIM.circleAt(pg, t) : { x: pg.cx, y: pg.cy };
      var sx = toScreenX(pose.x), sy = toScreenY(pose.y);
      if (sy < -60 || sy > view.h + 60) return;
      var r = Math.max(3, pg.r * view.scale);
      if (pg.ripple > 0) {        ctx.strokeStyle = 'rgba(251,191,36,' + Math.max(0, pg.ripple) * 0.8 + ')';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(sx, sy, r + (1 - pg.ripple) * 26, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = 'rgba(251,191,36,0.18)';
      ctx.beginPath(); ctx.arc(sx, sy, r * 1.9, 0, Math.PI * 2); ctx.fill();
      var g = ctx.createRadialGradient(sx - r * 0.4, sy - r * 0.4, 0, sx, sy, r);
      g.addColorStop(0, '#e0f2fe');
      g.addColorStop(0.6, '#829bad');
      g.addColorStop(1, '#1e3a50');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.stroke();
      // 钉阵是金属螺栓：十字槽，和弹射蘑菇的靶心清楚区分。
      ctx.strokeStyle = '#102335'; ctx.lineWidth = Math.max(1.5, r * 0.2);
      ctx.beginPath(); ctx.moveTo(sx - r * 0.45, sy); ctx.lineTo(sx + r * 0.45, sy);
      ctx.moveTo(sx, sy - r * 0.45); ctx.lineTo(sx, sy + r * 0.45); ctx.stroke();
    });
    objs.bumpers.forEach(function (bp) {
      var pose = SIM.circleAt ? SIM.circleAt(bp, t) : { x: bp.cx, y: bp.cy };
      var sx = toScreenX(pose.x), sy = toScreenY(pose.y);
      if (sy < -70 || sy > view.h + 70) return;
      var hit = bp.hitT > 0 ? bp.hitT : 0;
      var r = Math.max(4, bp.r * view.scale) * (1 + hit * 0.1);   // 放大不超过 1.1×，与碰撞体一致
      var g = ctx.createRadialGradient(sx, sy - r * 0.4, 0, sx, sy, r);
      g.addColorStop(0, '#f0fdf4');
      g.addColorStop(0.45, '#34d399');
      g.addColorStop(1, '#065f46');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(sx, sy, r, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#bbf7d0'; ctx.lineWidth = Math.max(1.5, r * 0.08);
      ctx.beginPath(); ctx.arc(sx, sy, r * 0.7, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#ecfccb'; ctx.beginPath();
      ctx.moveTo(sx + r * 0.08, sy - r * 0.44); ctx.lineTo(sx - r * 0.27, sy + r * 0.04);
      ctx.lineTo(sx - r * 0.02, sy + r * 0.04); ctx.lineTo(sx - r * 0.08, sy + r * 0.44);
      ctx.lineTo(sx + r * 0.28, sy - r * 0.08); ctx.lineTo(sx + r * 0.04, sy - r * 0.08); ctx.closePath(); ctx.fill();
      if (hit > 0) {
        ctx.strokeStyle = 'rgba(167,243,208,' + hit + ')';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(sx, sy, r + (1 - hit) * 40, 0, Math.PI * 2); ctx.stroke();
      }
    });
  }

  function drawObjects(race, t) {
    var course = race.course, objs = course.objects;
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, view.availW, view.h); ctx.clip();
    // 泥沼：棕色底面 + 冒泡
    course.muds.forEach(function (m) {
      var f = SIM.frameAt(course, (m.s0 + m.s1) / 2);
      var sy = toScreenY(f.y);
      if (sy < -300 || sy > view.h + 300) return;
      // 只铺在泥沼弧长范围内的底面上（旧实现两端各补一个整圆 → 一个棕色大圆饼盖住赛道）
      overlayFloor(course, m.s0, m.s1, 0, '#78350f', 0.55);
      // 两端"减速"标牌：横跨赛道的虚线 + 文字
      [m.s0, m.s1].forEach(function (s, ii) {
        var fe = SIM.frameAt(course, s);
        ctx.strokeStyle = 'rgba(251,146,60,0.85)';
        ctx.lineWidth = 2.5;
        ctx.setLineDash([8, 6]);
        ctx.beginPath();
        ctx.moveTo(toScreenX(fe.x + fe.nx * fe.w), toScreenY(fe.y + fe.ny * fe.w));
        ctx.lineTo(toScreenX(fe.x - fe.nx * fe.w), toScreenY(fe.y - fe.ny * fe.w));
        ctx.stroke();
        ctx.setLineDash([]);
        if (ii === 0) {
          var lx = toScreenX(fe.x), ly = toScreenY(fe.y) - 12;
          ctx.font = '800 12px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          var tw = ctx.measureText('减速泥沼').width + 14;
          ctx.fillStyle = 'rgba(28,12,2,0.85)';
          roundRect(lx - tw / 2, ly - 10, tw, 20, 6); ctx.fill();
          ctx.fillStyle = '#fdba74';
          ctx.fillText('减速泥沼', lx, ly + 1);
        }
      });
      for (var b2 = 0; b2 < 6; b2++) {
        var bs = m.s0 + (m.s1 - m.s0) * ((b2 / 6 + t * 0.12) % 1);
        var fb = SIM.frameAt(course, bs);
        var lat = fb.w * 0.6 * Math.sin(b2 * 2.1 + t * 0.7);
        ctx.fillStyle = 'rgba(217,119,6,0.6)';
        ctx.beginPath();
        ctx.arc(toScreenX(fb.x + fb.nx * lat), toScreenY(fb.y + fb.ny * lat), 3 + (b2 % 3), 0, Math.PI * 2);
        ctx.fill();
      }
    });
    drawBars(race, t, objs);
    drawMills(race, t, objs);
    drawPendulums(race, t, objs);
    drawPlats(race, t, objs);
    drawBoosts(race, t, objs);
    drawRoundObstacles(race, t, objs);
    drawObstacleLabels(race, t);
    ctx.restore();
  }

  // 同类仅给屏幕内的一件障碍贴牌；避免密集钉阵被文字遮盖。
  function drawObstacleLabels(race, t) {
    var o = race.course.objects, occupied = [];
    function label(list, name, color, position) {
      for (var i = 0; i < list.length; i++) {
        var p = position(list[i]), x = toScreenX(p.x), y = toScreenY(p.y) - p.r * view.scale - 16;
        ctx.font = '700 10px system-ui,"Microsoft YaHei",sans-serif';
        var w = ctx.measureText(name).width + 16;
        if (x < w / 2 + 8 || x > view.availW - w / 2 - 8 || y < 165 || y > view.h - 100) continue;
        if (occupied.some(function (b) { return Math.abs(b.x - x) < (b.w + w) / 2 + 8 && Math.abs(b.y - y) < 25; })) continue;
        ctx.fillStyle = '#0a131f'; roundRect(x - w / 2, y - 10, w, 20, 5); ctx.fill();
        ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = color; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(name, x, y);
        occupied.push({ x: x, y: y, w: w }); return;
      }
    }
    label(o.bars, '旋转挡板', '#f9a8d4', function (b) { return { x: b.cx, y: b.cy, r: b.thick }; });
    label(o.mills, '风车', '#fde68a', function (b) { return { x: b.cx, y: b.cy, r: b.thick }; });
    label(o.pendulums, '摆锤', '#fda4af', function (b) {
      var a = b.amp * Math.sin(b.w * t + b.phase), c = Math.cos(a), s = Math.sin(a);
      return { x: b.px + (b.rx * c - b.ry * s) * b.arm, y: b.py + (b.rx * s + b.ry * c) * b.arm, r: b.thick };
    });
    ['slab', 'gate', 'sweeper'].forEach(function (kind, i) {
      label(o.plats.filter(function (b) { return b.kind === kind; }), ['升降平台', '闸门', '横扫推杆'][i], ['#7dd3fc', '#fde68a', '#c4b5fd'][i], function (b) {
        var off = b.lat + Math.sin(t / b.period * Math.PI * 2 + b.phase) * b.amp;
        var dx = b.axis === 'tan' ? b.tx : b.nx, dy = b.axis === 'tan' ? b.ty : b.ny;
        return { x: b.bx + dx * off, y: b.by + dy * off, r: b.thick };
      });
    });
    label(o.pegs, '金属钉阵', '#cbd5e1', function (b) { return { x: b.cx, y: b.cy, r: b.r }; });
    label(o.bumpers, '弹射蘑菇', '#86efac', function (b) { return { x: b.cx, y: b.cy, r: b.r }; });
  }
  function ballScreen(b) {
    var x = b.px + (b.x - b.px) * state.alpha;
    var y = b.py + (b.y - b.py) * state.alpha;
    if (!isFinite(x)) x = b.x;
    if (!isFinite(y)) y = b.y;
    return { x: x, y: y };
  }

  /* ============================ 渲染侧特效状态 ============================ */
  /* 以下全部只影响画面：只读球的渲染字段，绝不写回物理状态 */

  var TRAIL_MIN_SPEED = 700;     // 拖影起始速度（世界单位/秒）
  var DEFORM_MS = 80;            // 撞击形变持续时长（毫秒）
  var DEFORM_HIT_POWER = 0.45;   // 触发形变的冲量阈值（约对应 |vn| > 400）
  var DEFORM = {};               // b.idx → { t, nx, ny, amt }，仅渲染侧持有

  /** 按位置找最近的存活球：vfx 的 idx 是障碍物索引，不能当球索引使用 */
  function nearestBall(race, x, y) {
    var best = null, bd = Infinity;
    var lim = (BALL_R * 4) * (BALL_R * 4);      // 超过 4 个球半径视为无关事件
    for (var i = 0; i < race.balls.length; i++) {
      var b = race.balls[i];
      if (!b.alive) continue;
      var dx = b.x - x, dy = b.y - y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = b; }
    }
    return bd <= lim ? best : null;
  }

  /** 撞击形变：power 超过阈值时记下时间戳 + 法线方向（存在渲染侧 map，不写回球对象） */
  function markDeform(race, e, power) {
    if (!race || !(power > DEFORM_HIT_POWER)) return;
    var b = nearestBall(race, e.x, e.y);
    if (!b) return;
    var nx = 0, ny = 0;
    if (b.contactN) { nx = b.contactN.x || 0; ny = b.contactN.y || 0; }   // 只读接触法线
    if (!nx && !ny) {                    // 尚无接触法线时退回运动方向
      var sp = Math.sqrt((b.vx || 0) * (b.vx || 0) + (b.vy || 0) * (b.vy || 0)) || 1;
      nx = (b.vx || 0) / sp; ny = (b.vy || 0) / sp;
    }
    var L = Math.sqrt(nx * nx + ny * ny) || 1;
    DEFORM[b.idx] = {
      t: performance.now(), nx: nx / L, ny: ny / L,
      amt: 0.08 + 0.04 * clamp(power, 0, 1),      // 沿法线压扁 8% ~ 12%
    };
  }

  /** 取当前形变量；80ms 内线性恢复，恢复完清除 */
  function ballDeform(b) {
    var d = DEFORM[b.idx];
    if (!d) return null;
    var k = (performance.now() - d.t) / DEFORM_MS;
    if (k >= 1) { delete DEFORM[b.idx]; return null; }
    return { ang: Math.atan2(d.ny, d.nx), amt: d.amt * (1 - k) };
  }

  /** 速度拖影：> 700 时沿速度反方向叠 2~3 个渐隐小头像（复用预渲染的头像图，不新建 canvas） */
  function drawSpeedTrails(p, b, sx, sy, rr) {
    var vx = b.vx || 0, vy = b.vy || 0;
    var sp = Math.sqrt(vx * vx + vy * vy);
    if (sp <= TRAIL_MIN_SPEED) return;
    var n = sp >= 1100 ? 3 : 2;
    var stepPx = clamp(6 + (sp - TRAIL_MIN_SPEED) / 400 * 8, 6, 14) * view.scale;   // 6~14 世界单位
    var dx = vx / sp * stepPx, dy = vy / sp * stepPx;
    for (var i = 1; i <= n; i++) {
      var tx = sx - dx * i, ty = sy - dy * i;
      if (tx < -60 || tx > view.availW + 60 || ty < -80 || ty > view.h + 80) continue;   // 屏幕外不画
      ctx.save();
      ctx.globalAlpha = 0.28 - (i - 1) * (0.23 / (n - 1));   // 0.28 → 0.05
      drawBallAvatar(p, tx, ty, rr * 0.78, b.angle);
      ctx.restore();
    }
  }

  /**
   * 球的静态外观预渲染成两张小图（挂在 p.sprite 上，scale / dpr / 头像加载状态变化时重建）：
   *   ring —— 光晕 + 色环 + role 圈（不随时间变化）
   *   face —— 圆形头像 + 白描边（每帧只做一次旋转 + drawImage）
   * 旧实现每个球每帧都要 createRadialGradient 一次、arc+clip 一次，18 个球就是 18 次裁剪，
   * 是 clip 调用数居高不下的主因。
   */
  function ballSprite(p, r) {
    var pal = palette(p.qq, p.role);
    var rr = r * 0.8;
    var faceHalf = rr + 3;
    var half = r * 2.2;
    var key = Math.round(r * state.dpr) + ':' + (p.imgOk ? 1 : 0) + ':' + state.dpr + ':' + (p.img ? 1 : 0);
    if (p.sprite && p.sprite.key === key) return p.sprite;
    var dpr = state.dpr;
    function mk(px, draw) {
      var c = document.createElement('canvas');
      c.width = c.height = Math.max(2, Math.ceil(px * 2 * dpr));
      var g = c.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.translate(px, px);
      draw(g);
      return c;
    }
    var ring = mk(half, function (g) {
      var gg = g.createRadialGradient(0, 0, rr * 0.75, 0, 0, rr * 2.1);
      gg.addColorStop(0, pal.glow + '0.42)');
      gg.addColorStop(1, pal.glow + '0)');
      g.fillStyle = gg;
      g.beginPath(); g.arc(0, 0, rr * 2.1, 0, Math.PI * 2); g.fill();
      g.beginPath(); g.arc(0, 0, rr, 0, Math.PI * 2);
      g.fillStyle = pal.fill; g.fill();
      g.lineWidth = 3.5; g.strokeStyle = pal.ring; g.stroke();
      if (pal.roleRing) {
        g.beginPath(); g.arc(0, 0, rr + 3.5, 0, Math.PI * 2);
        g.lineWidth = 2.5; g.strokeStyle = pal.roleRing; g.stroke();
      }
    });
    var face = mk(faceHalf, function (g) {
      if (p.imgOk && p.img) {
        g.save();
        g.beginPath(); g.arc(0, 0, rr, 0, Math.PI * 2); g.clip();
        g.drawImage(p.img, -rr, -rr, rr * 2, rr * 2);   // 只裁剪不取像素 → 无污染
        g.restore();
      } else {
        g.fillStyle = pal.fill;
        g.beginPath(); g.arc(0, 0, rr, 0, Math.PI * 2); g.fill();
        g.fillStyle = pal.ring;
        g.font = '700 ' + Math.round(rr * 1.05) + 'px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
        g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(firstGrapheme(p.name), 0, 1);
      }
      g.beginPath(); g.arc(0, 0, rr, 0, Math.PI * 2);
      g.strokeStyle = '#ffffff'; g.lineWidth = 2; g.stroke();
    });
    p.sprite = { key: key, ring: ring, face: face, half: half, faceHalf: faceHalf };
    return p.sprite;
  }

  /** 头像：把预渲染好的圆形头像按 b.angle 转一下贴上去；外圈色环 / role 描边不旋转 */
  function drawBallAvatar(p, sx, sy, r, angle) {
    var sp = ballSprite(p, r);
    var fh = sp.faceHalf;
    ctx.save();
    ctx.translate(sx, sy);
    if (angle) ctx.rotate(angle);
    ctx.drawImage(sp.face, -fh, -fh, fh * 2, fh * 2);
    ctx.restore();
  }

  function drawBalls(race) {
    var i, b, p;
    // 淘汰动画中的球先画
    for (i = 0; i < race.balls.length; i++) {
      b = race.balls[i];
      if (!b.dying) continue;
      var pos = ballScreen(b);
      var sx = toScreenX(pos.x), sy = toScreenY(pos.y);
      var r = BALL_R * view.scale * (1 - b.dieT / SIM.DEATH_TIME);
      if (r < 1) continue;
      ctx.save();
      ctx.globalAlpha = clamp(1 - b.dieT / SIM.DEATH_TIME, 0, 1);
      ctx.translate(sx, sy); ctx.rotate(b.dieRot);
      drawBallAvatar(race.players[b.idx] || b, 0, 0, r, b.angle);
      ctx.restore();
      // 破灭冲击环
      var k = clamp(b.dieT / SIM.DEATH_TIME, 0, 1);
      ctx.strokeStyle = 'rgba(248,113,113,' + (0.85 * (1 - k)) + ')';
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(sx, sy, r + k * 60, 0, Math.PI * 2); ctx.stroke();
    }
    // 存活球
    for (i = 0; i < race.balls.length; i++) {
      b = race.balls[i];
      if (!b.alive) continue;
      p = race.players[b.idx] || b;
      var pos2 = ballScreen(b);
      var sx2 = toScreenX(pos2.x), sy2 = toScreenY(pos2.y);
      var rr = BALL_R * view.scale;
      if (sy2 < -80 || sy2 > view.h + 80) continue;
      var pal = palette(p.qq, p.role);
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath();
      ctx.ellipse(sx2 + 3, sy2 + rr * 0.6, rr * 0.92, rr * 0.4, 0, 0, Math.PI * 2); ctx.fill();
      // 速度拖影：画在球本体之前
      drawSpeedTrails(p, b, sx2, sy2, rr);
      // 撞击形变：沿法线压扁，80ms 内线性恢复（纯渲染变换）
      var df = ballDeform(b);
      ctx.save();
      if (df) {
        ctx.translate(sx2, sy2);
        ctx.rotate(df.ang);
        ctx.scale(1 - df.amt, 1 + df.amt * 0.5);
        ctx.rotate(-df.ang);
        ctx.translate(-sx2, -sy2);
      }
      // 光晕 + 色环 + role 外圈：预渲染成一张小图，这里只贴一次
      var spb = ballSprite(p, rr);
      ctx.drawImage(spb.ring, sx2 - spb.half, sy2 - spb.half, spb.half * 2, spb.half * 2);
      drawBallAvatar(p, sx2, sy2, rr, b.angle);   // 头像跟着滚动转，色环/role 描边不转
      ctx.restore();
      // 领先者标记
      if (state.frameRank.length ? state.frameRank[0] === b : race.rankAlive()[0] === b) {
        ctx.fillStyle = 'rgba(250,204,21,0.95)';
        ctx.beginPath();
        ctx.moveTo(sx2, sy2 - rr - 16);
        ctx.lineTo(sx2 - 7, sy2 - rr - 28);
        ctx.lineTo(sx2 + 7, sy2 - rr - 28);
        ctx.closePath(); ctx.fill();
      }
    }
  }

  function drawNameTags(race) {
    if (view.scale < 0.36) return;
    ctx.textBaseline = 'middle';
    ctx.font = '600 11px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
    var shown = [];
    var list = race.balls.filter(function (b) { return b.alive; }).sort(function (a, b) { return b.best - a.best; });
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      var pos = ballScreen(b);
      var sx = toScreenX(pos.x), sy = toScreenY(pos.y) + BALL_R * view.scale + 14;
      if (sy < 12 || sy > view.h - 8) continue;
      var p = race.players[b.idx] || b;
      var text = fitText(ctx, p.name, 118);
      var w = ctx.measureText(text).width + 12;
      var rect = { x: sx - w / 2, y: sy - 8, w: w, h: 16 };
      var hit = false;
      for (var j = 0; j < shown.length; j++) {
        var s = shown[j];
        if (Math.abs(s.x - rect.x - s.w / 2) < (s.w + rect.w) / 2 && Math.abs(s.y - rect.y) < 20) { hit = true; break; }
      }
      if (hit) continue;
      shown.push(rect);
      var pal = palette(p.qq, p.role);
      ctx.fillStyle = 'rgba(4,8,18,0.72)';
      roundRect(rect.x, rect.y, rect.w, rect.h, 8); ctx.fill();
      ctx.strokeStyle = pal.glow + '0.75)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = 'rgba(233,243,255,0.95)';
      ctx.textAlign = 'center';
      ctx.fillText(text, sx, sy + 1);
    }
  }

  var PART_BUCKETS = [];      // 复用的分桶容器（避免每帧分配）
  function drawParticles() {
    var ps = state.particles;
    if (!ps.length) return;
    // 按「颜色 + 透明度档」分桶，每桶一条路径一次 fill。
    // 旧实现是每个粒子一次 beginPath + fill，260 个粒子就是 260 次 fill。
    var n = 0, i, j;
    for (i = 0; i < ps.length; i++) {
      var p = ps[i];
      var a = clamp(p.life / p.maxLife, 0, 1);
      var band = a > 0.75 ? 3 : (a > 0.5 ? 2 : (a > 0.25 ? 1 : 0));
      var key = p.color + '#' + band;
      var b = null;
      for (j = 0; j < n; j++) if (PART_BUCKETS[j].key === key) { b = PART_BUCKETS[j]; break; }
      if (!b) {
        b = PART_BUCKETS[n];
        if (!b) { b = PART_BUCKETS[n] = { key: '', color: '', alpha: 0, pts: [] }; }
        b.key = key; b.color = p.color; b.alpha = 0.25 + band * 0.25; b.pts.length = 0;
        n++;
      }
      b.pts.push(toScreenX(p.x), toScreenY(p.y), p.size * view.scale * (0.4 + a));
    }
    for (j = 0; j < n; j++) {
      var bb = PART_BUCKETS[j];
      if (!bb.pts.length) continue;
      ctx.globalAlpha = bb.alpha;
      ctx.fillStyle = bb.color;
      ctx.beginPath();
      for (i = 0; i < bb.pts.length; i += 3) {
        var r = bb.pts[i + 2];
        ctx.moveTo(bb.pts[i] + r, bb.pts[i + 1]);
        ctx.arc(bb.pts[i], bb.pts[i + 1], r, 0, Math.PI * 2);
      }
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  function spawnBurst(x, y, n, color, power) {
    var rnd = state.vfxRnd;
    for (var i = 0; i < n; i++) {
      var a = rnd() * Math.PI * 2, sp = (80 + rnd() * 420) * (power || 1);
      state.particles.push({
        x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60,
        life: 0.4 + rnd() * 0.7, maxLife: 1.1, size: 2 + rnd() * 4, color: color,
      });
    }
    // 超过上限就丢掉最老的：copyWithin 原地前移，避免 splice 在数组头部搬移
    if (state.particles.length > PARTICLE_MAX) {
      state.particles.copyWithin(0, state.particles.length - PARTICLE_MAX);
      state.particles.length = PARTICLE_MAX;
    }
  }

  /** 屏幕震动：强度直接取 vfx 的真实法向冲量归一化值 power（幅度上限仍是 render 里的 4px） */
  function bumpShake(power) {
    if (!state.shakeOn) return;
    var p = clamp(power || 0, 0, 1);
    if (p <= 0.25) return;
    if (!state.shake || p > state.shake.power || state.shake.t <= 0) state.shake = { t: 0.15, power: p };
  }

  function consumeVfx(race) {
    var v = race.vfx;
    for (var i = 0; i < v.length; i++) {
      var e = v[i];
      if (e.type === 'hit') {
        spawnBurst(e.x, e.y, 3 + Math.round(e.power * 5), 'rgba(186,230,253,0.9)', e.power);
        Sound.hit(e.power);
        bumpShake(e.power);
        markDeform(race, e, e.power);          // power > 0.45（|vn| > 400）才形变
      } else if (e.type === 'elim') {
        var b = race.balls[e.idx];
        spawnBurst(e.x, e.y, 26, 'rgba(248,113,113,0.95)', 1.5);
        Sound.elim();
        bumpShake(1);
      } else if (e.type === 'boost') {
        spawnBurst(e.x, e.y, 10, 'rgba(52,211,153,0.95)', 1.1);
        Sound.boost();
        var g = race.course.objects.boosts[e.idx];
        if (g) g.flashT = 0.2;
      } else if (e.type === 'peg') {
        var pg = race.course.objects.pegs[e.idx];
        if (pg) pg.ripple = 0.45;
        spawnBurst(e.x, e.y, 4, 'rgba(251,191,36,0.85)', 0.7);
        Sound.hit(e.power * 0.6);
        bumpShake(e.power);
        markDeform(race, e, e.power);
      } else if (e.type === 'bumper') {
        var bp = race.course.objects.bumpers[e.idx];
        if (bp) bp.hitT = 0.35;
        spawnBurst(e.x, e.y, 12, 'rgba(52,211,153,0.95)', 1.2);
        Sound.hit(0.8);
        bumpShake(e.power);
        markDeform(race, e, e.power);
      } else if (e.type === 'rescue') {
        spawnBurst(e.x, e.y, 12, 'rgba(250,204,21,0.95)', 1.2);
      } else if (e.type === 'finish') {
        spawnBurst(e.x, e.y, 40, 'rgba(250,204,21,0.95)', 1.8);
      }
    }
    v.length = 0;
  }

  function stepParticles(dt) {
    var ps = state.particles;
    for (var i = ps.length - 1; i >= 0; i--) {
      var p = ps[i];
      p.vy += 900 * dt;
      p.vx *= 0.99; p.vy *= 0.99;
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.life -= dt;
      if (p.life <= 0) {                  // 交换删除：把末尾元素换过来再 pop，O(1)
        var last = ps.pop();
        if (i < ps.length) ps[i] = last;
      }
    }
  }

  /** 屏幕外的球用小箭头提示 */
  function drawEdgeMarkers(race) {
    var alive = state.frameRank.length ? state.frameRank : race.rankAlive();
    ctx.save();
    for (var i = 0; i < alive.length; i++) {
      var b = alive[i];
      var pos = ballScreen(b);
      var sy = toScreenY(pos.y);
      if (sy > -20 && sy < view.h + 20) continue;
      var sx = clamp(toScreenX(pos.x), 16, view.availW - 16);
      var p = race.players[b.idx] || b;
      var pal = palette(p.qq, p.role);
      var up = sy < 0;
      var yy = up ? 20 : view.h - 20;
      ctx.fillStyle = pal.ring;
      ctx.beginPath();
      if (up) { ctx.moveTo(sx, yy - 8); ctx.lineTo(sx - 7, yy + 5); ctx.lineTo(sx + 7, yy + 5); }
      else { ctx.moveTo(sx, yy + 8); ctx.lineTo(sx - 7, yy - 5); ctx.lineTo(sx + 7, yy - 5); }
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  function drawStageBanner() {
    if (!state.stageBanner || state.stageBannerT <= 0) return;
    var a = clamp(state.stageBannerT, 0, 1);
    ctx.save();
    ctx.globalAlpha = a;
    ctx.textAlign = 'center';
    ctx.font = '800 30px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
    var w = ctx.measureText(state.stageBanner).width + 64;
    var x = view.availW / 2 - w / 2, y = view.h * 0.18;
    ctx.fillStyle = 'rgba(6,10,22,0.85)';
    roundRect(x, y, w, 60, 14); ctx.fill();
    ctx.strokeStyle = 'rgba(250,204,21,0.9)'; ctx.lineWidth = 2;
    roundRect(x, y, w, 60, 14); ctx.stroke();
    ctx.fillStyle = 'rgba(250,204,21,0.98)';
    ctx.fillText(state.stageBanner, view.availW / 2, y + 40);
    ctx.restore();
  }

  function drawCountdown(race) {
    if (race.phase !== 'countdown') return;
    var n = Math.ceil(race.countdown);
    var frac = race.countdown - Math.floor(race.countdown);
    ctx.save();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.globalAlpha = clamp(0.35 + frac * 0.65, 0, 1);
    ctx.font = '900 ' + Math.round(Math.min(view.availW, view.h) * 0.24) + 'px system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif';
    ctx.fillStyle = 'rgba(250,204,21,0.95)';
    ctx.shadowColor = 'rgba(250,204,21,0.6)'; ctx.shadowBlur = 40;
    ctx.fillText(n > 0 ? String(n) : 'GO', view.availW / 2, view.h * 0.42);
    ctx.restore();
  }

  /* ============================ 粒子/事件钩子 ============================ */

  function render(dt) {
    if (state.menuOpen || state.skipRender) return;
    var t0 = performance.now();
    var race = state.race;
    // resize、调试定位、回主页等入口也都使用当前比赛的排名和插值坐标。
    if (race) updateCamera(0);
    var dpr = state.dpr;
    // 碰撞屏幕震动：只作用于渲染偏移，不影响相机与物理
    var sh = state.shake || { t: 0, power: 0 };
    var shx = 0, shy = 0;
    if (sh.t > 0) {
      sh.t -= dt;
      var amp = 4 * sh.power * Math.max(0, sh.t) / 0.15;
      var ph = performance.now() / 22;
      shx = Math.sin(ph) * amp;
      shy = Math.cos(ph * 1.7) * amp;
      if (sh.t <= 0) { sh.power = 0; }
    }
    ctx.setTransform(dpr, 0, 0, dpr, shx * dpr, shy * dpr);
    if (!race) { drawBackdrop(); state.frameMs = state.frameMs * 0.9 + (performance.now() - t0) * 0.1; return; }
    // 静态层（管道 / 门框 / 终点棋盘格 / 关卡色带 / 背景网格）全部走离屏瓦片，每帧只贴 2~3 张图
    drawTiles(race);
    // 动态层
    drawChannel(race, 'dynamic');
    drawMarkers(race, 'dynamic');
    drawObjects(race, race.t);
    drawEdgeMarkers(race);
    drawBalls(race);
    drawNameTags(race);
    drawParticles();
    drawStageBanner();
    drawCountdown(race);
    state.frameMs = state.frameMs * 0.9 + (performance.now() - t0) * 0.1;
  }

  /* ============================ HUD ============================ */

  var hud = {
    round: $('hud-round'), timer: $('hud-timer'), stage: $('hud-stage'),
    aliveN: $('hud-alive-n'), seed: $('hud-seed'), boardList: $('board-list'),
    boardOut: $('board-out'), boardOutN: $('board-out-n'), ticker: $('ticker'),
    inter: $('intermission'),
  };

  function updateHud(force) {
    var match = state.match, race = state.race;
    if (!match || !race) return;
    var isFinal = match.stage === 'final' || match.stage === 'done';
    hud.round.textContent = isFinal ? '决赛 · 3 人争冠' : '预赛 · 18 进 3';
    hud.timer.textContent = fmtTime(race.raceTime);
    var cutDone = race.cuts.length;
    hud.stage.textContent = isFinal
      ? '先到终点者夺冠'
      : '淘汰 ' + cutDone + ' / ' + race.course.elims.length + ' 轮 · 每轮末位 3 人出局';
    hud.aliveN.textContent = String(race.aliveCount());
    hud.seed.textContent = String(state.seed);
    var followed = race.balls.find(function (b) { return b.qq === state.cameraTarget; });
    $('hud-camera').textContent = '镜头锁定 · ' + (followed ? followed.name : '领跑小球');

    // 排行榜
    var rank = race.rankAlive();
    var html = '';
    for (var i = 0; i < rank.length; i++) {
      var b = rank[i], p = race.players[b.idx] || b;
      var pal = palette(p.qq, p.role);
      var pct = Math.round(race.progressPct(b) * 100);
      html += '<li class="row' + (i === 0 ? ' lead' : '') + '">'
        + '<span class="rk" style="--c:' + pal.ring + '">' + (i + 1) + '</span>'
        + thumbHtml(p)
        + '<span class="nm" title="' + escapeHtml(p.name) + '">' + escapeHtml(p.name) + '</span>'
        + (pal.badge ? '<span class="bdg">' + pal.badge + '</span>' : '')
        + '<span class="bar"><i style="width:' + pct + '%;background:' + pal.ring + '"></i></span>'
        + '<span class="pc">' + pct + '%</span></li>';
    }
    hud.boardList.innerHTML = html;

    var outs = race.eliminations;
    hud.boardOutN.textContent = outs.length ? '（' + outs.length + '）' : '';
    var oh = '';
    for (var k = outs.length - 1; k >= 0; k--) {
      var o = outs[k], op = { qq: o.qq, name: o.name, role: o.role };
      var pal2 = palette(o.qq, o.role);
      oh += '<li class="row out">'
        + '<span class="rk" style="--c:' + pal2.ring + '">' + (19 - o.order) + '</span>'
        + thumbHtml(op)
        + '<span class="nm" title="' + escapeHtml(o.name) + '">' + escapeHtml(o.name) + '</span>'
        + '<span class="pc">第' + o.round + '轮</span></li>';
    }
    hud.boardOut.innerHTML = oh;

    // 事件滚动条
    var ev = race.events.slice(-5);
    var th = '';
    for (var e = 0; e < ev.length; e++) {
      var it = ev[e];
      var cls = it.type === 'elim' ? 'ev elim' : (it.type === 'cut' ? 'ev cut' : (it.type === 'level' ? 'ev lv' : 'ev'));
      th += '<span class="' + cls + '">' + escapeHtml(it.text) + '</span>';
    }
    hud.ticker.innerHTML = th;
  }

  function thumbHtml(p) {
    if (p.avatar) {
      return '<img class="th" src="' + p.avatar + '" alt="" loading="lazy" '
        + 'onerror="this.replaceWith(Object.assign(document.createElement(\'span\'),{className:\'th ph\',textContent:this.dataset.c}))" '
        + 'data-c="' + escapeHtml(firstGrapheme(p.name)) + '">';
    }
    return '<span class="th ph">' + escapeHtml(firstGrapheme(p.name)) + '</span>';
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ============================ 今日记录（localStorage） ============================ */

  /**
   * 记录模块：键名固定 'peppa-race:records:v1'，值是 JSON 数组。
   * 所有 localStorage 访问都包在 try/catch 里 —— 隐私模式 / 配额满 / 被禁用时
   * 游戏照常运行、记录页显示提示，绝不抛错白屏。读到的数据逐条校验，坏记录直接丢弃。
   * ⚠️ Date.now() 只在本文件（game.js）里使用，绝不进 sim.js，否则会破坏确定性。
   */
  var Records = (function () {
    var KEY = 'peppa-race:records:v1';
    var MAX_AGE = 30 * 24 * 3600 * 1000;   // 只保留最近 30 天
    var MAX_ITEMS = 300;                   // 最多 300 条
    var available = true;

    function pad2(n) { return (n < 10 ? '0' : '') + n; }
    function dayOf(ts) {
      var d = new Date(ts === undefined ? Date.now() : ts);
      return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    }
    /** 逐条校验：字段缺失或类型不对的坏记录直接丢弃，不影响其它记录 */
    function valid(r) {
      if (!r || typeof r !== 'object') return false;
      if (typeof r.id !== 'string' || !r.id) return false;
      if (!Number.isFinite(r.seed)) return false;
      if (typeof r.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(r.date)) return false;
      if (!Array.isArray(r.standings) || !r.standings.length) return false;
      if (!r.champion || typeof r.champion.name !== 'string') return false;
      return true;
    }
    function normalize(r) {
      return {
        id: r.id, seed: r.seed >>> 0, mode: r.mode === 'replay' ? 'replay' : 'new',
        date: r.date,
        startedAt: Number.isFinite(r.startedAt) ? r.startedAt : 0,
        endedAt: Number.isFinite(r.endedAt) ? r.endedAt : 0,
        qualifierTime: Number.isFinite(r.qualifierTime) ? r.qualifierTime : 0,
        finalTime: Number.isFinite(r.finalTime) ? r.finalTime : 0,
        champion: { qq: String(r.champion.qq || ''), name: String(r.champion.name) },
        podium: Array.isArray(r.podium) ? r.podium.map(function (p) {
          return { qq: String(p.qq || ''), name: String(p.name || ''), time: Number.isFinite(p.time) ? p.time : null };
        }) : [],
        standings: r.standings.map(function (s, i) {
          return {
            rank: Number.isFinite(s.rank) ? s.rank : i + 1,
            qq: String(s.qq || ''), name: String(s.name || ''),
            how: typeof s.how === 'string' ? s.how : '—',
          };
        }),
        cuts: Array.isArray(r.cuts) ? r.cuts.map(function (c) {
          return {
            round: Number.isFinite(c.round) ? c.round : 0,
            afterLevel: Number.isFinite(c.afterLevel) ? c.afterLevel : 0,
            out: Array.isArray(c.out) ? c.out.map(String) : [],
          };
        }) : [],
        skipped: !!r.skipped,
      };
    }
    function read() {
      var arr;
      try {
        var raw = window.localStorage.getItem(KEY);
        available = true;
        if (!raw) return [];
        arr = JSON.parse(raw);
      } catch (e) { available = false; return []; }
      if (!Array.isArray(arr)) return [];
      var now = Date.now(), out = [];
      for (var i = 0; i < arr.length; i++) {
        if (!valid(arr[i])) continue;
        var r = arr[i];
        if (r.endedAt && now - r.endedAt > MAX_AGE) continue;
        out.push(normalize(r));
      }
      return out;
    }
    function write(list) {
      try { window.localStorage.setItem(KEY, JSON.stringify(list)); available = true; }
      catch (e) { available = false; }
    }
    function sorted(list) {
      return list.slice().sort(function (a, b) { return (b.endedAt || 0) - (a.endedAt || 0); });
    }
    function probe() {
      try {
        window.localStorage.setItem(KEY + ':probe', '1');
        window.localStorage.removeItem(KEY + ':probe');
        available = true;
      } catch (e) { available = false; }
      return available;
    }
    return {
      KEY: KEY,
      probe: probe,
      isAvailable: function () { return available; },
      dayOf: dayOf,
      list: function () { return sorted(read()); },
      today: function () {
        var d = dayOf();
        return sorted(read().filter(function (r) { return r.date === d; }));
      },
      add: function (rec) {
        var list = read();
        list = list.filter(function (r) { return r.id !== rec.id; });   // 同一场只留一条
        list.push(normalize(rec));
        var now = Date.now();
        list = list.filter(function (r) { return !r.endedAt || now - r.endedAt <= MAX_AGE; });
        list = sorted(list).slice(0, MAX_ITEMS);
        write(list);
        return list.length;
      },
      clearToday: function () {
        var d = dayOf();
        var list = read().filter(function (r) { return r.date !== d; });
        write(list);
        return list.length;
      },
      days: function (n) {
        var out = [], base = Date.now();
        for (var i = 0; i < (n || 7); i++) out.push(dayOf(base - i * 86400000));
        return out;
      },
    };
  }());

  /* ============================ 主菜单 ============================ */


  var cfCb = null;
  function confirmBox(text, onOk) {
    var el = $('confirm');
    if (!el) { if (onOk) onOk(); return; }
    $('cf-text').textContent = text;
    cfCb = onOk;
    el.hidden = false;
    try { $('cf-ok').focus(); } catch (e) { }
  }
  function cfResolve(ok) {
    var cb = cfCb; cfCb = null;
    var el = $('confirm');
    if (el) el.hidden = true;
    if (ok && cb) cb();
  }

  /* ---------- 菜单显隐与二级页面 ---------- */

  function menuShow(page) {
    var el = $('menu');
    if (!el) return;
    if (!state.menuOpen) {
      state.menuFocus = document.activeElement;
    }
    state.menuOpen = true;
    stopGameLoop();
    $('game-screen').hidden = true;
    document.body.dataset.screen = 'menu';
    if (SPECTATOR) document.documentElement.dataset.spectatorScreen = 'menu';
    el.hidden = false;
    setMenuPage(page || 'main');
  }
  function menuHide() {
    if (!state.race) return;
    var el = $('menu');
    if (el) el.hidden = true;
    if (state.menuOpen && state.menuFocus && state.menuFocus.focus) {
      try { state.menuFocus.focus({ preventScroll: true }); } catch (e) { }
    }
    state.menuOpen = false;
    state.menuFocus = null;
    $('game-screen').hidden = false;
    document.body.dataset.screen = 'game';
    if (SPECTATOR) document.documentElement.dataset.spectatorScreen = 'game';
    resize();
    resumeGameLoop();
  }
  function setMenuPage(p) {
    state.menuPage = p;
    Array.prototype.forEach.call(document.querySelectorAll('.menu-page'), function (s) {
      s.classList.toggle('on', s.dataset.page === p);
    });
    if (p === 'main') renderMenuMain();
    else if (p === 'records') renderMenuRecords(state.recDay);
    else if (p === 'detail') renderMenuDetail(state.menuDetail);
    else if (p === 'rules') renderMenuRules();
    var btn = document.querySelector('.menu-page.on .m-btn');
    if (btn) { try { btn.focus({ preventScroll: true }); } catch (e) { } }
  }
  /** 菜单态的 Enter / Esc */
  function menuPrimary() {
    if (state.menuPage === 'main') menuStartGame('new');
    else if (state.menuPage === 'records') menuBack();
    else if (state.menuPage === 'detail') $('m-det-replay').click();
    else if (state.menuPage === 'rules') menuBack();
  }
  /** 菜单态返回上一级 */
  function menuBack() {
    if (state.confirmOpen) return;
    if (state.menuPage === 'main') return;
    if (state.menuPage === 'detail') { setMenuPage('records'); return; }
    setMenuPage('main');
  }

  /* ---------- 种子输入 ---------- */

  function seedFromInput() {
    var inp = $('m-seed-input');
    if (!inp) return null;
    var v = inp.value.trim();
    if (v === '') return null;                 // 留空 = 随机
    if (!/^\d+$/.test(v)) return NaN;          // 非法
    var n = Number(v);
    if (!Number.isFinite(n) || n < 0 || n > 4294967295) return NaN;
    return n >>> 0;
  }
  function syncSeedInput() {
    var inp = $('m-seed-input'), warn = $('m-seed-warn');
    if (!inp) return;
    inp.value = (state.seedHint === null || state.seedHint === undefined) ? '' : String(state.seedHint);
    inp.classList.remove('bad');
    if (warn) warn.hidden = true;
  }
  function validateSeedInput() {
    var v = seedFromInput(), inp = $('m-seed-input'), warn = $('m-seed-warn');
    if (v === null) { if (inp) inp.classList.remove('bad'); if (warn) warn.hidden = true; return null; }
    if (Number.isNaN(v)) {
      if (inp) inp.classList.add('bad');
      if (warn) { warn.hidden = false; warn.textContent = '请输入 0 ~ 4294967295 的整数'; }
      return NaN;
    }
    if (inp) inp.classList.remove('bad');
    if (warn) warn.hidden = true;
    return v;
  }
  function menuStartGame(mode) {
    var v = validateSeedInput();
    if (Number.isNaN(v)) return;
    var seed = (v === null) ? ((Math.random() * 0xFFFFFFFF) >>> 0) : v;
    startMatch(seed, true, mode || 'new');
  }

  /* ---------- 主页 ---------- */

  function updateRecordBadge() {
    var b = $('m-rec-badge');
    if (!b) return;
    var n = Records.today().length;
    b.hidden = n === 0;
    b.textContent = n + ' 场';
  }

  function renderMenuMain() {
    if (SPECTATOR) { window.PeppaDaily.renderHome(); return; }
    var box = $('m-roster');
    if (box) {
      var html = '';
      state.players.forEach(function (p) {
        var cls = 'm-play' + (p.role === 'owner' ? ' owner' : (p.role === 'admin' ? ' admin' : ''));
        html += '<div class="' + cls + '" title="' + escapeHtml(p.name) + '">'
          + thumbHtml(p) + '<span class="mn">' + escapeHtml(p.name) + '</span></div>';
      });
      box.innerHTML = html;
    }
    syncSeedInput();
    updateRecordBadge();
    var btn = $('m-start');
    if (btn) btn.focus({ preventScroll: true });
  }

  /* ---------- 名次表 / 淘汰记录（结算页与记录详情共用同一套 DOM 与 CSS） ---------- */

  function howText(r) {
    if (r.rank === 1) return '🏆 冠军';
    if (r.stage === 'final') return '决赛第 ' + r.rank + ' 名';
    if (r.cutRound) return '预赛第 ' + r.cutRound + ' 轮淘汰（第 ' + r.afterLevel + ' 关末）';
    return '—';
  }
  /** 18 人名次表：standings 每项 { rank, qq, name, how? }；players 用于取头像 */
  function standingsTableHtml(standings, players) {
    var html = '<div class="res-table"><table><thead><tr><th>名次</th><th>选手</th><th>结局</th></tr></thead><tbody>';
    standings.forEach(function (r) {
      var p = (players || []).filter(function (x) { return x.qq === r.qq; })[0] || r;
      var pal = palette(r.qq, r.role);
      var how = r.how || howText(r);
      html += '<tr class="' + (r.rank === 1 ? 'r1' : (r.rank <= 3 ? 'r3' : '')) + '">'
        + '<td class="rk2" style="color:' + pal.ring + '">' + r.rank + '</td>'
        + '<td class="who">' + thumbHtml(p) + '<span>' + escapeHtml(r.name) + '</span>'
        + (pal.badge ? '<i class="bdg">' + pal.badge + '</i>' : '') + '</td>'
        + '<td class="how">' + escapeHtml(how) + '</td></tr>';
    });
    return html + '</tbody></table></div>';
  }
  /** 5 轮淘汰记录 */
  function cutsLogHtml(cuts) {
    if (!cuts || !cuts.length) return '';
    var html = '<div class="res-log"><h3>淘汰记录</h3><ol>';
    cuts.forEach(function (c) {
      html += '<li><b>第 ' + c.round + ' 轮</b>（第 ' + c.afterLevel + ' 关末）<br>'
        + c.out.map(escapeHtml).join(' · ') + '</li>';
    });
    return html + '</ol></div>';
  }

  /* ---------- 记录页 ---------- */

  function fmtClock(ts) {
    var d = new Date(ts || 0);
    return (d.getHours() < 10 ? '0' : '') + d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
  }
  function playerOf(qq) {
    return state.players.filter(function (p) { return p.qq === qq; })[0] || { qq: qq, name: '—' };
  }

  function renderMenuRecords(dayKey) {
    var body = $('m-rec-body');
    if (!body) return;
    if (!Records.isAvailable()) {
      body.innerHTML = '<div class="m-empty">当前浏览器不允许本地存储，记录不会保存</div>';
      return;
    }
    var days = Records.days(7);
    var cur = dayKey && days.indexOf(dayKey) >= 0 ? dayKey : days[0];
    state.recDay = cur;
    var all = Records.list();
    var list = all.filter(function (r) { return r.date === cur; });
    var html = '';

    // 日期切换（最近 7 天）
    html += '<div class="m-days">';
    days.forEach(function (d, i) {
      var n = all.filter(function (r) { return r.date === d; }).length;
      var label = i === 0 ? '今天' : (i === 1 ? '昨天' : d.slice(5));
      html += '<button class="m-btn sm' + (d === cur ? ' primary' : '') + '" data-day="' + d + '">'
        + label + '（' + n + '）</button>';
    });
    html += '</div>';

    // 今日概览
    var champCount = {};
    list.forEach(function (r) {
      var k = r.champion.name;
      champCount[k] = (champCount[k] || 0) + 1;
    });
    var champs = Object.keys(champCount).sort(function (a, b) {
      return champCount[b] - champCount[a] || a.localeCompare(b);
    }).slice(0, 5);
    var qs = list.map(function (r) { return r.qualifierTime; }).filter(function (v) { return v > 0; });
    var fs = list.map(function (r) { return r.finalTime; }).filter(function (v) { return v > 0; });
    var bestOf = {};
    list.forEach(function (r) {
      r.standings.forEach(function (s) {
        if (!bestOf[s.name] || s.rank < bestOf[s.name]) bestOf[s.name] = s.rank;
      });
    });
    var names = Object.keys(bestOf).sort(function (a, b) { return bestOf[a] - bestOf[b]; });

    html += '<div class="m-card"><h3>今日概览</h3><div class="m-kpis">'
      + '<div class="m-kpi"><b>' + list.length + '</b><span>今日场次</span></div>'
      + '<div class="m-kpi"><b>' + (qs.length ? Math.min.apply(null, qs).toFixed(1) + 's' : '—') + '</b><span>今日最快预赛</span></div>'
      + '<div class="m-kpi"><b>' + (fs.length ? Math.min.apply(null, fs).toFixed(1) + 's' : '—') + '</b><span>今日最快决赛</span></div>'
      + '<div class="m-kpi"><b>' + champs.length + '</b><span>今日冠军人数</span></div>'
      + '</div>';
    if (champs.length) {
      html += '<div style="margin-top:10px"><div class="m-champs">';
      champs.forEach(function (nm) {
        var qq = '';
        for (var i = 0; i < list.length; i++) if (list[i].champion.name === nm) { qq = list[i].champion.qq; break; }
        html += '<span class="m-champ">' + thumbHtml(playerOf(qq)) + escapeHtml(nm)
          + ' <b style="color:#fde68a">×' + champCount[nm] + '</b></span>';
      });
      html += '</div></div>';
    }
    if (names.length) {
      html += '<details style="margin-top:10px"><summary style="cursor:pointer;font-size:12.5px;color:#7dd3fc">'
        + '每位群友今日最好名次（' + names.length + ' 人，点开）</summary><div class="m-champs" style="margin-top:8px">';
      names.forEach(function (nm) {
        var qq = '';
        for (var i = 0; i < list.length; i++) {
          var hit = list[i].standings.filter(function (s) { return s.name === nm; })[0];
          if (hit) { qq = hit.qq; break; }
        }
        html += '<span class="m-champ" style="border-color:rgba(125,211,252,.3);background:rgba(125,211,252,.08)">'
          + thumbHtml(playerOf(qq)) + escapeHtml(nm) + ' <b style="color:#bae6fd">第 ' + bestOf[nm] + '</b></span>';
      });
      html += '</div></details>';
    }
    html += '</div>';

    // 场次列表
    if (!list.length) {
      html += '<div class="m-empty">今天还没有比赛，去开一局吧'
        + '<button class="m-btn primary" id="m-empty-start">▶ 开始游戏</button></div>';
    } else {
      html += '<div class="m-card"><h3>场次（时间倒序）</h3>';
      list.forEach(function (r) {
        var top3 = r.standings.slice(0, 3);
        html += '<button class="m-row" data-rec="' + escapeHtml(r.id) + '">'
          + '<span class="tm">' + fmtClock(r.startedAt) + '</span>'
          + '<span class="sd">种子 ' + r.seed + '</span>'
          + '<span class="wch">' + thumbHtml(playerOf(r.champion.qq))
          + '<span class="nm">' + escapeHtml(r.champion.name) + '</span></span>'
          + '<span class="wch" style="flex:0 0 auto;gap:3px">'
          + top3.map(function (s) { return thumbHtml(playerOf(s.qq)); }).join('')
          + '</span>'
          + (r.mode === 'replay' ? '<span class="m-tag">重放</span>' : '')
          + (r.skipped ? '<span class="m-tag sk">快进</span>' : '')
          + '<span class="ts">预 ' + r.qualifierTime.toFixed(1) + 's · 决 ' + r.finalTime.toFixed(1) + 's</span>'
          + '</button>';
      });
      html += '</div>';
      html += '<div style="text-align:center;margin:4px 0 10px">'
        + '<button class="m-btn sm" id="m-clear-day">🗑 清空今日记录</button></div>';
    }
    body.innerHTML = html;

    Array.prototype.forEach.call(body.querySelectorAll('[data-day]'), function (b) {
      b.onclick = function () { renderMenuRecords(b.dataset.day); };
    });
    Array.prototype.forEach.call(body.querySelectorAll('[data-rec]'), function (b) {
      b.onclick = function () {
        var rec = all.filter(function (x) { return x.id === b.dataset.rec; })[0];
        if (rec) { state.menuDetail = rec; setMenuPage('detail'); }
      };
    });
    var es = $('m-empty-start');
    if (es) es.onclick = function () { menuStartGame('new'); };
    var cd = $('m-clear-day');
    if (cd) cd.onclick = function () {
      confirmBox('确定清空【' + cur + '】的全部记录吗？此操作不可撤销。', function () {
        Records.clearToday();
        updateRecordBadge();
        renderMenuRecords(cur);
      });
    };
  }

  /* ---------- 记录详情 ---------- */

  function renderMenuDetail(rec) {
    var body = $('m-det-body');
    if (!body) return;
    if (!rec) { body.innerHTML = '<div class="m-empty">没有选中任何记录</div>'; return; }
    var top3 = rec.standings.slice(0, 3);
    var html = '<div class="m-card">'
      + '<h3>第 ' + escapeHtml(rec.date) + ' ' + fmtClock(rec.startedAt) + ' · 种子 ' + rec.seed
      + (rec.mode === 'replay' ? ' · <span class="m-tag">重放</span>' : '')
      + (rec.skipped ? ' · <span class="m-tag sk">快进</span>' : '')
      + '</h3>'
      + '<div class="m-kpis">'
      + '<div class="m-kpi"><b>' + (rec.qualifierTime || 0).toFixed(1) + 's</b><span>预赛用时</span></div>'
      + '<div class="m-kpi"><b>' + (rec.finalTime || 0).toFixed(1) + 's</b><span>决赛用时</span></div>'
      + '<div class="m-kpi"><b>' + escapeHtml(rec.champion.name) + '</b><span>冠军</span></div>'
      + '</div>'
      + '<div class="m-champs" style="margin-top:10px">'
      + top3.map(function (s, i) {
        return '<span class="m-champ">' + thumbHtml(playerOf(s.qq))
          + (i + 1) + '. ' + escapeHtml(s.name) + '</span>';
      }).join('')
      + '</div></div>';
    html += '<div class="m-card">' + standingsTableHtml(rec.standings, state.players) + '</div>';
    html += cutsLogHtml(rec.cuts);
    body.innerHTML = html;
    $('m-det-replay').onclick = function () { startMatch(rec.seed, true, 'replay'); };
  }

  /* ---------- 规则页（数字与关卡名全部来自运行时数据） ---------- */

  var LEGEND = [
    { k: 'bar', n: '旋转挡板', d: '胶囊绕圆心旋转，按 ω 结算接触点速度，把球扫向一侧' },
    { k: 'mill', n: '风车', d: '同圆心多片叶轮，相位差 2π/n，几乎没有空档期' },
    { k: 'pendulum', n: '摆锤', d: '枢轴固定，锤头按 θ=A·sin(ωt+φ) 摆动，周期性封住通道' },
    { k: 'plat', n: '移动平台 / 闸门 / 推杆', d: '升降台与闸门沿法线往复，推杆沿切线横扫' },
    { k: 'boost', n: '弹簧跳板', d: '限定横向带内沿切线加速' },
    { k: 'peg', n: '圆钉', d: '圆-圆碰撞，钉阵逼球折线穿行' },
    { k: 'bumper', n: '弹射蘑菇', d: '高恢复系数 + 固定冲量踢开，撞上就被弹飞' },
    { k: 'pit', n: '断层凹坑', d: '地板下沉成坑，低速会掉进去再爬出来' },
    { k: 'mud', n: '泥沼', d: '只抬高接触时的滚动阻力，空中经过不减速' },
    { k: 'throat', n: '收窄喉口', d: '管道收窄到最窄处，大部队在这里被挤成纵队' },
  ];

  /** 图例用小 canvas：临时把全局 ctx 指到小画布，复用比赛里的绘制函数 */
  function paintLegend(canvas, kind) {
    var saved = ctx;
    ctx = canvas.getContext('2d');
    try {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      if (kind === 'bar') {
        ctx.rotate(0.6);
        drawCapsule(-26, 0, 26, 0, 7, '#a31368', '#ff9edb', 'rgba(244,114,182,0.25)', 'bar');
      } else if (kind === 'mill') {
        var arms = 5;
        for (var i = 0; i < arms; i++) {
          var a = i * 2 * Math.PI / arms;
          drawCapsule(0, 0, Math.cos(a) * 26, Math.sin(a) * 26, 6, '#a6530c', '#ffe37b', 'rgba(245,158,11,0.22)', 'mill');
        }
      } else if (kind === 'pendulum') {
        drawCapsule(0, -26, 0, 8, 6, '#891f2a', '#fb7185', null, 'pendulum');
        ctx.fillStyle = '#fb7185';
        ctx.beginPath(); ctx.arc(0, 14, 9, 0, Math.PI * 2); ctx.fill();
      } else if (kind === 'plat') {
        drawCapsule(-26, 0, 26, 0, 7, '#075985', '#bae6fd', 'rgba(56,189,248,0.25)', 'platform');
      } else if (kind === 'boost') {
        ctx.fillStyle = 'rgba(16,185,129,0.28)';
        ctx.fillRect(-26, -16, 52, 32);
        ctx.strokeStyle = 'rgba(52,211,153,0.9)'; ctx.lineWidth = 2.5;
        ctx.strokeRect(-26, -16, 52, 32);
        ctx.strokeStyle = 'rgba(167,243,208,0.95)'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(-12, -7); ctx.lineTo(0, 0); ctx.lineTo(-12, 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(4, -7); ctx.lineTo(16, 0); ctx.lineTo(4, 7); ctx.stroke();
      } else if (kind === 'peg' || kind === 'bumper') {
        var rr = kind === 'peg' ? 11 : 17;
        var g = ctx.createRadialGradient(-rr * 0.4, -rr * 0.4, 0, 0, 0, rr);
        if (kind === 'peg') { g.addColorStop(0, '#e0f2fe'); g.addColorStop(0.6, '#829bad'); g.addColorStop(1, '#1e3a50'); }
        else { g.addColorStop(0, '#f0fdf4'); g.addColorStop(0.45, '#34d399'); g.addColorStop(1, '#065f46'); }
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(0, 0, rr, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 2; ctx.stroke();
        if (kind === 'peg') {
          ctx.strokeStyle = '#102335'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(-5, 0); ctx.lineTo(5, 0); ctx.moveTo(0, -5); ctx.lineTo(0, 5); ctx.stroke();
        } else {
          ctx.strokeStyle = '#bbf7d0'; ctx.beginPath(); ctx.arc(0, 0, rr * 0.7, 0, Math.PI * 2); ctx.stroke();
        }
      } else if (kind === 'pit') {
        ctx.strokeStyle = 'rgba(248,113,113,0.95)'; ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(-28, -10);
        ctx.quadraticCurveTo(0, 26, 28, -10);
        ctx.stroke();
        ctx.fillStyle = 'rgba(248,113,113,0.16)';
        ctx.beginPath(); ctx.moveTo(-28, -10); ctx.quadraticCurveTo(0, 26, 28, -10); ctx.closePath(); ctx.fill();
      } else if (kind === 'mud') {
        ctx.fillStyle = 'rgba(120,72,32,0.55)';
        ctx.fillRect(-28, -14, 56, 28);
        ctx.strokeStyle = 'rgba(180,120,60,0.9)'; ctx.lineWidth = 2;
        ctx.strokeRect(-28, -14, 56, 28);
        ctx.fillStyle = 'rgba(220,180,120,0.7)';
        for (var m = 0; m < 4; m++) { ctx.beginPath(); ctx.arc(-18 + m * 12, 4 - (m % 2) * 7, 2.6, 0, Math.PI * 2); ctx.fill(); }
      } else if (kind === 'throat') {
        ctx.strokeStyle = 'rgba(251,146,60,0.95)'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(-28, -22); ctx.lineTo(-6, -8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(-28, 22); ctx.lineTo(-6, 8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(28, -22); ctx.lineTo(6, -8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(28, 22); ctx.lineTo(6, 8); ctx.stroke();
      }
      ctx.restore();
    } catch (e) { state.errors.push('legend:' + kind + ':' + e.message); }
    ctx = saved;
  }

  function renderMenuRules() {
    var body = $('m-rule-body');
    if (!body) return;
    var seed = state.seedHint || 1;
    var q, f;
    try {
      q = SIM.buildCourse(seed, 'qualifier');
      f = SIM.buildCourse(seed, 'final');
    } catch (e) { q = SIM.buildCourse(1, 'qualifier'); f = SIM.buildCourse(1, 'final'); }
    var cutSet = {};
    q.elims.forEach(function (e) { cutSet[e.afterLevel] = 1; });

    var html = '';
    html += '<h3>① 比赛流程</h3><p>预赛 ' + state.players.length + ' 人同场出发，滑完 '
      + q.levels.length + ' 关；每条淘汰线触发时，<b>当前排名最后的 '
      + SIM.CUT_SIZE + ' 人出局</b>，共 ' + SIM.CUT_COUNT + ' 条淘汰线（合计 '
      + (SIM.CUT_SIZE * SIM.CUT_COUNT) + ' 人）。剩下 '
      + (state.players.length - SIM.CUT_SIZE * SIM.CUT_COUNT)
      + ' 人进入决赛道，<b>先到终点者夺冠</b>，最后给出 1~' + state.players.length + ' 名的完整名次。</p>';

    html += '<h3>② 预赛关卡（共 ' + q.levels.length + ' 关）</h3><p>'
      + q.levels.map(function (l) {
        return '<span class="m-lv' + (cutSet[l.no] ? ' cut' : '') + '">第 ' + l.no + ' 关 · '
          + escapeHtml(l.name) + (cutSet[l.no] ? ' 🔴 淘汰线' : '') + '</span>';
      }).join('') + '</p>';

    html += '<h3>③ 决赛关卡（共 ' + f.levels.length + ' 关）</h3><p>'
      + f.levels.map(function (l) {
        return '<span class="m-lv">第 ' + l.no + ' 关 · ' + escapeHtml(l.name) + '</span>';
      }).join('') + '</p>';

    html += '<h3>④ 障碍物图例</h3><div class="m-legend">';
    LEGEND.forEach(function (it, i) {
      html += '<div class="m-lg"><canvas width="92" height="92" data-legend="' + it.k + '" id="lg-' + i + '"></canvas>'
        + '<div><b>' + escapeHtml(it.n) + '</b><span>' + escapeHtml(it.d) + '</span></div></div>';
    });
    html += '</div>';

    html += '<h3>⑤ 公平性</h3><ul>'
      + '<li>所有球<b>半径与质量完全相同</b>，同一轮面对<b>完全相同的赛道与障碍</b>。</li>'
      + '<li>起跑顺序由种子抽签决定，没有任何人被固定在有利位置。</li>'
      + '<li>没有随机加速、随机传送、随机放水；唯一随机源是种子。</li>'
      + '<li>球停滞超过约 ' + (SIM.STUCK_TIME || 3) + ' 秒会自动弹射脱困。</li>'
      + '</ul>';

    html += '<h3>⑥ 种子</h3><p>同一颗种子的比赛过程与结果<b>完全一样</b>。'
      + '把种子发到群里，大家能复现同一场比赛；结算页可以直接「重放本局」，'
      + '记录页也能「用此种子重放」。</p>';

    html += '<h3>⑦ 操作</h3><p><kbd>空格</kbd> 暂停 · <kbd>R</kbd> 重开 · '
      + '<kbd>1</kbd><kbd>2</kbd><kbd>4</kbd> 倍速 · <kbd>S</kbd> 音效 · '
      + '<kbd>Esc</kbd> 回主页 · HUD 右上角的 📳 是碰撞震动开关。</p>';
    html += '<p>镜头始终锁定赛程排名第一的小球，放在比赛画面的中央；领先者改变时自动切换。'
      + '粉黑条纹是旋转挡板，金色是风车，红色是摆锤，蓝色是平台，紫色是推杆，'
      + '黄黑条纹是闸门，十字金属钉是钉阵，绿色闪电靶心是弹射蘑菇。</p>';

    body.innerHTML = html;
    Array.prototype.forEach.call(body.querySelectorAll('[data-legend]'), function (c) {
      paintLegend(c, c.dataset.legend);
    });
  }

  /* ---------- 比赛 ↔ 主页 ---------- */

  /** 回到主页：停推进、清粒子与震动、静音、关闭结算页 */
  function goHome() {
    state.match = null;
    state.race = null;
    state.paused = false;
    state.champIdx = -1;
    state.acc = 0;
    state.particles.length = 0;
    state.shake = { t: 0, power: 0 };
    state.vfxRnd = null;
    Sound.mute();
    var sb = $('btn-sound');
    if (sb) { sb.textContent = '🔇'; sb.title = '音效已关（点击开启）'; }
    var r = $('result'); if (r) r.hidden = true;
    hud.inter.hidden = true;
    hud.ticker.innerHTML = '';
    menuShow('main');
  }
  /** HUD 🏠 / Esc：比赛中要先确认 */
  function requestHome() {
    if (SPECTATOR) { goHome(); return; }
    var m = state.match;
    if (m && m.stage !== 'done') {
      confirmBox('比赛进行中，返回主页将放弃本局。', goHome);
    } else {
      goHome();
    }
  }

  /* ============================ 比赛流程 ============================ */

  function startMatch(seed, announce, mode) {
    if (SPECTATOR) {
      if (mode !== 'replay' || !spectatorRecord || spectatorRecord.seed !== (seed >>> 0)) return false;
    }
    state.seed = seed >>> 0;
    stopGameLoop();
    state.menuOpen = false;
    document.body.dataset.screen = 'game';
    if (SPECTATOR) document.documentElement.dataset.spectatorScreen = 'game';
    $('game-screen').hidden = false;
    var mel = $('menu'); if (mel) mel.hidden = true;
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    state.match = SPECTATOR ? window.PeppaRecorded.create(spectatorRecord, window.PeppaDaily.getRecording(spectatorRecord.id), state.players) : SIM.createMatch({ players: state.players, seed: state.seed });
    state.race = state.match.race;
    state.vfxRnd = SIM.mulberry32((state.seed ^ 0xC0FFEE) >>> 0);
    state.particles.length = 0;
    state.paused = false;
    state.acc = 0;
    state.champIdx = -1;
    $('btn-pause').textContent = '⏸';
    state.alpha = 0;
    state.frameRank = [];
    // 记录用：开赛时刻 + matchId（Date.now 只在 game.js 出现，绝不进 sim.js）
    state.startedAt = Date.now();
    state.recId = state.seed + '-' + state.startedAt;
    state.recWritten = false;
    state.recMode = mode === 'replay' ? 'replay' : 'new';
    state.recCount = 0;
    state.seedHint = state.seed;
    view.top = state.race.course.minY - 200;
    resize();
    try { if (!SPECTATOR) history.replaceState(null, '', '?seed=' + state.seed); } catch (e) { /* file:// 下可能受限 */ }
    $('result').hidden = true;
    hud.inter.hidden = true;
    setStageBanner(announce ? '预赛 · 18 进 3' : '重新开赛', 2.0);
    updateHud(true);
    resumeGameLoop();
  }

  /* ---------- 记录写入（每场只写一次，中途回主页 / 重开都不写） ---------- */

  function buildRecord(m, skipped) {
    var now = Date.now();
    var podium = [];
    if (m.finalRace) {
      var fin = m.finalRace.balls.slice().sort(function (a, b) {
        var ia = m.finalRace.finishedOrder.indexOf(a.idx), ib = m.finalRace.finishedOrder.indexOf(b.idx);
        if (ia < 0) ia = 99; if (ib < 0) ib = 99;
        return ia - ib;
      });
      fin.forEach(function (b) {
        podium.push({ qq: b.qq, name: b.name, time: b.finished ? Number(b.finishT.toFixed(3)) : null });
      });
    }
    return {
      id: state.recId || (state.seed + '-' + now),
      seed: state.seed,
      mode: state.recMode,
      date: Records.dayOf(now),
      startedAt: state.startedAt || now,
      endedAt: now,
      qualifierTime: Number(m.race.raceTime.toFixed(3)),
      finalTime: m.finalRace ? Number(m.finalRace.raceTime.toFixed(3)) : 0,
      champion: { qq: m.standings[0].qq, name: m.standings[0].name },
      podium: podium,
      standings: m.standings.map(function (r) {
        return { rank: r.rank, qq: r.qq, name: r.name, how: howText(r) };
      }),
      cuts: m.race.cuts.map(function (c) {
        return { round: c.round, afterLevel: c.afterLevel, out: c.out.map(function (o) { return o.name; }) };
      }),
      skipped: !!skipped,
    };
  }
  /** 返回"今日第 N 场"的 N；重复调用不会重复写入 */
  function maybeWriteRecord(skipped) {
    if (SPECTATOR) return 0;
    var m = state.match;
    if (state.recWritten || !m || !m.standings) return state.recCount;
    state.recWritten = true;
    try { Records.add(buildRecord(m, skipped)); } catch (e) { state.errors.push('record:' + e.message); }
    state.recCount = Records.today().length;
    updateRecordBadge();
    return state.recCount;
  }

  function setStageBanner(text, t) { state.stageBanner = text; state.stageBannerT = t; }

  function onRaceSwitch() {
    var m = state.match;
    state.race = m.currentRace();
    computeLayout();
    if (m.stage === 'intermission') {
      var names = m.finalists.map(function (qq) {
        var p = m.players.filter(function (x) { return x.qq === qq; })[0];
        return p ? p.name : qq;
      });
      setStageBanner('预赛结束！晋级决赛：' + names.join(' / '), 3.0);
      hud.inter.hidden = false;
      hud.inter.innerHTML = '<b>预赛结束</b><div>晋级决赛：' + names.map(escapeHtml).join(' · ') + '</div>';
      Sound.cut();
    } else if (m.stage === 'final') {
      hud.inter.hidden = true;
      setStageBanner('决赛开始！', 2.0);
    } else if (m.stage === 'done') {
      hud.inter.hidden = true;
      showResult();
    }
  }

  /**
   * 所有纯视觉计时统一在这里按真实 dt 递减（暂停不减、倍速按倍速减）。
   * 旧实现是在绘制函数里每帧减 1/60，而且对象不在屏幕内就提前 return —— 于是动画速度
   * 随帧率变化、滚出屏幕还会"冻结"。绘制函数现在只读不写。
   */
  function stepVisualTimers(race, dt) {
    if (!race || dt <= 0) return;
    var course = race.course, objs = course.objects, i;
    for (i = 0; i < course.elims.length; i++) {
      var ln = course.elims[i];
      if (ln.done && ln.flashT === undefined) ln.flashT = 1.0;
      if (ln.flashT > 0) ln.flashT -= dt;
    }
    for (i = 0; i < objs.boosts.length; i++) if (objs.boosts[i].flashT > 0) objs.boosts[i].flashT -= dt;
    for (i = 0; i < objs.pegs.length; i++) if (objs.pegs[i].ripple > 0) objs.pegs[i].ripple -= dt;
    for (i = 0; i < objs.bumpers.length; i++) if (objs.bumpers[i].hitT > 0) objs.bumpers[i].hitT -= dt;
    for (i = 0; i < objs.bars.length; i++) if (objs.bars[i].hitT > 0) objs.bars[i].hitT -= dt;
  }

  function tick(dt) {
    var m = state.match;
    if (!m) return;
    var before = m.stage;
    // 固定步长推进物理；速度倍率只改变每帧步数，不改变步进顺序 → 结果一致
    var sp = state.paused ? 0 : state.speed;
    state.acc += dt * sp;
    var steps = 0, maxSteps = 60;
    while (state.acc >= DT && steps < maxSteps) {
      var race = m.currentRace();
      race.balls.forEach(function (b) { b.px = b.x; b.py = b.y; });
      m.step();
      state.acc -= DT;
      steps++;
      var nowStage = m.stage;
      if (nowStage !== before) { onRaceSwitch(); before = nowStage; }
    }
    if (state.acc > DT * 12) state.acc = 0;
    state.alpha = clamp(state.acc / DT, 0, 1);
    state.race = m.currentRace();
    consumeVfx(state.race);
    stepParticles(dt);
    // 每帧只排一次序，所有绘制函数共用（旧实现里 drawBalls 对每个球都调一次 rankAlive）
    state.frameRank = state.race.rankAlive();
    stepVisualTimers(state.race, dt * sp);
    if (state.stageBannerT > 0) state.stageBannerT -= dt;
    updateCamera(Math.max(dt, 0.0001));
    adaptQuality(dt);
    if (m.stage === 'done' && state.champIdx < 0) {
      state.champIdx = 0;
      maybeWriteRecord(false);      // 一场只写一次；中途回主页 / 重开的不写
      showResult();
      Sound.win();
    }
  }

  /* ============================ 结果页 ============================ */

  function showResult() {
    var m = state.match;
    if (!m || !m.standings) return;
    var el = $('result');
    if (SPECTATOR) {
      window.PeppaDaily.showReplayResult(el, spectatorRecord, m.standings);
      return;
    }
    if (!el.hidden && el.dataset.seed === String(state.seed)) return;
    el.dataset.seed = String(state.seed);
    var html = '';
    html += '<div class="res-card">';
    html += '<div class="res-head"><h2>🏆 全场名次</h2><div class="res-sub">种子 <b>' + state.seed
      + '</b> · 预赛 ' + m.race.raceTime.toFixed(1) + 's · 决赛 ' + (m.finalRace ? m.finalRace.raceTime.toFixed(1) : '-') + 's</div></div>';

    var champ = m.standings[0];
    var cp = m.players.filter(function (p) { return p.qq === champ.qq; })[0] || champ;
    html += '<div class="champ"><div class="crown">👑</div>'
      + '<div class="cav">' + thumbHtml(cp) + '</div>'
      + '<div class="cnm">' + escapeHtml(champ.name) + '</div>'
      + '<div class="ctag">冠军 · ' + (champ.stage === 'final' ? '决赛第一' : '') + '</div></div>';

    html += '<div class="res-cols">' + standingsTableHtml(m.standings, m.players);

    html += '<div class="res-log"><h3>淘汰记录</h3><ol>';
    m.race.cuts.forEach(function (c) {
      html += '<li><b>第 ' + c.round + ' 轮</b>（第 ' + c.afterLevel + ' 关末 · ' + c.t.toFixed(1) + 's）<br>'
        + c.out.map(function (o) { return escapeHtml(o.name); }).join(' · ') + '</li>';
    });
    html += '</ol><h3>决赛</h3><ol>';
    if (m.finalRace) {
      m.finalRace.balls.slice().sort(function (a, b) {
        var ia = m.finalRace.finishedOrder.indexOf(a.idx), ib = m.finalRace.finishedOrder.indexOf(b.idx);
        if (ia < 0) ia = 99; if (ib < 0) ib = 99;
        return ia - ib;
      }).forEach(function (b, i) {
        html += '<li>' + escapeHtml(b.name)   // <ol> 自带序号，不要再手动拼 (i+1)
          + (b.finished ? ' <span class="t">' + b.finishT.toFixed(2) + 's</span>' : ' <span class="t">未完赛</span>') + '</li>';
      });
    }
    html += '</ol></div></div>';

    html += '<div class="res-foot">'
      + '<button class="btn primary" id="btn-again">再来一局（新种子）</button>'
      + '<button class="btn" id="btn-replay">重放本局（同种子 ' + state.seed + '）</button>'
      + '<button class="btn" id="btn-close">看回放画面</button>'
      + '<button class="btn" id="btn-home2">🏠 返回主页</button>'
      + '</div>';
    html += '</div>';
    el.innerHTML = html;
    el.hidden = false;
    // 记录联动：本场已记入今日第 N 场（若浏览器不允许本地存储则提示）
    var recLine = document.createElement('div');
    recLine.className = 'res-sub';
    recLine.id = 'res-record';
    recLine.style.textAlign = 'center';
    recLine.style.marginTop = '10px';
    if (!Records.isAvailable()) recLine.textContent = '当前浏览器不允许本地存储，本场未记录';
    else if (state.recWritten) recLine.textContent = '已记入今日第 ' + (state.recCount || Records.today().length) + ' 场';
    else recLine.textContent = '';
    el.querySelector('.res-card').appendChild(recLine);
    $('btn-again').onclick = function () { startMatch((Math.random() * 0xFFFFFFFF) >>> 0, true, 'new'); };
    $('btn-replay').onclick = function () { startMatch(state.seed, true, 'replay'); };
    $('btn-close').onclick = function () { el.hidden = true; };
    $('btn-home2').onclick = goHome;
  }

  /* ============================ 交互 ============================ */

  function bindInput() {
    window.addEventListener('keydown', function (e) {
      // 1) 确认弹窗优先
      if (!$('confirm').hidden) {
        if (e.key === 'Enter') { e.preventDefault(); cfResolve(true); }
        else if (e.key === 'Escape') { e.preventDefault(); cfResolve(false); }
        return;
      }
      // 2) 主菜单显示时，比赛快捷键一律不响应，只处理菜单自己的键
      if (state.menuOpen) {
        if (e.key === 'Enter' && e.target instanceof HTMLElement && e.target.closest('button')) {
          e.preventDefault(); e.target.closest('button').click(); return;
        }
        if (e.key === 'Enter') { e.preventDefault(); menuPrimary(); }
        else if (e.key === 'Escape') { e.preventDefault(); menuBack(); }
        return;
      }
      // 3) 比赛中
      if (e.code === 'Space') { e.preventDefault(); state.paused = !state.paused; $('btn-pause').textContent = state.paused ? '▶' : '⏸'; }
      else if (e.key === 'r' || e.key === 'R') { startMatch(state.seed, true, state.recMode); }
      else if (e.key === '1') setSpeed(1);
      else if (e.key === '2') setSpeed(2);
      else if (e.key === '4') setSpeed(4);
      else if (e.key === 's' || e.key === 'S') toggleSound();
      else if (e.key === 'Escape') { e.preventDefault(); requestHome(); }
    });
    document.querySelectorAll('[data-speed]').forEach(function (btn) {
      btn.onclick = function () { setSpeed(Number(btn.dataset.speed)); };
    });
    $('btn-pause').onclick = function () { state.paused = !state.paused; $('btn-pause').textContent = state.paused ? '▶' : '⏸'; };
    $('btn-sound').onclick = toggleSound;
    var shBtn = $('btn-shake');
    if (shBtn) shBtn.onclick = function () {
      state.shakeOn = !state.shakeOn;
      shBtn.textContent = state.shakeOn ? '📳' : '🚫';
      shBtn.classList.toggle('on', state.shakeOn);
      shBtn.title = state.shakeOn ? '碰撞震动：开' : '碰撞震动：关';
    };
    $('btn-live').onclick = function () {
      $('result').hidden = true;
      startMatch(state.seed, true, state.recMode);
    };
    $('btn-home').onclick = requestHome;
    var qBtn = $('btn-quality');
    if (qBtn) qBtn.onclick = function () {
      state.quality = state.quality === 'auto' ? 'high' : (state.quality === 'high' ? 'low' : 'auto');
      if (state.quality === 'high') state.autoDpr = 2;
      else if (state.quality === 'low') state.autoDpr = 1;
      qBtn.textContent = state.quality === 'auto' ? '⚙ 自动' : (state.quality === 'high' ? '⚙ 高' : '⚙ 低');
      qBtn.title = '画质：' + (state.quality === 'auto' ? '自动' : (state.quality === 'high' ? '高（dpr 2）' : '低（dpr 1）'));
      resize();
    };

    // ---- 主菜单 ----
    if (!SPECTATOR) {
    $('m-start').onclick = function () { menuStartGame('new'); };
    $('m-records').onclick = function () { state.recDay = null; setMenuPage('records'); };
    $('m-rules').onclick = function () { setMenuPage('rules'); };
    $('m-dice').onclick = function () {
      $('m-seed-input').value = String((Math.random() * 0xFFFFFFFF) >>> 0);
      validateSeedInput();
    };
    $('m-seed-input').addEventListener('input', validateSeedInput);
    $('m-rec-back').onclick = function () { setMenuPage('main'); };
    $('m-det-back').onclick = function () { setMenuPage('records'); };
    $('m-rule-back').onclick = function () { setMenuPage('main'); };
    }
    $('cf-ok').onclick = function () { cfResolve(true); };
    $('cf-cancel').onclick = function () { cfResolve(false); };
  }
  function setSpeed(s) {
    state.speed = s;
    document.querySelectorAll('[data-speed]').forEach(function (b) {
      b.classList.toggle('on', Number(b.dataset.speed) === s);
    });
  }
  function toggleSound() {
    var on = Sound.toggle();
    $('btn-sound').textContent = on ? '🔊' : '🔇';
    $('btn-sound').title = on ? '音效已开' : '音效已关（点击开启）';
  }

  /* ============================ 自检钩子（?selftest=1） ============================ */

  function runSelfTest() {
    var out = { ok: false, errors: [], seed: state.seed };
    try {
      var m = SIM.createMatch({ players: state.players, seed: state.seed });
      var steps = m.runToEnd();
      out.steps = steps;
      out.standings = m.standings.map(function (r) { return r.rank + ':' + r.name + ':' + r.qq; });
      out.champion = m.standings[0].name;
      out.finalists = m.finalists;
      out.cuts = m.race.cuts.map(function (c) { return c.out.map(function (o) { return o.name; }).join('/'); });
      out.qualifierTime = Number(m.race.raceTime.toFixed(2));
      out.finalTime = Number(m.finalRace.raceTime.toFixed(2));
      out.qualifierLength = Math.round(m.race.course.total);
      out.finalLength = Math.round(m.finalRace.course.total);
      out.avatars = state.players.filter(function (p) { return !!p.avatar; }).length;
      out.players = state.players.length;
      // 渲染一遍，确保渲染层也不抛错
      state.match = m; state.race = m.currentRace();
      computeLayout();
      render(0.016);
      updateHud(true);
      out.rendered = true;
      out.ok = true;
    } catch (err) {
      out.errors.push(String(err && err.stack || err));
    }
    out.errors = out.errors.concat(state.errors);
    var pre = document.createElement('pre');
    pre.id = 'peppa-selftest';
    pre.style.cssText = 'position:fixed;left:-9999px;top:0;white-space:pre-wrap';
    pre.textContent = JSON.stringify(out, null, 2);
    document.body.appendChild(pre);
    document.title = out.ok ? 'PEPPA_SELFTEST_OK' : 'PEPPA_SELFTEST_FAIL';
  }

  /* ============================ 启动 ============================ */

  function resize() {
    // 画布只覆盖 availW（右侧排行榜面板挡住的区域不再渲染，面板用自己的 CSS 背景）
    state.dpr = effectiveDpr();
    computeLayout();
    var dpr = state.dpr;
    cv.width = Math.max(1, Math.round(view.availW * dpr));
    cv.height = Math.max(1, Math.round(view.h * dpr));
    cv.style.width = view.availW + 'px';
    cv.style.height = view.h + 'px';
    invalidateTiles();
  }

  function boot() {
    window.addEventListener('error', function (e) {
      state.errors.push(String(e.message) + ' @ ' + e.filename + ':' + e.lineno);
    });
    window.addEventListener('unhandledrejection', function (e) {
      state.errors.push('unhandledrejection: ' + String(e.reason));
    });

    var params = new URLSearchParams(location.search);
    var rawSeed = params.get('seed');
    var seedParam = parseInt(rawSeed, 10);
    var hasSeed = rawSeed !== null && String(rawSeed).trim() !== '' && Number.isFinite(seedParam) && seedParam >= 0;
    var seed = hasSeed ? (seedParam >>> 0) : ((Math.random() * 0xFFFFFFFF) >>> 0);

    state.players = loadRoster();
    if (!state.players.length) {
      document.body.innerHTML = '<div style="color:#e2e8f0;font:16px system-ui;padding:40px;line-height:1.8">'
        + '读不到选手名单 data/players.js。<br>请先在项目根目录执行：<code>node tools/fetch-avatars.mjs</code></div>';
      return;
    }
    state.players.forEach(loadAvatar);

    bindInput();
    setSpeed(1);
    resize();
    window.addEventListener('resize', resize);
    if (SPECTATOR) {
      // Only stored official matches can enter the renderer. URL seeds, the
      // original debug restart API and local record writes are not exposed.
      window.PeppaPlayback = Object.freeze({
        watch: function (id) {
          var rec = window.PeppaDaily.getMatch(id);
          if (!rec || !window.PeppaDaily.supports(rec.simVersion) || !window.PeppaDaily.getRecording(id)) return false;
          SIM = window.PeppaSimVersions[rec.simVersion];
          spectatorRecord = rec;
          state.players = window.PeppaDaily.getPlayers().map(function (p) {
            return { qq: p.qq, name: p.name, role: p.role, avatar: p.avatar };
          });
          state.players.forEach(loadAvatar);
          startMatch(rec.seed, true, 'replay');
          setStageBanner('今日第 ' + rec.number + ' 场 · 官方回放', 3);
          return true;
        },
        home: goHome,
        status: function () { return { screen: state.menuOpen ? 'home' : 'replay', matchId: spectatorRecord ? spectatorRecord.id : null, stage: state.match ? state.match.stage : null, paused: state.paused, speed: state.speed, raceTime: state.race ? state.race.raceTime : 0, frames: state.frameCount, errors: state.errors.slice() }; }
      });
      menuShow('main');
      window.PeppaDaily.init();
      return;
    }
    Records.probe();          // 探测 localStorage 是否可用（失败也不影响游戏）

    if (params.get('selftest')) {          // 无头自检：保持原有行为，不显示主菜单
      state.seed = seed; state.seedHint = seed;
      startMatch(seed, true, 'new');
      stopGameLoop();
      expose(); runSelfTest(); return;
    }

    // ?play=1（browser-check 用的 ?live=1 等价）→ 直接开赛；
    // 否则进主菜单。?seed=N 只把种子预填进输入框，不自动开赛 ——
    // 所以比赛进行中刷新页面会回到主菜单并保留当前种子。
    if (params.get('play') === '1' || params.get('live') === '1') {
      state.seedHint = seed;
      startMatch(seed, true, 'new');
    } else {
      state.seed = seed;
      state.seedHint = hasSeed ? seed : null;
      menuShow('main');
    }

    resumeGameLoop();
    expose();
  }

  function expose() {
    window.__PEPPA = {
      state: state, sim: SIM, view: view, sound: Sound,
      restart: function (s) { startMatch(s === undefined ? state.seed : s, true, 'new'); },
      /** 定位到指定弧长（截图 / 调试用）：暂停主循环，同步推进到目标位置再渲染一帧 */
      seek: function (target, which) {
        state.paused = true;
        var m = state.match;
        var g = 0;
        if (which === 'final') {
          while (m.stage !== 'final' && m.stage !== 'done' && g < 400000) { m.step(); g++; }
        }
        var race = m.currentRace();
        while (!race.done && g < 400000) {
          var lead = race.rankAlive()[0];
          if (lead && lead.best >= target) break;
          m.step(); g++;
          race = m.currentRace();
        }
        state.race = m.currentRace();
        state.race.balls.forEach(function (b) { b.px = b.x; b.py = b.y; });
        state.alpha = 0;
        state.frameRank = state.race.rankAlive();
        computeLayout();
        updateCamera(0.6);
        render(0.016);
        updateHud(true);
        var la = state.race.rankAlive();
        return { ok: true, stage: m.stage, leadS: la.length ? Math.round(la[0].best) : 0, steps: g };
      },
      fastForward: function () {
        if (!state.match) return null;
        state.match.runToEnd();
        state.match.currentRace().balls.forEach(function (b) { b.px = b.x; b.py = b.y; });
        state.alpha = 0;
        maybeWriteRecord(true);        // 快进跑完的也记入，但标记 skipped:true
        onRaceSwitch();
        render(0.016);
        updateHud(true);
        return state.match.standings ? state.match.standings.length : 0;
      },
      /**
       * 障碍物审计：每个障碍物的「画面外接半径 / 碰撞外接半径」（世界单位）。
       * visR 的公式与 drawBars / drawMills / drawPendulums / drawPlats / drawRoundObstacles
       * 里的绘制尺寸一一对应（半透明光晕不计入外接半径，单独用 padWorld 表示外扩上限）。
       * 回归检查要求 ratio ≤ 1.15、padWorld ≤ 6。
       */
      obstacleRatios: function () {
        var race = state.race;
        if (!race) return null;
        var o = race.course.objects, out = [];
        function add(kind, colR, visR) {
          out.push({ kind: kind, col: +colR.toFixed(2), vis: +visR.toFixed(2), ratio: +(visR / colR).toFixed(4) });
        }
        o.bars.forEach(function (b) { add('bar', b.half + b.thick, b.half + b.thick * 1.1); });
        o.mills.forEach(function (m) { add('mill', m.half + m.thick, m.half + Math.max(m.thick * 0.95, m.thick * 1.1)); });
        o.pendulums.forEach(function (p) { add('pendulum', p.arm + p.thick, p.arm + p.thick * 1.1); });
        o.plats.forEach(function (p) { add('plat', p.half + p.thick, p.half + p.thick); });
        o.pegs.forEach(function (p) { add('peg', p.r, p.r); });
        o.bumpers.forEach(function (p) { add('bumper', p.r, p.r * 1.1); });
        // JSON.stringify 不会序列化数组的自定义属性，所以包一层对象。
        // drawCapsule 的光晕是「线宽 = 半宽×2 + 6px」，即每侧只外扩 3 屏幕像素 → 3/scale 世界单位。
        return { list: out, padWorld: +(3 / view.scale).toFixed(2) };
      },

      /** 对照实验：同一帧分别用「瓦片缓存」和「实时绘制」渲染静态层，返回平均像素差异（0~1） */
      compareTileRender: function () {
        var race = state.race;
        if (!race) return null;
        var W = Math.round(view.availW), H = Math.round(view.h);
        var savedCtx = ctx, savedDpr = state.dpr;
        state.dpr = 1;
        var A = document.createElement('canvas'); A.width = W; A.height = H;
        var B = document.createElement('canvas'); B.width = W; B.height = H;
        ctx = A.getContext('2d');
        ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H);
        drawBackdrop(); drawLevelBands(race); drawChannel(race, 'static'); drawMarkers(race, 'static');
        ctx = B.getContext('2d');
        ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H);
        invalidateTiles();
        drawTiles(race);
        var da = A.getContext('2d').getImageData(0, 0, W, H).data;
        var db = B.getContext('2d').getImageData(0, 0, W, H).data;
        var diff = 0, n = 0, gx, gy;
        var G = 4, grid = [];
        for (gy = 0; gy < G; gy++) { grid.push([]); for (gx = 0; gx < G; gx++) grid[gy].push({ d: 0, n: 0 }); }
        for (var yy = 0; yy < H; yy++) {
          for (var xx = 0; xx < W; xx++) {
            var i = (yy * W + xx) * 4;
            var d = (Math.abs(da[i] - db[i]) + Math.abs(da[i + 1] - db[i + 1]) + Math.abs(da[i + 2] - db[i + 2])) / 3;
            diff += d; n++;
            var c = grid[(yy * G / H) | 0][(xx * G / W) | 0];
            c.d += d; c.n++;
          }
        }
        ctx = savedCtx; state.dpr = savedDpr; invalidateTiles();
        var covA = 0, covB = 0;
        for (var q = 3; q < da.length; q += 4) { if (da[q] > 8) covA++; if (db[q] > 8) covB++; }
        return {
          mean: diff / n / 255, w: W, h: H, covA: covA, covB: covB, px: n,
          grid: grid.map(function (row) { return row.map(function (c) { return +(c.d / c.n / 255 * 100).toFixed(2); }); }),
        };
      },

      /**
       * 对照实验：验证「视觉计时只依赖 dt、与帧率无关」。
       * 取第一个加速跳板，分别按 dt=1/30 与 dt=1/120 递减同样的 2 秒真实时间，
       * 看消耗掉的 flashT 是否一致（旧实现每帧减 1/60，会随帧率变化）。
       */
      visualTimerProbe: function () {
        var race = state.race;
        if (!race) return null;
        var g = race.course.objects.boosts[0];
        if (!g) return null;
        var TARGET = 2.0;
        function run(dt) {
          g.flashT = 1e9;
          var t = 0, steps = 0;
          while (t < TARGET - 1e-9 && steps < 100000) { stepVisualTimers(race, dt); t += dt; steps++; }
          return { consumed: 1e9 - g.flashT, steps: steps };
        }
        var a = run(1 / 30), b2 = run(1 / 120);
        g.flashT = 0;
        return {
          t30: a.consumed, t120: b2.consumed, steps30: a.steps, steps120: b2.steps,
          ratio30: a.consumed / TARGET,
        };
      },

      /** 开关瓦片缓存（对照实验 / 调试用） */
      setTilesEnabled: function (on) { tilesEnabled = !!on; invalidateTiles(); return tilesEnabled; },
      cameraMetrics: function () {
        var race = activeRace();
        var ball = race && race.balls.find(function (b) { return b.qq === state.cameraTarget; });
        if (!ball) return null;
        var pos = ballScreen(ball);
        return { qq: ball.qq, name: ball.name, x: toScreenX(pos.x), y: toScreenY(pos.y),
          centerX: view.availW / 2, centerY: view.h / 2,
          error: hypot(toScreenX(pos.x) - view.availW / 2, toScreenY(pos.y) - view.h / 2) };
      },
      /** 今日记录（自动化测试 / 调试用） */
      records: {
        available: function () { return Records.isAvailable(); },
        key: Records.KEY,
        list: function () { return Records.list(); },
        today: function () { return Records.today(); },
        clear: function () { Records.clearToday(); updateRecordBadge(); return Records.today().length; },
      },
      /** 主菜单（自动化测试 / 调试用） */
      menu: {
        show: function (p) { menuShow(p || 'main'); },
        hide: function () { menuHide(); },
        get page() { return state.menuOpen ? state.menuPage : null; },
      },
      /** 布局自检：球的最小可视半径 / 是否溢出 / 面板宽度 */
      metrics: function () {
        var board = $('board');
        var rows = document.querySelectorAll('#board-list .row');
        var outRows = document.querySelectorAll('#board-out .row');
        var clip = 0, longest = '';
        rows.forEach(function (r) {
          var nm = r.querySelector('.nm');
          if (nm && nm.scrollWidth > nm.clientWidth + 1) {
            clip++;
            if (!longest || nm.textContent.length > longest.length) longest = nm.textContent;
          }
        });
        // 自动化测试用的物理观测量：领先球累计转角 + 高速撞击计数
        var leadBall = state.race ? (state.race.rankAlive()[0] || null) : null;
        return {
          w: window.innerWidth, h: window.innerHeight,
          availW: view.availW, scale: view.scale,
          ballRadiusPx: SIM.BALL_R * view.scale,
          panelW: board ? board.getBoundingClientRect().width : 0,
          boardVisible: !!board && board.getBoundingClientRect().width > 0,
          rows: rows.length,
          outRows: outRows.length,
          namesEllipsized: clip,
          longestClipped: longest,
          overflowX: document.documentElement.scrollWidth - window.innerWidth,
          overflowY: document.documentElement.scrollHeight - window.innerHeight,
          hudTimer: $('hud-timer').textContent,
          alive: $('hud-alive-n').textContent,
          round: $('hud-round').textContent,
          stage: state.match ? state.match.stage : null,
          progress: state.race ? state.race.raceTime.toFixed(1) : null,
          maxSpeedHits: state.race && state.race.maxSpeedHits != null ? state.race.maxSpeedHits : 0,
          ballAngleSample: leadBall && leadBall.angle != null ? Number(leadBall.angle.toFixed(3)) : 0,
          resultShown: !$('result').hidden,
          standings: state.match && state.match.standings ? state.match.standings.length : 0,
          errors: state.errors.slice(),
          frameMs: Number(state.frameMs.toFixed(2)),
          shakeOn: state.shakeOn,
          avatarsLoaded: state.players.filter(function (p) { return p.imgOk; }).length,
          avatarsTotal: state.players.length,
          thumbBroken: Array.prototype.filter.call(document.querySelectorAll('#board-list img.th'), function (i) { return i.complete && i.naturalWidth === 0; }).length,
          // 主菜单 / 记录相关
          menuOpen: state.menuOpen,
          menuPage: state.menuOpen ? state.menuPage : null,
          menuVisible: (function () { var el = $('menu'); return !!el && !el.hidden; })(),
          demoStatic: false,
          demoActive: false,
          matchExists: !!state.match,
          recordWritten: state.recWritten,
          recordCount: state.recCount,
          recordsAvailable: Records.isAvailable(),
          confirmVisible: !$('confirm').hidden,
          dpr: state.dpr,
          quality: state.quality,
          tilesEnabled: tilesEnabled,
          tileCount: Object.keys(tiles.map).length,
          tileBuilt: state.tileBuilt,
          particles: state.particles.length,
        };
      },
    };
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
